(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm-es5 lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
/*!*********************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm-es5 lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*********************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-action-sheet-ios.entry.js",
		"common",
		2
	],
	"./ion-action-sheet-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-action-sheet-md.entry.js",
		"common",
		3
	],
	"./ion-alert-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-alert-ios.entry.js",
		"common",
		4
	],
	"./ion-alert-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-alert-md.entry.js",
		"common",
		5
	],
	"./ion-app_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-app_8-ios.entry.js",
		0,
		"common",
		6
	],
	"./ion-app_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-app_8-md.entry.js",
		0,
		"common",
		7
	],
	"./ion-avatar_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-avatar_3-ios.entry.js",
		"common",
		8
	],
	"./ion-avatar_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-avatar_3-md.entry.js",
		"common",
		9
	],
	"./ion-back-button-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-back-button-ios.entry.js",
		"common",
		10
	],
	"./ion-back-button-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-back-button-md.entry.js",
		"common",
		11
	],
	"./ion-backdrop-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-backdrop-ios.entry.js",
		12
	],
	"./ion-backdrop-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-backdrop-md.entry.js",
		13
	],
	"./ion-button_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-button_2-ios.entry.js",
		"common",
		14
	],
	"./ion-button_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-button_2-md.entry.js",
		"common",
		15
	],
	"./ion-card_5-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-card_5-ios.entry.js",
		"common",
		16
	],
	"./ion-card_5-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-card_5-md.entry.js",
		"common",
		17
	],
	"./ion-checkbox-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-checkbox-ios.entry.js",
		"common",
		18
	],
	"./ion-checkbox-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-checkbox-md.entry.js",
		"common",
		19
	],
	"./ion-chip-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-chip-ios.entry.js",
		"common",
		20
	],
	"./ion-chip-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-chip-md.entry.js",
		"common",
		21
	],
	"./ion-col_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-col_3.entry.js",
		22
	],
	"./ion-datetime_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-datetime_3-ios.entry.js",
		"common",
		23
	],
	"./ion-datetime_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-datetime_3-md.entry.js",
		"common",
		24
	],
	"./ion-fab_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-fab_3-ios.entry.js",
		"common",
		25
	],
	"./ion-fab_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-fab_3-md.entry.js",
		"common",
		26
	],
	"./ion-img.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-img.entry.js",
		27
	],
	"./ion-infinite-scroll_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-infinite-scroll_2-ios.entry.js",
		"common",
		28
	],
	"./ion-infinite-scroll_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-infinite-scroll_2-md.entry.js",
		"common",
		29
	],
	"./ion-input-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-input-ios.entry.js",
		"common",
		30
	],
	"./ion-input-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-input-md.entry.js",
		"common",
		31
	],
	"./ion-item-option_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item-option_3-ios.entry.js",
		"common",
		32
	],
	"./ion-item-option_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item-option_3-md.entry.js",
		"common",
		33
	],
	"./ion-item_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item_8-ios.entry.js",
		"common",
		34
	],
	"./ion-item_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item_8-md.entry.js",
		"common",
		35
	],
	"./ion-loading-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-loading-ios.entry.js",
		"common",
		36
	],
	"./ion-loading-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-loading-md.entry.js",
		"common",
		37
	],
	"./ion-menu_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-menu_3-ios.entry.js",
		"common",
		38
	],
	"./ion-menu_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-menu_3-md.entry.js",
		"common",
		39
	],
	"./ion-modal-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-modal-ios.entry.js",
		0,
		"common",
		40
	],
	"./ion-modal-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-modal-md.entry.js",
		0,
		"common",
		41
	],
	"./ion-nav_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-nav_2.entry.js",
		0,
		42
	],
	"./ion-popover-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-popover-ios.entry.js",
		0,
		"common",
		43
	],
	"./ion-popover-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-popover-md.entry.js",
		0,
		"common",
		44
	],
	"./ion-progress-bar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-progress-bar-ios.entry.js",
		"common",
		45
	],
	"./ion-progress-bar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-progress-bar-md.entry.js",
		"common",
		46
	],
	"./ion-radio_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-radio_2-ios.entry.js",
		"common",
		47
	],
	"./ion-radio_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-radio_2-md.entry.js",
		"common",
		48
	],
	"./ion-range-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-range-ios.entry.js",
		"common",
		49
	],
	"./ion-range-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-range-md.entry.js",
		"common",
		50
	],
	"./ion-refresher_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-refresher_2-ios.entry.js",
		"common",
		51
	],
	"./ion-refresher_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-refresher_2-md.entry.js",
		"common",
		52
	],
	"./ion-reorder_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-reorder_2-ios.entry.js",
		"common",
		53
	],
	"./ion-reorder_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-reorder_2-md.entry.js",
		"common",
		54
	],
	"./ion-ripple-effect.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-ripple-effect.entry.js",
		55
	],
	"./ion-route_4.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-route_4.entry.js",
		"common",
		56
	],
	"./ion-searchbar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-searchbar-ios.entry.js",
		"common",
		57
	],
	"./ion-searchbar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-searchbar-md.entry.js",
		"common",
		58
	],
	"./ion-segment_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-segment_2-ios.entry.js",
		"common",
		59
	],
	"./ion-segment_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-segment_2-md.entry.js",
		"common",
		60
	],
	"./ion-select_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-select_3-ios.entry.js",
		"common",
		61
	],
	"./ion-select_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-select_3-md.entry.js",
		"common",
		62
	],
	"./ion-slide_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-slide_2-ios.entry.js",
		63
	],
	"./ion-slide_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-slide_2-md.entry.js",
		64
	],
	"./ion-spinner.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-spinner.entry.js",
		"common",
		65
	],
	"./ion-split-pane-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-split-pane-ios.entry.js",
		66
	],
	"./ion-split-pane-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-split-pane-md.entry.js",
		67
	],
	"./ion-tab-bar_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-tab-bar_2-ios.entry.js",
		"common",
		68
	],
	"./ion-tab-bar_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-tab-bar_2-md.entry.js",
		"common",
		69
	],
	"./ion-tab_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-tab_2.entry.js",
		1
	],
	"./ion-text.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-text.entry.js",
		"common",
		70
	],
	"./ion-textarea-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-textarea-ios.entry.js",
		"common",
		71
	],
	"./ion-textarea-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-textarea-md.entry.js",
		"common",
		72
	],
	"./ion-toast-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toast-ios.entry.js",
		"common",
		73
	],
	"./ion-toast-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toast-md.entry.js",
		"common",
		74
	],
	"./ion-toggle-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toggle-ios.entry.js",
		"common",
		75
	],
	"./ion-toggle-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toggle-md.entry.js",
		"common",
		76
	],
	"./ion-virtual-scroll.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-virtual-scroll.entry.js",
		77
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm-es5 lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-SG": "./node_modules/moment/locale/en-SG.js",
	"./en-SG.js": "./node_modules/moment/locale/en-SG.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./ga": "./node_modules/moment/locale/ga.js",
	"./ga.js": "./node_modules/moment/locale/ga.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it-ch": "./node_modules/moment/locale/it-ch.js",
	"./it-ch.js": "./node_modules/moment/locale/it-ch.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ku": "./node_modules/moment/locale/ku.js",
	"./ku.js": "./node_modules/moment/locale/ku.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\n  <ion-router-outlet></ion-router-outlet>\n</ion-app>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-direct-login/auth-direct-login.component.html":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-direct-login/auth-direct-login.component.html ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content color=\"light\" class=\"ion-text-center\">\n  <div class=\"div-logo\">\n    <app-branding-logo></app-branding-logo>\n  </div>\n  <div class=\"div-after-logo\">\n    <p>We are redirecting you to the page you want to go to, please be patient\n      <ion-spinner name=\"dots\" class=\"vertical-middle\"></ion-spinner>\n    </p>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-forgot-password/auth-forgot-password.component.html":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-forgot-password/auth-forgot-password.component.html ***!
  \*********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content color=\"light\" class=\"ion-text-center\">\n  <div class=\"div-logo\">\n    <app-branding-logo></app-branding-logo>\n  </div>\n  <div class=\"div-after-logo\">\n    <p class=\"headline-6\">Forgot your password? No worries, mate!</p>\n    <p class=\"body-1\">Enter your email and we'll send you a link that will let you pick a new password.</p>\n    <ion-list class=\"ion-margin\">\n      <ion-item>\n        <ion-input name=\"email\" [(ngModel)]=\"email\" required type=\"text\" placeholder=\"Email\"></ion-input>\n      </ion-item>\n    </ion-list>\n    <div class=\"clearfix\"></div>\n    <ion-button (click)=\"send()\" shape=\"round\" color=\"primary\" expand=\"full\">\n      <ng-container *ngIf=\"!isSending\">Send Email</ng-container>\n      <ng-container *ngIf=\"isSending\">Sending...</ng-container>\n    </ion-button>\n    <div class=\"text-split\">\n      <span><ion-text class=\"body-2 ion-margin-end\"> Remembered it?</ion-text></span>\n      <a class=\"subtitle-2\" routerLink=\"/login\">Login here</a>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-login/auth-login.component.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-login/auth-login.component.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content color=\"light\" class=\"ion-text-center\">\n  <div class=\"div-logo\">\n    <app-branding-logo></app-branding-logo>\n  </div>\n  <div class=\"div-after-logo\">\n    <form (ngSubmit)=\"login()\" [formGroup]=\"loginForm\" (keyup.enter)=\"login()\">\n      <ion-list class=\"ion-margin\">\n        <ion-item>\n          <ion-input\n            name=\"email\"\n            formControlName=\"email\"\n            required\n            autocomplete=\"on\"\n            inputmode=\"email\"\n            type=\"email\"\n            placeholder=\"Email\"\n            ></ion-input>\n        </ion-item>\n        <ion-item lines=\"none\">\n          <ion-input\n            name=\"password\"\n            formControlName=\"password\"\n            autocomplete=\"on\"\n            inputmode=\"password\"\n            required\n            [type]=\"showPassword ? 'text' : 'password'\"\n            placeholder=\"Password\"\n            ></ion-input>\n            <ion-button (click)=\"showPassword = !showPassword\" fill=\"clear\">\n              <ion-icon slot=\"end\" [name]=\"showPassword ? 'eye' : 'eye-off'\"></ion-icon>\n            </ion-button>\n        </ion-item>\n      </ion-list>\n      <ion-button\n        shape=\"round\"\n        color=\"primary\"\n        [disabled]=\"!loginForm.valid || isLoggingIn\"\n        type=\"submit\"\n        expand=\"full\"\n        >\n        <ng-container *ngIf=\"!isLoggingIn\">LOGIN</ng-container>\n        <ng-container *ngIf=\"isLoggingIn\">LOGGING IN...</ng-container>\n      </ion-button>\n    </form>\n  </div>\n  <div class=\"text-split\">\n    <a routerLink=\"/forgot_password\" class=\"subtitle-2\">Problem signing in?</a>\n  </div>\n  <div>\n    <a>Powered by</a><img src=\"/assets/logo.svg\" height=\"25\" class=\"img-inline\">\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-registration/auth-registration.component.html":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-registration/auth-registration.component.html ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content color=\"light\" class=\"ion-text-center\">\n  <div class=\"div-logo registration\">\n    <app-branding-logo></app-branding-logo>\n  </div>\n  <div class=\"div-after-logo\">\n    <ng-container *ngIf=\"!hide_password\">\n      <p class=\"headline-6\">Your Login Email Address</p>\n      <p class=\"body-1\">{{user.email}}</p>\n    </ng-container>\n    <ng-container *ngIf=\"hide_password\">\n      <p class=\"headline-6\">Your Mobile Number</p>\n      <p class=\"body-1\">{{user.contact}}</p>\n    </ng-container>\n    <form [formGroup]=\"registerationForm\">\n      <ion-input name=\"email\" formControlName=\"email\" type=\"hidden\" value=\"{{user.email}}\" aria-hidden=\"true\"></ion-input>\n      <ion-list margin>\n        <ion-item *ngIf=\"!hide_password\">\n          <ion-input\n            name=\"password\"\n            [(ngModel)]=\"password\"\n            inputmode=\"password\"\n            formControlName=\"password\"\n            autocomplete=\"on\"\n            required\n            [type]=\"showPassword ? 'text' : 'password'\"\n            placeholder=\"Set up Practera password*\"></ion-input>\n          <ion-button (click)=\"showPassword = !showPassword\" fill=\"clear\">\n            <ion-icon slot=\"end\" [name]=\"showPassword ? 'eye' : 'eye-off'\"></ion-icon>\n          </ion-button>\n        </ion-item>\n        <ion-item *ngIf=\"!hide_password\" lines=\"none\">\n          <ion-input\n            name=\"confirmPassword\"\n            [(ngModel)]=\"confirmPassword\"\n            inputmode=\"password\"\n            formControlName=\"confirmPassword\"\n            required\n            [type]=\"showPassword ? 'text' : 'password'\"\n            autocomplete=\"on\"\n            placeholder=\"Confirm password*\"></ion-input>\n        </ion-item>\n      </ion-list>\n      <div class=\"list-terms\">\n        <ion-checkbox color=\"primary\" slot=\"start\" [(ngModel)]=\"isAgreed\" [ngModelOptions]=\"{standalone: true}\" name=\"isAgreed\"></ion-checkbox>\n        <ion-label class=\"body-2\">I agree to the <a class=\"subtitle-2\" (click)=\"openLink()\">Terms & Conditions</a></ion-label>\n      </div>\n\n      <ion-text *ngFor=\"let error of errors\" color=\"danger\">\n        <p class=\"text-error\">{{error}}</p>\n      </ion-text>\n      <ion-button id=\"btn-register\" shape=\"round\" expand=\"full\" (click)=\"register()\" color=\"primary\">REGISTER</ion-button>\n    </form>\n\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-reset-password/auth-reset-password.component.html":
/*!*******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-reset-password/auth-reset-password.component.html ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content color=\"light\" class=\"ion-text-center\" *ngIf=\"verifySuccess\">\n  <div class=\"div-logo\">\n    <app-branding-logo></app-branding-logo>\n  </div>\n  <div class=\"div-after-logo\">\n    <div class=\"text-split\">\n      <p><b>Reset your password</b></p>\n      <p>Please enter a new password for your account.</p>\n    </div>\n    <form (ngSubmit)=\"resetPassword()\" [formGroup]=\"resetPasswordForm\">\n      <ion-input name=\"username\" formControlName=\"email\" type=\"email\"></ion-input>\n      <ion-list>\n        <ion-item>\n          <ion-input\n            name=\"password\"\n            autocomplete=\"new-password\"\n            inputmode=\"password\"\n            formControlName=\"password\"\n            required\n            [type]=\"showPassword ? 'text' : 'password'\"\n            placeholder=\"Password\" ></ion-input>\n          <ion-button (click)=\"showPassword = !showPassword\" fill=\"clear\">\n            <ion-icon slot=\"end\" [name]=\"showPassword ? 'eye' : 'eye-off'\"></ion-icon>\n          </ion-button>\n        </ion-item>\n        <ion-item>\n          <ion-input\n            name=\"confirmPassword\"\n            autocomplete=\"new-password\"\n            inputmode=\"password\"\n            formControlName=\"confirmPassword\"\n            [type]=\"showPassword ? 'text' : 'password'\"\n            placeholder=\"Verify\"\n            [class.invalid-field]=\"resetPasswordForm.hasError('notMatching') && resetPasswordForm.controls.confirmPassword.value\"></ion-input>\n        </ion-item>\n      </ion-list>\n      <ion-text color=\"danger\" class=\"ion-margin-top\" *ngIf=\"resetPasswordForm.hasError('notMatching') && resetPasswordForm.controls.confirmPassword.value\">\n        Password do not match\n      </ion-text>\n      <br/>\n      <ion-button shape=\"round\" color=\"primary\" [disabled]=\"!resetPasswordForm.valid || isResetting\" type=\"submit\">\n        <ng-container *ngIf=\"!isResetting\">CHANGE PASSWORD</ng-container>\n        <ng-container *ngIf=\"isResetting\">RESETTING...</ng-container>\n      </ion-button>\n    </form>\n    <div class=\"text-split\">\n      <span><ion-text class=\"ion-margin-end\"> Remembered it?</ion-text></span>\n      <a routerLink=\"/login\">Login here</a>\n    </div>\n    <div>\n      <a>Powered by</a><img src=\"/assets/logo.svg\" height=\"25\" class=\"img-inline\">\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/device-info/device-info.component.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/device-info/device-info.component.html ***!
  \**********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content class=\"ion-padding\">\n  <ion-list>\n    <ion-item-divider>\n      <ion-label>\n        General\n      </ion-label>\n    </ion-item-divider>\n    <ion-item>\n      Platform type: {{ platform.platforms() | json }}\n    </ion-item>\n    <ion-item>\n      Current URL: {{ platform.url() }}\n    </ion-item>\n    <ion-item>\n      Height: {{ platform.height() }}\n    </ion-item>\n    <ion-item>\n      Width: {{ platform.width() }}\n    </ion-item>\n  </ion-list>\n  <ion-list>\n    <ion-item-divider>\n      <ion-label>\n        Browser Info\n      </ion-label>\n    </ion-item-divider>\n    <ion-item>\n      is('mobile'): {{ platform.is('mobile') }}\n    </ion-item>\n    <ion-item>\n      Is Mobile: {{ isMobile() }}\n    </ion-item>\n    <ion-item>\n      Agent: {{ navigator.userAgent }}\n    </ion-item>\n    <ion-item>\n      Vendor: {{ navigator.vendor }}\n    </ion-item>\n    <ion-item>\n      Code name: {{ navigator.appCodeName }}\n    </ion-item>\n    <ion-item>\n      Version: {{ navigator.appVersion }}\n    </ion-item>\n    <ion-item>\n      Platform: {{ navigator.platform }}\n    </ion-item>\n  </ion-list>\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/event-detail/event-detail.component.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/event-detail/event-detail.component.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header mode=\"ios\">\n  <ion-toolbar [ngClass]=\"{'ion-toolbar-absolute': !utils.isMobile()}\">\n    <ion-icon *ngIf=\"utils.isMobile()\" name=\"close-circle-outline\" class=\"close-icon\" (click)=\"close()\" color=\"primary\" slot=\"end\"></ion-icon>\n    <ion-title class=\"ion-text-center\" [ngClass]=\"{\n      'subtitle-2': !utils.isMobile()\n    }\">Event</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"light\" [ngClass]=\"{ 'ion-content-absolute': !utils.isMobile() }\">\n  <div class=\"ion-text-center ion-margin\">\n    <h1 class=\"headline-4\">{{ event.name }}</h1>\n    <div class=\"div-activity-name subtitle-1 gray-2\">{{ event.activityName }}</div>\n    <app-description *ngIf=\"event.description\" class=\"body-1\" [content]=\"event.description\"></app-description>\n  </div>\n  <p *ngIf=\"event.isPast && !event.isBooked\" class=\"expired-text ion-margin-horizontal subtitle-2 gray-2\">Event Expired</p>\n\n  <ion-list lines=\"full\">\n    <ion-item>\n      <ion-icon class=\"leading-icon gray-2\" name=\"calendar-outline\"></ion-icon>\n      <div id=\"date\" class=\"subtitle-1\">{{ utils.utcToLocal(event.startTime, 'date') }}</div>\n    </ion-item>\n    <ion-item>\n      <ion-icon class=\"leading-icon gray-2\" name=\"time-outline\"></ion-icon>\n      <div id=\"time\" class=\"subtitle-1\">{{ utils.utcToLocal(event.startTime, 'time') }} - {{ utils.utcToLocal(event.endTime, 'time') }}</div>\n    </ion-item>\n    <ng-container *ngIf=\"event.videoConference\">\n      <ion-item *ngIf=\"!event.isBooked\" class=\"zoom-meeting\">\n        <img src=\"../../assets/icon_zoom_24.svg\">\n        <div class=\"subtitle-1 ion-text-capitalize\"> {{ event.videoConference.provider }} Meeting </div>\n      </ion-item>\n      <ion-item *ngIf=\"event.isBooked\" class=\"zoom-meeting\" (click)=\"openMeetingLink(event.videoConference.url)\">\n        <img src=\"../../assets/icon_zoom_24.svg\">\n        <div class=\"item-content\">\n          <p class=\"subtitle-1\"> Join {{ event.videoConference.provider }} meeting </p>\n          <p class=\"caption gray-2\"> ID: {{ event.videoConference.meetingId }} </p>\n        </div>\n        <ion-icon slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\n      </ion-item>\n    </ng-container>\n    <ion-item *ngIf=\"event.location\">\n      <ion-icon class=\"leading-icon gray-2\" name=\"location-outline\"></ion-icon>\n      <div id=\"location\" class=\"subtitle-1\">{{ event.location }}</div>\n    </ion-item>\n    <ion-item lines=\"none\" *ngIf=\"event.capacity\">\n      <ion-icon class=\"leading-icon gray-2\" name=\"people-outline\"></ion-icon>\n      <div id=\"capacity\" class=\"subtitle-1\">{{ event.remainingCapacity }} Seats Available Out of {{ event.capacity }}</div>\n    </ion-item>\n  </ion-list>\n\n  <div class=\"ion-margin-top ion-text-center\" *ngIf=\"buttonText()\">\n    <ion-button\n      class=\"btn-cta\"\n      (click)=\"confirmed()\"\n      [disabled]=\"(event.isPast && !event.isBooked) || ctaIsActing\"\n      shape=\"round\"\n      [color]=\"event.isPast && !event.isBooked ? 'medium' : 'primary'\">\n      {{ buttonText() }}\n    </ion-button>\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/fast-feedback/fast-feedback.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/fast-feedback/fast-feedback.component.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header mode=\"ios\">\n  <ion-toolbar>\n    <ion-title text-center>Pulse Check</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <div text-center>\n    <p class=\"body-1 ion-margin\">Before you continue, please spend 10 seconds to answer these questions.</p>\n  </div>\n\n  <form (ngSubmit)=\"submit()\" [formGroup]=\"fastFeedbackForm\">\n    <ng-container *ngFor=\"let question of questions\">\n      <question [question]=\"question\" [form]=\"fastFeedbackForm\"></question>\n    </ng-container>\n\n    <div class=\"ion-text-center\">\n      <ion-button type=\"submit\"\n        [disabled]=\"fastFeedbackForm.invalid || loading\"\n        shape=\"round\"\n        class=\"btn-cta\">\n        <ng-container *ngIf=\"!loading\">Submit</ng-container>\n        <ng-container *ngIf=\"loading && !submissionCompleted\">\n          <ion-spinner name=\"dots\"></ion-spinner>\n        </ng-container>\n        <ng-container *ngIf=\"loading && submissionCompleted\">\n          <ion-icon src=\"/assets/checkmark.svg\"></ion-icon>\n        </ng-container>\n      </ion-button>\n    </div>\n  </form>\n\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/fast-feedback/question/question.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/fast-feedback/question/question.component.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-card class=\"practera-card ion-text-left\" [formGroup]=\"form\">\n  <ion-card-header class=\"q-title\">\n    {{ question.title }}\n    <ion-text color=\"danger\" *ngIf=\"question.isRequired\">*</ion-text>\n    <ion-text color=\"medium\"><p><i>{{ question.description }}</i></p></ion-text>\n  </ion-card-header>\n\n  <ion-card-content class=\"q-content ion-padding-horizontal\">\n  <ion-list>\n    <ion-radio-group [formControlName]=\"question.id\">\n      <ion-item *ngFor=\"let choice of question.choices\" color=\"light\">\n        <ion-label class=\"white-space-normal\">{{ choice.title }}</ion-label>\n        <ion-radio [value]=\"choice.id\" mode=\"md\"></ion-radio>\n      </ion-item>\n    </ion-radio-group>\n  </ion-list>\n  </ion-card-content>\n</ion-card>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/go-mobile/go-mobile.component.html":
/*!******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/go-mobile/go-mobile.component.html ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header mode=\"ios\">\n  <ion-toolbar>\n    <ion-title class=\"ion-text-center\">It's 10x better on mobile!</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content class='go-mobile'>\n  <form (ngSubmit)=\"submit()\" >\n  <ion-grid>\n    <div *ngIf=\"profile.contactNumber && saved\">\n      <ion-row class=\"ion-justify-content-center\">\n        <ion-col class=\"glazing-effect ion-align-self-center ion-text-center\">\n          <img src='/assets/img/mobile.png'/>\n          <P>You can now launch Practera on your phone for a better experience. Just click below!</P>\n        </ion-col>\n      </ion-row>\n    </div>\n    <div *ngIf=\"!profile.contactNumber || !saved\">\n      <ion-row class=\"ion-justify-content-center\">\n        <ion-col class=\"glazing-effect ion-align-self-center ion-text-center\">\n          <img src='/assets/img/mobile.png'/>\n          <P>Add your mobile number to get the most out of Practera. We will never send you spam!</P>\n        </ion-col>\n      </ion-row>\n      <app-contact-number-form [page]=\"'go-mobile'\" (updateNumber)=\"updateCountry()\"></app-contact-number-form>\n    </div>\n    <div class=\"ion-text-center\">\n        <ion-button expand=\"block\" type=\"submit\" [disabled]=\"invalidNumber || sendingSMS\">\n          Send Instant-Login via SMS  <ion-spinner *ngIf=\"sendingSMS\"></ion-spinner>\n        </ion-button>\n        <a href=\"/app/home\">not right now...</a>\n    </div>\n  </ion-grid>\n  </form>\n</ion-content>\n\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/page-not-found/page-not-found.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/page-not-found/page-not-found.component.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n  <div class=\"div-logo\" text-center>\n    <h1>Page Not Found</h1>\n  </div>\n  <div class=\"div-after-logo\">\n    <ion-button expand=\"block\" href=\"/app/home\">Go Home</ion-button>\n  </div>\n</ion-content>\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/review-rating/review-rating.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/review-rating/review-rating.component.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content class=\"review-rating ion-padding-horizontal\">\n  <div class=\"header-detail\">\n    <h1 class=\"title\">Rating</h1>\n    <!-- AV2-169 review rating is compulsory -->\n   <!--  <ion-icon class=\"close-button\" name=\"close-circle-outline\" (click)=\"closeReviewRating()\"></ion-icon> -->\n  </div>\n\n  <hr class=\"separator\">\n\n  <h2 class=\"title\">How helpful was the feedback?</h2>\n\n  <div>\n    <ion-range min=\"0\" max=\"1\" step=\"any\" [(ngModel)]=\"ratingData.rating\"></ion-range>\n\n    <div class=\"range-text\">\n      <p>Not helpful</p>\n      <p>Very helpful</p>\n    </div>\n  </div>\n\n  <hr *ngIf=\"ratingData.rating !== 0.5\" class=\"separator\">\n  <h2 *ngIf=\"ratingData.rating !== 0.5\" class=\"subTitle\">Send a quick thank you note!</h2>\n  <div *ngIf=\"ratingData.rating !== 0.5\" class=\"quick-tagging\">\n    <a class=\"toggle\" [class.active]=\"ratingData.tags.includes('Thanks')\" (click)=\"addOrRemoveTags('Thanks')\">Thanks</a>\n    <a class=\"toggle\" [class.active]=\"ratingData.tags.includes('Thank You')\" (click)=\"addOrRemoveTags('Thank You')\">Thank You</a>\n    <a class=\"toggle\" [class.active]=\"ratingData.tags.includes('You are awesome!')\" (click)=\"addOrRemoveTags('You are awesome!')\">You are awesome!</a>\n    <a class=\"toggle\" [class.active]=\"ratingData.tags.includes('Great support')\" (click)=\"addOrRemoveTags('Great support')\">Great support</a>\n    <a class=\"toggle\" [class.active]=\"ratingData.tags.includes('Very helpful')\" (click)=\"addOrRemoveTags('Very helpful')\">Very helpful</a>\n    <a class=\"toggle\" [class.active]=\"ratingData.tags.includes('Friendly')\" (click)=\"addOrRemoveTags('Friendly')\">Friendly</a>\n  </div>\n  <br>\n\n  <ion-input *ngIf=\"ratingData.rating !== 0.5\" placeholder=\"Add a personal thank you\" class=\"comment-box ion-padding-horizontal\" [(ngModel)]=\"ratingData.comment\"></ion-input>\n\n  <br>\n  <div class=\"div-after-logo ion-text-center\">\n    <ion-button\n      [disabled]=\"ratingData.rating === 0.5 || isSubmitting\"\n      (click)=\"submitReviewRating()\"\n      shape=\"round\"\n      class=\"btn-cta\">\n      <ng-container *ngIf=\"!isSubmitting\">Submit</ng-container>\n      <ng-container *ngIf=\"isSubmitting\">Submitting...</ng-container>\n    </ion-button>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/achievement-badge/achievement-badge.component.html":
/*!****************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/achievement-badge/achievement-badge.component.html ***!
  \****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"achievement-badge\">\n  <div class=\"badge\" (click)=\"showAchievementDetails()\">\n    <img [src]=\"achievement.image ? achievement.image : '/assets/achievement.svg'\"\n      [ngClass]=\"{'black-white-image': !achievement.isEarned}\">\n    <ion-icon *ngIf=\"achievement.isEarned\" name=\"checkmark-circle\" color=\"primary\"></ion-icon>\n    <ion-icon *ngIf=\"!achievement.isEarned\" name=\"lock-closed\" color=\"medium\"></ion-icon>\n  </div>\n\n  <div *ngIf=\"showName\" class=\"badge-name body-2\" [ngClass]=\"achievement.isEarned ? 'gray-3' : 'gray-0'\">\n    {{achievement.name}}\n  </div>\n\n  <div *ngIf=\"achievement.points\" class=\"badge-point subtitle-2\"\n    [ngClass]=\"{'badge-point-unearned': !achievement.isEarned, 'desktop' : !utils.isMobile()}\">\n    {{achievement.points}} Points\n  </div>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/activity-card/activity-card.component.html":
/*!********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/activity-card/activity-card.component.html ***!
  \********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-card\n  *ngIf=\"!loading\"\n  color=\"primary\"\n  class=\"card practera-card ion-activatable\"\n  [ngClass]=\"{\n    'loading-card': loading,\n    'locked-card': activity.isLocked,\n    'default-image-card': !activity.leadImage\n  }\"\n  [ngStyle]=\"{'background-image': backgroundImageStyle }\"\n>\n  <ion-card-content>\n    <p color=\"primary-contrast\" class=\"caption\">Activity</p>\n    <p color=\"primary-contrast\" class=\"activity-name headline-6\">{{activity.name}}</p>\n  </ion-card-content>\n</ion-card>\n\n<ion-card\n  *ngIf=\"loading\"\n  class=\"card practera-card skeleton-card\"\n>\n  <ion-card-content>\n    <p class=\"caption\">\n      <ion-skeleton-text animated style=\"width: 20%\"></ion-skeleton-text>\n    </p>\n    <p class=\"activity-name headline-6\">\n      <ion-skeleton-text animated style=\"width: 80%\"></ion-skeleton-text>\n    </p>\n  </ion-card-content>\n</ion-card>\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/branding-logo/branding-logo.component.html":
/*!********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/branding-logo/branding-logo.component.html ***!
  \********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<img [src]=\"storage.getConfig().logo || '/assets/logo.svg'\" width=\"100%\">\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/circle-progress/circle-progress.component.html":
/*!************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/circle-progress/circle-progress.component.html ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ng-container *ngIf=\"!loading\">\n    <circle-progress\n    [animateTitle]='config.animateTitle'\n    [animation]='config.animation'\n    [backgroundColor]='config.backgroundColor'\n    [backgroundPadding]='config.backgroundPadding'\n    [backgroundStroke]='config.backgroundStroke'\n    [backgroundStrokeWidth]='config.backgroundStrokeWidth'\n    [maxPercent]='config.maxPercent'\n    [outerStrokeColor]='config.outerStrokeColor'\n    [outerStrokeLinecap]='config.outerStrokeLinecap'\n    [outerStrokeWidth]='config.outerStrokeWidth'\n    [innerStrokeWidth]='config.innerStrokeWidth'\n    [innerStrokeColor]='config.innerStrokeColor'\n    [percent]='config.percent'\n    [radius]='config.radius'\n    [showInnerStroke]='config.showInnerStroke'\n    [showSubtitle]='config.showSubtitle'\n    [showTitle]='config.showTitle'\n    [showUnits]='config.showUnits'\n    [space]='config.space'\n    [startFromZero]='config.startFromZero'\n    [toFixed]='config.toFixed'\n  ></circle-progress>\n</ng-container>\n<ng-container *ngIf=\"loading\">\n  <div class=\"skeleton\">\n    <ion-skeleton-text animated class=\"progress-circle\" [ngClass]=\"{'desktop' : !utils.isMobile()}\"></ion-skeleton-text>\n    <div class=\"progress-content\" [ngClass]=\"{'desktop' : !utils.isMobile()}\">\n      <div class=\"labels\">\n        <p><ion-skeleton-text animated></ion-skeleton-text></p>\n        <p><ion-skeleton-text animated></ion-skeleton-text></p>\n      </div>\n    </div>\n  </div>\n</ng-container>\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/clickable-item/clickable-item.component.html":
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/clickable-item/clickable-item.component.html ***!
  \**********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-item class=\"ion-activatable\" [lines]=\"lines\" [ngClass]=\"{\n  'switcher-card-item': isSwitcherCard,\n  'active': active\n}\">\n  <ion-text color=\"primary\" [ngStyle]=\"{'color': backgroundColor}\">\n    <ion-ripple-effect></ion-ripple-effect>\n  </ion-text>\n  <ng-content></ng-content>\n</ion-item>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/contact-number-form/contact-number-form.component.html":
/*!********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/contact-number-form/contact-number-form.component.html ***!
  \********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ng-container *ngIf=\"page === 'settings'\">\n  <ion-label class=\"subtitle-2 gray-2\">Contact Number</ion-label>\n  <ion-card class=\"practera-card\" [ngClass]=\"{'desktop-view': !utils.isMobile()}\">\n    <ion-item lines=\"none\">\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"5\">\n            <ion-select class=\"subtitle-1\" [(ngModel)]=\"countryModel\" (ionChange)=\"updateCountry()\">\n              <ion-select-option *ngFor=\"let countryCode of contactNumberFormat.countryCodes\" [value]=\"countryCode.code\">{{countryCode.code}} {{contactNumberFormat.masks[countryCode.code].format}}</ion-select-option>\n            </ion-select>\n          </ion-col>\n          <ion-col>\n            <input type=\"text\"\n              [attr.maxlength]=\"activeCountryModelInfo.length\"\n              pattern=\"{{activeCountryModelInfo.pattern}}\"\n              placeholder=\"{{activeCountryModelInfo.placeholder}}\"\n              [(ngModel)]=\"contactNumber\"\n              class=\"contact-input subtitle-1 gray-1\"\n              (keydown)=\"disableArrowKeys($event)\"\n              (keyup)=\"formatContactNumber()\" />\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-item>\n  </ion-card>\n  <ion-button class=\"practera-btn\" [ngClass]=\"{'mobile-btn': utils.isMobile()}\" [disabled]=\"updating\" (click)=\"updateContactNumber()\">\n    <ng-container *ngIf=\"!updating\">Update</ng-container>\n    <ng-container *ngIf=\"updating\">Updating..</ng-container>\n  </ion-button>\n</ng-container>\n<ng-container *ngIf=\"page === 'go-mobile'\">\n  <ion-item lines=\"none\" class=\"text-field\">\n    <ion-grid>\n      <ion-row class=\"contact-details\">\n        <ion-col size=\"4\">\n          <p class=\"country-code\">{{activeCountryModelInfo.countryCode}}</p>\n        </ion-col>\n        <ion-col>\n          <input type=\"text\"\n            [attr.maxlength]=\"activeCountryModelInfo.length\"\n            pattern=\"{{activeCountryModelInfo.pattern}}\"\n            placeholder=\"{{activeCountryModelInfo.placeholder}}\"\n            [(ngModel)]=\"contactNumber\"\n            class=\"contact-input\"\n            (keydown)=\"disableArrowKeys($event)\"\n            (blur)=\"formatContactNumber()\"\n            (keyup)=\"formatContactNumber()\" />\n        </ion-col>\n        <ion-col size=\"5\">\n          <ion-select placeholder=\"Select Country\"\n            name=\"countryModel\"\n            [(ngModel)]=\"countryModel\"\n            (ionChange)=\"updateCountry()\">\n            <ion-select-option *ngFor=\"let countryCode of contactNumberFormat.countryCodes\" [value]=\"countryCode.code\">\n              {{countryCode.name}}\n            </ion-select-option>\n          </ion-select>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-item>\n</ng-container>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/description/description.component.html":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/description/description.component.html ***!
  \****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container\">\n  <div class=\"text-content\">\n    <p #description [innerHtml]=\"content\"\n      [ngClass]=\"{ 'limit-height': isTruncating || heightExceeded, 'full-height': !isTruncating && !isInPopup, 'full-height-popup': !isTruncating && isInPopup }\">\n    </p>\n  </div>\n\n  <ng-container *ngIf=\"heightExceeded\">\n    <ng-container *ngIf=\"isTruncating\">\n      <ion-button color=\"primary\" fill=\"clear\" (click)=\"isTruncating = !isTruncating\">\n        SHOW MORE\n        <ion-icon slot=\"end\" name=\"arrow-forward\"></ion-icon>\n      </ion-button>\n    </ng-container>\n\n    <ng-container *ngIf=\"!isTruncating\">\n      <ion-button color=\"primary\" fill=\"clear\" (click)=\"isTruncating = !isTruncating\">\n        <ion-icon slot=\"start\" name=\"arrow-back\"></ion-icon>\n        SHOW LESS\n      </ion-button>\n    </ng-container>\n  </ng-container>\n\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/icon/icon.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/icon/icon.component.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<img [src]=\"iconDir\" height=\"25\" />\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/img/img.component.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/img/img.component.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<img [src]=\"imgSrc\" (load)=\"imageLoaded($event)\"/>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/list-item/list-item.component.html":
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/list-item/list-item.component.html ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<clickable-item *ngIf=\"!loading\" [active]=\"active\" [lines]=\"lines\">\n\n  <ion-icon [name]=\"leadingIcon\" slot=\"start\" [color]=\"leadingIconColor || 'primary'\" class=\"leading-icon\" [ngClass]=\"{'pulsing': leadingIconPulsing}\"></ion-icon>\n\n  <div class=\"item-content ion-padding-vertical\" [ngClass]=\"{'content-expired': eventExpired}\">\n    <p class=\"item-title subtitle-3\" [ngClass]=\"'color-' + titleColor\">{{ title }}</p>\n    <p *ngIf=\"subtitle1\" class=\"item-subtitle-1 caption gray-2\" [ngClass]=\"'color-' + subtitle1Color\">{{ subtitle1 }}</p>\n    <p *ngIf=\"subtitle2\" class=\"item-subtitle-2 caption gray-2\">{{ subtitle2 }}</p>\n  </div>\n\n  <ion-text *ngIf=\"endingText\" class=\"item-ending-text caption gray-2\" slot=\"end\">{{ endingText }}</ion-text>\n\n  <ion-icon *ngIf=\"endingIcon\" [name]=\"endingIcon\" slot=\"end\" [color]=\"endingIconColor || 'primary'\"></ion-icon>\n\n  <div *ngIf=\"eventExpired\" class=\"expired-batch gray-2\">Expired</div>\n  <div *ngIf=\"eventVideoConference && !eventExpired\" class=\"video-conference-batch ion-text-capitalize\">{{ eventVideoConference.provider }}</div>\n\n</clickable-item>\n\n<ion-item *ngIf=\"loading\" [lines]=\"lines\">\n  <ion-avatar class=\"skeleton-icon leading-icon\">\n    <ion-skeleton-text animated></ion-skeleton-text>\n  </ion-avatar>\n  <div class=\"item-content ion-padding-vertical\">\n    <p><ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text></p>\n    <p><ion-skeleton-text animated></ion-skeleton-text></p>\n  </div>\n</ion-item>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/unlocking/unlocking.component.html":
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/unlocking/unlocking.component.html ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"contain\">\n  <img class=\"badge\" [src]=\"badgeUrl ? badgeUrl : '/assets/img/sample-badge.png'\">\n  <div class=\"div-svg\">\n    <svg xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" preserveAspectRatio=\"none\" x=\"0px\" y=\"0px\" width=\"350px\" height=\"350px\" viewBox=\"0 0 350 350\">\n    <defs>\n\n    <g>\n      <filter id=\"blur-filter-1\" x=\"-20%\" y=\"-37.69373337726917%\" width=\"140%\" height=\"175.38746675453834%\" color-interpolation-filters=\"sRGB\">\n      <feGaussianBlur in=\"SourceGraphic\" stdDeviation=\"0,13.333333333333334\" result=\"result1\"/>\n      <feColorMatrix in=\"result1\" type=\"matrix\" values=\"1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 0 0\" result=\"result2\"/>\n      </filter>\n\n      <filter id=\"blur-filter-2\" x=\"-20%\" y=\"-33.07832243736631%\" width=\"140%\" height=\"166.15664487473262%\" color-interpolation-filters=\"sRGB\">\n      <feGaussianBlur in=\"SourceGraphic\" stdDeviation=\"0,11.111043294270834\" result=\"result1\"/>\n      <feColorMatrix in=\"result1\" type=\"matrix\" values=\"1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 0.17 0\" result=\"result2\"/>\n      </filter>\n\n      <filter id=\"blur-filter-3\" x=\"-20%\" y=\"-28.46291149746345%\" width=\"140%\" height=\"156.9258229949269%\" color-interpolation-filters=\"sRGB\">\n      <feGaussianBlur in=\"SourceGraphic\" stdDeviation=\"0,8.888956705729166\" result=\"result1\"/>\n      <feColorMatrix in=\"result1\" type=\"matrix\" values=\"1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 0.33 0\" result=\"result2\"/>\n      </filter>\n\n      <filter id=\"blur-filter-4\" x=\"-20%\" y=\"-23.847077978276587%\" width=\"140%\" height=\"147.69415595655317%\" color-interpolation-filters=\"sRGB\">\n      <feGaussianBlur in=\"SourceGraphic\" stdDeviation=\"0,6.666666666666667\" result=\"result1\"/>\n      <feColorMatrix in=\"result1\" type=\"matrix\" values=\"1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 0.5 0\" result=\"result2\"/>\n      </filter>\n\n      <filter id=\"blur-filter-5\" x=\"-20%\" y=\"-20%\" width=\"140%\" height=\"140%\" color-interpolation-filters=\"sRGB\">\n      <feGaussianBlur in=\"SourceGraphic\" stdDeviation=\"0,4.444376627604167\" result=\"result1\"/>\n      <feColorMatrix in=\"result1\" type=\"matrix\" values=\"1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 0.67 0\" result=\"result2\"/>\n      </filter>\n\n      <filter id=\"blur-filter-6\" x=\"-20%\" y=\"-20%\" width=\"140%\" height=\"140%\" color-interpolation-filters=\"sRGB\">\n      <feGaussianBlur in=\"SourceGraphic\" stdDeviation=\"0,2.2222900390625\" result=\"result1\"/>\n      <feColorMatrix in=\"result1\" type=\"matrix\" values=\"1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 0.83 0\" result=\"result2\"/>\n      </filter>\n    </g>\n\n    <g>\n      <g id=\"Lock_move_0_Layer0_0_MEMBER_0_FILL\">\n      <path fill=\"#FFFFFF\" stroke=\"none\" d=\"\n      M 1032 294.1\n      Q 1023.3 291.35 1013.95 291.35 1004.85 291.35 996.7 294 988.5 296.7 982.25 301.7 974.7 307.65 970.8 316.15 966.9 324.65 966.9 335.05\n      L 966.9 455.65\n      Q 966.9 460.45 970.3 463.85 973.65 467.25 978.45 467.25 983.25 467.25 986.65 463.85 990.05 460.45 990.05 455.65\n      L 990.05 335.05\n      Q 990.05 325 996.65 319.75 999.85 317.2 1004.3 315.85 1008.75 314.5 1013.95 314.5 1023.8 314.5 1031.7 319.15 1041.5 324.9 1041.5 335.05\n      L 1041.5 350.8\n      Q 1041.5 355.55 1044.9 358.95 1048.25 362.35 1053.05 362.35 1057.85 362.35 1061.25 358.95 1064.6 355.55 1064.6 350.8\n      L 1064.6 335.05\n      Q 1064.6 325.1 1060.2 316.55 1055.8 308.05 1047.6 301.95 1040.65 296.8 1032 294.1 Z\"/>\n      </g>\n\n      <g id=\"Lock_move_0_Layer0_0_MEMBER_1_FILL\">\n      <path fill=\"#97928A\" stroke=\"none\" d=\"\n      M 1026.3 292.65\n      L 1026.4 292.7\n      Q 1038.9 300.2 1044.85 306.05 1053.2 314.25 1055.8 324.85 1058.5 335.95 1057.9 349.05 1057.55 355.7 1056.4 361.85 1060 360.75 1062.3 357.75 1064.6 354.65 1064.6 350.8\n      L 1064.6 335.05\n      Q 1064.6 325.1 1060.2 316.55 1055.8 308.05 1047.6 301.95 1038.35 295.1 1026.3 292.65 Z\"/>\n      </g>\n\n      <g id=\"Lock_move_0_Layer0_0_MEMBER_2_FILL\">\n      <path fill=\"#97928A\" stroke=\"none\" d=\"\n      M 1020.25 315.1\n      Q 1018.45 311.9 1018.35 311.9 1009.4 310.5 1000.05 313.4 983.2 318.65 983.2 337\n      L 983.2 466.2\n      Q 986.3 464.85 988.15 462 990.05 459.15 990.05 455.65\n      L 990.05 335.05\n      Q 990.05 325 996.65 319.75 999.85 317.2 1004.3 315.85 1008.75 314.5 1013.95 314.5 1016.95 314.5 1020.25 315.1 Z\"/>\n      </g>\n\n      <g id=\"Lock_move_0_Layer0_0_MEMBER_3_MEMBER_0_MEMBER_0_MEMBER_0_FILL\">\n      <path class=\"lock-color\" stroke=\"none\" d=\"\n      M 1051 357\n      Q 1049.3 357 1048 359.4 1047.6 360.4 1047.55 360.5\n      L 1051.45 360.5\n      Q 1054.8 360.5 1057.2 362.75 1059.55 364.95 1059.55 368.2\n      L 1059.55 456.95\n      Q 1059.55 460.2 1057.2 462.4 1054.8 464.65 1051.45 464.65\n      L 1048.3 464.65\n      Q 1049.5 466.5 1051 466.5\n      L 1080.15 466.5\n      Q 1081.9 466.5 1083.15 464.1 1084.35 461.7 1084.35 458.35\n      L 1084.35 365.15\n      Q 1084.35 361.8 1083.15 359.4 1081.9 357 1080.15 357\n      L 1051 357 Z\"/>\n      </g>\n\n      <g id=\"Lock_move_0_Layer0_0_MEMBER_4_MEMBER_0_MEMBER_0_MEMBER_0_FILL\">\n      <path class=\"lock-color\" stroke=\"none\" d=\"\n      M 1046.8 365.15\n      Q 1046.8 362.55 1047.55 360.5\n      L 966.75 360.5\n      Q 963.4 360.5 961 362.75 958.65 365.05 958.65 368.2\n      L 958.65 456.95\n      Q 958.65 460.15 961 462.4 963.4 464.65 966.75 464.65\n      L 1048.3 464.65 1048 464.1\n      Q 1046.8 461.7 1046.8 458.35\n      L 1046.8 365.15 Z\"/>\n      </g>\n\n      <g id=\"Lock_move_0_Layer0_0_MEMBER_4_MEMBER_0_MEMBER_0_MEMBER_1_FILL\">\n      <path class=\"lock-color\" stroke=\"none\" d=\"\n      M 1051.45 360.5\n      L 1047.55 360.5\n      Q 1046.8 362.55 1046.8 365.15\n      L 1046.8 458.35\n      Q 1046.8 461.7 1048 464.1\n      L 1048.3 464.65 1051.45 464.65\n      Q 1054.8 464.65 1057.2 462.4 1059.55 460.2 1059.55 456.95\n      L 1059.55 368.2\n      Q 1059.55 364.95 1057.2 362.75 1054.8 360.5 1051.45 360.5 Z\"/>\n      </g>\n\n      <g id=\"Lock_move_0_Layer0_0_MEMBER_5_MEMBER_0_FILL\">\n      <path fill=\"#161616\" stroke=\"none\" d=\"\n      M 1000.2 295.1\n      Q 1001.2 295.75 1002.35 295.5 1007.85 294.25 1013.95 294.25 1022.85 294.25 1031.1 296.85 1039.35 299.4 1045.85 304.25 1053.25 309.75 1057.3 317.25 1058.15 318.8 1059.85 318.8 1060.6 318.8 1061.25 318.45 1062.3 317.9 1062.65 316.75 1062.95 315.6 1062.4 314.55 1057.75 305.85 1049.3 299.6 1042 294.25 1032.9 291.35 1023.7 288.45 1013.95 288.45 1007.55 288.45 1001.15 289.85 999.95 290.05 999.3 291.1 998.65 292.05 998.9 293.25 999.15 294.45 1000.2 295.1 Z\"/>\n      </g>\n\n      <g id=\"Lock_move_0_Layer0_0_MEMBER_5_MEMBER_1_FILL\">\n      <path fill=\"#161616\" stroke=\"none\" d=\"\n      M 1061.15 322.4\n      Q 1060.3 323.25 1060.3 324.45 1060.3 325.65 1061.15 326.5 1062 327.35 1063.2 327.35 1064.4 327.35 1065.25 326.5 1066.1 325.65 1066.1 324.45 1066.1 323.25 1065.25 322.4 1064.4 321.55 1063.2 321.55 1062 321.55 1061.15 322.4 Z\"/>\n      </g>\n\n      <g id=\"Lock_move_0_Layer0_0_MEMBER_5_MEMBER_2_FILL\">\n      <path fill=\"#161616\" stroke=\"none\" d=\"\n      M 993.2 293.05\n      Q 992.1 292.6 991 293.1 984.95 295.75 980.45 299.4 972.4 305.85 968.2 314.9 964 324 964 335.05\n      L 964 353.55 956.35 353.55\n      Q 951.05 353.55 947.3 357.3 943.55 361.05 943.55 366.4\n      L 943.55 458.8\n      Q 943.55 464.1 947.3 467.85 951.05 471.6 956.35 471.6\n      L 1075.05 471.6\n      Q 1080.3 471.6 1084.05 467.85 1087.85 464.15 1087.85 458.8\n      L 1087.85 438\n      Q 1087.85 436.6 1086.8 435.55 1085.8 434.55 1084.35 434.55 1083 434.55 1081.9 435.55 1080.9 436.65 1080.9 438\n      L 1080.9 458.8\n      Q 1080.9 461.15 1079.2 462.95 1077.5 464.65 1075.05 464.65\n      L 956.35 464.65\n      Q 953.9 464.65 952.25 462.95 950.5 461.25 950.5 458.8\n      L 950.5 366.4\n      Q 950.5 363.95 952.25 362.2 953.9 360.5 956.35 360.5\n      L 1075.05 360.5\n      Q 1077.5 360.5 1079.2 362.2 1080.9 364.05 1080.9 366.4\n      L 1080.9 398.9\n      Q 1080.9 400.3 1081.9 401.4 1083 402.4 1084.35 402.4 1085.8 402.4 1086.8 401.4 1087.85 400.35 1087.85 398.9\n      L 1087.85 366.4\n      Q 1087.85 361.05 1084.05 357.3 1080.3 353.55 1075.05 353.55\n      L 1067.25 353.55\n      Q 1067.5 352.05 1067.5 350.8\n      L 1067.5 333.65\n      Q 1067.45 332.45 1066.6 331.65 1065.75 330.8 1064.6 330.8\n      L 1064.5 330.8\n      Q 1063.3 330.85 1062.5 331.7 1061.65 332.6 1061.7 333.8\n      L 1061.75 350.8\n      Q 1061.75 351.95 1061.3 353.55\n      L 1044.8 353.55\n      Q 1044.4 352.1 1044.4 350.8\n      L 1044.4 335.05\n      Q 1044.4 323.45 1033.6 316.9 1024.8 311.6 1013.95 311.6 1008.3 311.6 1003.35 313.15 998.45 314.65 994.85 317.5 988 323 987.25 332.5 987.15 333.7 987.9 334.6 988.7 335.55 989.9 335.65 991.1 335.75 992 334.95 992.95 334.2 993 333 993.6 325.95 998.45 322.05 1004.25 317.4 1013.95 317.4 1017.7 317.4 1021.75 318.35 1026.55 319.45 1030.25 321.65 1038.6 326.55 1038.6 335.05\n      L 1038.6 350.8\n      Q 1038.6 352.05 1038.85 353.55\n      L 992.95 353.55 992.95 341.85\n      Q 992.95 340.65 992.1 339.8 991.25 338.95 990.05 338.95 988.85 338.95 988 339.8 987.15 340.65 987.15 341.85\n      L 987.15 353.55 969.8 353.55 969.8 335.05\n      Q 969.8 325.35 973.4 317.45 977.05 309.5 984.05 303.95 988.15 300.7 993.3 298.4 994.4 297.9 994.85 296.8 995.3 295.7 994.8 294.6 994.3 293.5 993.2 293.05 Z\"/>\n      </g>\n\n      <g id=\"Lock_move_0_Layer0_0_MEMBER_5_MEMBER_3_FILL\">\n      <path fill=\"#161616\" stroke=\"none\" d=\"\n      M 1087.85 411.75\n      Q 1087.85 410.35 1086.8 409.3 1085.8 408.3 1084.35 408.3 1083 408.3 1081.9 409.3 1080.9 410.4 1080.9 411.75\n      L 1080.9 425.6\n      Q 1080.9 426.95 1081.9 428.05 1083 429.05 1084.35 429.05 1085.8 429.05 1086.8 428.05 1087.85 427 1087.85 425.6\n      L 1087.85 411.75 Z\"/>\n      </g>\n\n      <g id=\"Lock_move_0_Layer0_0_MEMBER_6_MEMBER_0_MEMBER_0_MEMBER_0_FILL\">\n      <path fill=\"#FFFFFF\" stroke=\"none\" d=\"\n      M 1022.35 400.8\n      Q 1019.6 398.05 1015.7 398.05 1011.8 398.05 1009.05 400.8 1006.3 403.55 1006.3 407.45 1006.3 409.9 1007.5 412 1008.6 414 1010.6 415.3\n      L 1008.7 427.1 1022.5 427.1 1020.7 415.4\n      Q 1022.7 414.15 1023.85 412 1025.1 409.8 1025.1 407.45 1025.1 403.65 1022.35 400.8 Z\"/>\n      </g>\n    </g>\n\n    <g>\n      <g id=\"Lock_hook_0_Layer0_0_FILL\">\n      <path fill=\"#FFFFFF\" stroke=\"none\" d=\"\n      M 353.45 116.75\n      Q 341.5 107.9 326.5 103.2 311.45 98.45 295.3 98.45 279.65 98.45 265.5 103.05 251.35 107.65 240.5 116.3 227.5 126.65 220.75 141.35 214 156.05 214 174\n      L 214 382.5\n      Q 214 390.8 219.85 396.65 225.7 402.5 234 402.5 242.25 402.5 248.15 396.65 254 390.8 254 382.5\n      L 254 174\n      Q 254 156.65 265.45 147.55 270.95 143.15 278.65 140.8 286.4 138.45 295.3 138.45 312.3 138.45 326 146.5 342.9 156.45 342.9 174\n      L 342.9 201.2\n      Q 342.9 209.5 348.75 215.35 354.6 221.2 362.9 221.2 371.2 221.2 377.05 215.35 382.9 209.5 382.9 201.2\n      L 382.9 174\n      Q 382.9 156.85 375.3 142.05 367.7 127.3 353.45 116.75 Z\"/>\n      </g>\n\n      <g id=\"Lock_hook_0_Layer0_1_FILL\">\n      <path fill=\"#97928A\" stroke=\"none\" d=\"\n      M 375.3 142.05\n      Q 367.7 127.3 353.45 116.75 337.5 104.95 316.7 100.65\n      L 316.85 100.75\n      Q 338.4 113.75 348.7 123.85 363.15 138.05 367.65 156.35 372.35 175.55 371.25 198.15 370.7 209.85 368.7 220.35 374.95 218.45 378.9 213.2 382.9 207.85 382.9 201.2\n      L 382.9 174\n      Q 382.9 156.85 375.3 142.05 Z\"/>\n      </g>\n\n      <g id=\"Lock_hook_0_Layer0_2_FILL\">\n      <path fill=\"#97928A\" stroke=\"none\" d=\"\n      M 304.5 136.6\n      Q 303 133.95 302.9 133.95 298.75 133.3 292.05 133.45 280.7 133.65 271.35 136.6 242.2 145.7 242.2 177.35\n      L 242.2 400.7\n      Q 247.5 398.3 250.7 393.45 254 388.5 254 382.5\n      L 254 174\n      Q 254 156.65 265.45 147.55 270.95 143.15 278.65 140.8 286.4 138.45 295.3 138.45 300.35 138.45 306.25 139.45 306.1 139.3 304.5 136.6 Z\"/>\n      </g>\n\n      <g id=\"Lock_hook_0_Layer0_3_MEMBER_0_FILL\">\n      <path fill=\"#191919\" stroke=\"none\" d=\"\n      M 237.4 112.4\n      Q 223.45 123.5 216.25 139.2 209 154.85 209 174\n      L 209 382.5\n      Q 209 392.8 216.35 400.15 223.65 407.5 234 407.5 244.3 407.5 251.65 400.15 259 392.8 259 382.5\n      L 259 185.75\n      Q 259 183.7 257.55 182.2 256.05 180.75 254 180.75 251.9 180.75 250.45 182.2 249 183.7 249 185.75\n      L 249 382.5\n      Q 249 388.7 244.6 393.1 240.2 397.5 234 397.5 227.8 397.5 223.4 393.1 219 388.7 219 382.5\n      L 219 174\n      Q 219 157.25 225.25 143.55 231.55 129.85 243.6 120.2 250.65 114.6 259.65 110.6 261.55 109.8 262.3 107.85 263.05 105.95 262.2 104.05 261.4 102.15 259.45 101.4 257.55 100.6 255.65 101.45 245.4 105.95 237.4 112.4 Z\"/>\n      </g>\n\n      <g id=\"Lock_hook_0_Layer0_3_MEMBER_1_FILL\">\n      <path fill=\"#191919\" stroke=\"none\" d=\"\n      M 387.9 171.5\n      Q 387.85 169.5 386.35 168.05 384.9 166.65 382.9 166.65\n      L 382.75 166.65\n      Q 380.65 166.75 379.25 168.25 377.85 169.75 377.9 171.8\n      L 377.9 201.2\n      Q 377.9 207.4 373.5 211.8 369.1 216.2 362.9 216.2 356.7 216.2 352.3 211.8 347.9 207.4 347.9 201.2\n      L 347.9 174\n      Q 347.9 154 329.25 142.65 314.1 133.45 295.3 133.45 285.55 133.45 277 136.1 268.5 138.75 262.3 143.65 250.5 153.05 249.15 169.6 248.95 171.65 250.35 173.25 251.7 174.85 253.75 175 255.8 175.2 257.4 173.85 258.95 172.45 259.1 170.4 260.05 158.2 268.55 151.5 273.4 147.6 280.35 145.55 287.25 143.45 295.3 143.45 301.8 143.45 308.8 145.1 317.1 147.05 323.5 150.85 337.9 159.3 337.9 174\n      L 337.9 201.2\n      Q 337.9 211.5 345.25 218.85 352.6 226.2 362.9 226.2 373.25 226.2 380.6 218.85 387.9 211.5 387.9 201.2\n      L 387.9 171.5 Z\"/>\n      </g>\n\n      <g id=\"Lock_hook_0_Layer0_3_MEMBER_2_FILL\">\n      <path fill=\"#191919\" stroke=\"none\" d=\"\n      M 374.7 145.9\n      Q 375.95 145.9 377.05 145.3 378.9 144.3 379.5 142.3 380.1 140.35 379.1 138.5 370.9 123.4 356.45 112.75 343.85 103.4 328.05 98.45 312.25 93.45 295.3 93.45 284 93.45 273.15 95.8 271.1 96.25 270 98 268.9 99.75 269.35 101.75 269.8 103.75 271.55 104.9 273.25 106 275.3 105.6 284.85 103.45 295.3 103.45 310.65 103.45 324.95 107.9 339.15 112.4 350.5 120.75 363.25 130.25 370.3 143.25 370.95 144.5 372.15 145.2 373.35 145.9 374.7 145.9 Z\"/>\n      </g>\n\n      <g id=\"Lock_hook_0_Layer0_3_MEMBER_3_FILL\">\n      <path fill=\"#191919\" stroke=\"none\" d=\"\n      M 385.45 155.65\n      Q 385.45 153.6 384 152.1 382.5 150.65 380.45 150.65 378.4 150.65 376.9 152.1 375.45 153.6 375.45 155.65 375.45 157.75 376.9 159.2 378.4 160.65 380.45 160.65 382.5 160.65 384 159.2 385.45 157.75 385.45 155.65 Z\"/>\n      </g>\n\n      <g id=\"Lock_body_0_Layer0_0_MEMBER_0_MEMBER_0_MEMBER_0_FILL\">\n      <path class=\"lock-color\" stroke=\"none\" d=\"\n      M 414.95 439.3\n      Q 412.75 435.2 409.8 435.2\n      L 359.35 435.2\n      Q 356.35 435.2 354.2 439.3 352.1 443.5 352.1 449.25\n      L 352.1 610.4\n      Q 352.1 616.25 354.2 620.35 356.3 624.45 359.35 624.45\n      L 409.8 624.45\n      Q 412.8 624.45 414.95 620.35 417.05 616.25 417.05 610.4\n      L 417.05 449.25\n      Q 417.05 443.5 414.95 439.3 Z\"/>\n      </g>\n\n      <g id=\"Lock_body_0_Layer0_1_MEMBER_0_MEMBER_0_MEMBER_0_FILL\">\n      <path class=\"lock-color\" stroke=\"none\" d=\"\n      M 213.75 441.2\n      Q 207.95 441.2 203.8 445.1 199.7 449.15 199.7 454.6\n      L 199.7 607.95\n      Q 199.7 613.45 203.8 617.4 207.95 621.3 213.75 621.3\n      L 360.15 621.3\n      Q 366 621.3 370.1 617.4 374.2 613.55 374.2 607.95\n      L 374.2 454.6\n      Q 374.2 449.05 370.1 445.1 366 441.2 360.15 441.2\n      L 213.75 441.2 Z\"/>\n      </g>\n\n      <g id=\"Lock_body_0_Layer0_2_MEMBER_0_MEMBER_0_MEMBER_0_FILL\">\n      <path fill=\"#161616\" stroke=\"none\" d=\"\n      M 188.6 444.2\n      Q 191.6 441.2 195.75 441.2\n      L 400.9 441.2\n      Q 405.1 441.2 408.1 444.2 411.05 447.25 411.05 451.4\n      L 411.05 507.65\n      Q 411.05 510.15 412.8 511.9 414.55 513.65 417.05 513.65 419.6 513.65 421.3 511.9 423.05 510.15 423.05 507.65\n      L 423.05 451.4\n      Q 423.05 442.2 416.55 435.7 410 429.2 400.9 429.2\n      L 195.75 429.2\n      Q 186.7 429.2 180.1 435.7 173.6 442.3 173.6 451.4\n      L 173.6 611.15\n      Q 173.6 620.3 180.1 626.8 186.6 633.3 195.75 633.3\n      L 400.9 633.3\n      Q 410.05 633.3 416.55 626.8 423.05 620.4 423.05 611.15\n      L 423.05 575.25\n      Q 423.05 572.85 421.3 571 419.55 569.25 417.05 569.25 414.65 569.25 412.8 571 411.05 572.85 411.05 575.25\n      L 411.05 611.15\n      Q 411.05 615.35 408.1 618.35 405.15 621.3 400.9 621.3\n      L 195.75 621.3\n      Q 191.55 621.3 188.6 618.35 185.6 615.35 185.6 611.15\n      L 185.6 451.4\n      Q 185.6 447.2 188.6 444.2 Z\"/>\n      </g>\n\n      <g id=\"Lock_body_0_Layer0_3_MEMBER_0_MEMBER_0_MEMBER_0_FILL\">\n      <path fill=\"#161616\" stroke=\"none\" d=\"\n      M 412.8 525.6\n      Q 411.05 527.45 411.05 529.85\n      L 411.05 553.75\n      Q 411.05 556.25 412.8 558 414.5 559.75 417.05 559.75 419.6 559.75 421.3 558 423.05 556.25 423.05 553.75\n      L 423.05 529.85\n      Q 423.05 527.45 421.3 525.6 419.55 523.85 417.05 523.85 414.55 523.85 412.8 525.6 Z\"/>\n      </g>\n\n      <g id=\"Lock_body_0_Layer0_4_MEMBER_0_MEMBER_0_MEMBER_0_FILL\">\n      <path fill=\"#FFFFFF\" stroke=\"none\" d=\"\n      M 298.35 506.15\n      Q 291.6 506.15 286.85 510.9 282.1 515.75 282.1 522.35 282.1 526.6 284.15 530.25 286.15 533.8 289.55 536\n      L 286.2 556.4 310.1 556.4 306.95 536.1\n      Q 310.4 534 312.45 530.3 314.55 526.65 314.55 522.35 314.55 515.75 309.8 510.9 305.05 506.15 298.35 506.15 Z\"/>\n      </g>\n\n      <g id=\"Mask_Square_7_1_MASK_0_FILL\">\n      <path fill=\"#FFFFFF\" stroke=\"none\" d=\"\n      M -18.9 -16.65\n      L -50.9 -16.65 -50.9 19.7 -18.9 19.7 -18.9 -16.65 Z\"/>\n      </g>\n    </g>\n\n    <g id=\"Square_67_Layer2_0_FILL\">\n      <path id=\"checkbox-68\" class=\"lock-color\" fill-opacity=\"0.00784313725490196\" stroke=\"none\" d=\"\n      M 5.65 -5.65\n      Q 3.3 -8 0 -8 -3.3 -8 -5.65 -5.65 -8 -3.3 -8 0 -8 3.3 -5.65 5.65 -3.3 8 0 8 3.3 8 5.65 5.65 8 3.3 8 0 8 -3.3 5.65 -5.65 Z\"/>\n      <path id=\"checkbox-69\" class=\"lock-color\" fill-opacity=\"0.17254901960784313\" stroke=\"none\" d=\"\n      M 6.95 -6.95\n      Q 4.05 -9.85 0 -9.85 -4.05 -9.85 -6.95 -6.95 -9.85 -4.05 -9.85 0 -9.85 4.05 -6.95 6.95 -4.05 9.85 0 9.85 4.05 9.85 6.95 6.95 9.85 4.05 9.85 0 9.85 -4.05 6.95 -6.95 Z\"/>\n      <path id=\"checkbox-70\" class=\"lock-color\" fill-opacity=\"0.33725490196078434\" stroke=\"none\" d=\"\n      M 8.25 -8.25\n      Q 4.8 -11.65 0 -11.65 -4.8 -11.65 -8.25 -8.25 -11.65 -4.8 -11.65 0 -11.65 4.8 -8.25 8.25 -4.8 11.65 0 11.65 4.8 11.65 8.25 8.25 11.65 4.8 11.65 0 11.65 -4.8 8.25 -8.25 Z\"/>\n      <path id=\"checkbox-71\" class=\"lock-color\" fill-opacity=\"0.5058823529411764\" stroke=\"none\" d=\"\n      M 9.55 -9.55\n      Q 5.6 -13.5 0 -13.5 -5.55 -13.5 -9.55 -9.55 -13.5 -5.55 -13.5 0 -13.5 5.6 -9.55 9.55 -5.55 13.5 0 13.5 5.6 13.5 9.55 9.55 13.5 5.6 13.5 0 13.5 -5.55 9.55 -9.55 Z\"/>\n      <path id=\"checkbox-72\" class=\"lock-color\" fill-opacity=\"0.6705882352941176\" stroke=\"none\" d=\"\n      M 10.8 -10.85\n      Q 6.35 -15.35 0 -15.35 -6.35 -15.35 -10.85 -10.85 -15.35 -6.35 -15.35 0 -15.35 6.35 -10.85 10.8 -6.35 15.35 0 15.35 6.35 15.35 10.8 10.8 15.35 6.35 15.35 0 15.35 -6.35 10.8 -10.85 Z\"/>\n      <path id=\"checkbox-73\" class=\"lock-color\" fill-opacity=\"0.8352941176470589\" stroke=\"none\" d=\"\n      M 12.1 -12.15\n      Q 7.1 -17.15 0 -17.15 -7.1 -17.15 -12.15 -12.15 -17.15 -7.1 -17.15 0 -17.15 7.1 -12.15 12.1 -7.1 17.15 0 17.15 7.1 17.15 12.1 12.1 17.15 7.1 17.15 0 17.15 -7.1 12.1 -12.15 Z\"/>\n      <path id=\"checkbox-74\" class=\"lock-color\" stroke=\"none\" d=\"\n      M 13.4 -13.45\n      Q 7.85 -19 0 -19 -7.85 -19 -13.45 -13.45 -19 -7.85 -19 0 -19 7.85 -13.45 13.4 -7.85 19 0 19 7.85 19 13.4 13.4 19 7.85 19 0 19 -7.85 13.4 -13.45 Z\"/>\n      <path class=\"checkbox-75 lock-color\" stroke=\"none\" d=\"\n      M 21.6 -16.55\n      Q 18.85 -24.4 9.85 -24.4 -3.9 -24.4 -16.55 -21.6 -24.4 -18.8 -24.4 -9.85 -24.4 3.95 -21.6 16.55 -18.8 24.4 -9.85 24.4 3.95 24.4 16.55 21.6 24.4 18.85 24.4 9.85 24.4 -3.9 21.6 -16.55 Z\"/>\n      <path class=\"checkbox-border-final\" fill=\"#FFFFFF\" stroke=\"none\" d=\"\n      M -108.4 144\n      Q -108.4 132 -120.4 132\n      L -167.2 132\n      Q -179.2 132 -179.2 144\n      L -179.2 190.8\n      Q -179.2 202.8 -167.2 202.8\n      L -120.4 202.8\n      Q -108.4 202.8 -108.4 190.8\n      L -108.4 144 Z\"/>\n    </g>\n\n    <g id=\"Mask_Mask_Tween_3_0_Layer0_0_FILL\">\n      <path fill=\"#FFFFFF\" stroke=\"none\" d=\"\n      M 16 18.2\n      L 16 -18.15 -16 -18.15 -16 18.2 16 18.2 Z\"/>\n    </g>\n    <g id=\"Tween_1_0_Layer0_0_FILL\">\n      <path class=\"lock-color\" stroke=\"none\" d=\"\n      M 1299 288.4\n      Q 1298.05 287.5 1296.95 287.4 1295.85 287.3 1295.1 288 1294.35 288.7 1294.45 289.75 1294.5 290.85 1295.4 291.75\n      L 1300.8 297\n      Q 1301.7 297.9 1303 297.85 1304.1 297.95 1305.15 296.65\n      L 1316.6 282.15\n      Q 1317.55 280.95 1317.4 279.9 1317.3 278.85 1316.2 278.25 1314.3 277.1 1312.6 279.25 1305.5 288.1 1303.65 290.55 1303 291.35 1302.5 291.4 1302 291.4 1301.35 290.65 1300.35 289.55 1299 288.4 Z\"/>\n    </g>\n    <path id=\"Square_74_Layer2_0_1_STROKES\" stroke=\"#135967\" stroke-opacity=\"0.5019607843137255\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" fill=\"none\" d=\"\n    M -24.4 -9.85\n    Q -24.4 -18.8 -16.55 -21.6 -3.9 -24.4 9.85 -24.4 18.85 -24.4 21.6 -16.55 24.4 -3.9 24.4 9.85 24.4 18.85 16.55 21.6 3.95 24.4 -9.85 24.4 -18.8 24.4 -21.6 16.55 -24.4 3.95 -24.4 -9.85 Z\"/>\n    <path class=\"lock-color-stroke\" id=\"Square_75_Layer2_0_1_STROKES\" stroke-width=\"6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" fill=\"none\" d=\"\n    M -19.698437499999997 -29.782812500000006\n    L 19.697656249999994 -29.782812500000006\n    Q 29.799218749999994 -29.782812500000006 29.799218749999994 -19.681250000000006\n    L 29.799218749999994 19.71484375\n    Q 29.799218749999994 29.81640625 19.697656249999994 29.81640625\n    L -19.698437499999997 29.81640625\n    Q -29.799999999999997 29.81640625 -29.799999999999997 19.71484375\n    L -29.799999999999997 -19.681250000000006\n    Q -29.799999999999997 -29.782812500000006 -19.698437499999997 -29.782812500000006 Z\"/>\n    </defs>\n\n    <g transform=\"matrix( 0.83843994140625, 0, 0, 0.83843994140625, 200,85.85) \">\n    <g class=\"blur-only\">\n      <g class=\"blur-filter\" transform=\"matrix( 1.19268798828125, 0, 0, 1.19268798828125, -238.5,-102.35)\">\n      <g class=\"blur-lock\">\n      <g transform=\"matrix( 1, 0, 0, 1, -1015.7,-380) \">\n      <use xlink:href=\"#Lock_move_0_Layer0_0_MEMBER_0_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 1, 0, 0, 1, -1015.7,-380) \">\n      <use xlink:href=\"#Lock_move_0_Layer0_0_MEMBER_1_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 1, 0, 0, 1, -1015.7,-380) \">\n      <use xlink:href=\"#Lock_move_0_Layer0_0_MEMBER_2_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 1, 0, 0, 1, -1015.7,-380) \">\n      <use xlink:href=\"#Lock_move_0_Layer0_0_MEMBER_3_MEMBER_0_MEMBER_0_MEMBER_0_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 1, 0, 0, 1, -1015.7,-380) \">\n      <use xlink:href=\"#Lock_move_0_Layer0_0_MEMBER_4_MEMBER_0_MEMBER_0_MEMBER_0_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 1, 0, 0, 1, -1015.7,-380) \">\n      <use xlink:href=\"#Lock_move_0_Layer0_0_MEMBER_4_MEMBER_0_MEMBER_0_MEMBER_1_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 1, 0, 0, 1, -1015.7,-380) \">\n      <use xlink:href=\"#Lock_move_0_Layer0_0_MEMBER_5_MEMBER_0_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 1, 0, 0, 1, -1015.7,-380) \">\n      <use xlink:href=\"#Lock_move_0_Layer0_0_MEMBER_5_MEMBER_1_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 1, 0, 0, 1, -1015.7,-380) \">\n      <use xlink:href=\"#Lock_move_0_Layer0_0_MEMBER_5_MEMBER_2_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 1, 0, 0, 1, -1015.7,-380) \">\n      <use xlink:href=\"#Lock_move_0_Layer0_0_MEMBER_5_MEMBER_3_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 1, 0, 0, 1, -1015.7,-380) \">\n      <use xlink:href=\"#Lock_move_0_Layer0_0_MEMBER_6_MEMBER_0_MEMBER_0_MEMBER_0_FILL\"/>\n      </g>\n      </g>\n      </g>\n    </g>\n\n    <g class=\"lock-only\">\n      <g class=\"lock-head\">\n      <g transform=\"matrix( 0.583160400390625, 0, 0, 0.583160400390625, -174.05,-146.1) \">\n      <use xlink:href=\"#Lock_hook_0_Layer0_0_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 0.583160400390625, 0, 0, 0.583160400390625, -174.05,-146.1) \">\n      <use xlink:href=\"#Lock_hook_0_Layer0_1_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 0.583160400390625, 0, 0, 0.583160400390625, -174.05,-146.1) \">\n      <use xlink:href=\"#Lock_hook_0_Layer0_2_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 0.5830535888671875, 0, 0, 0.5830535888671875, -174.05,-146.1) \">\n      <use xlink:href=\"#Lock_hook_0_Layer0_3_MEMBER_0_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 0.5830535888671875, 0, 0, 0.5830535888671875, -174.05,-146.1) \">\n      <use xlink:href=\"#Lock_hook_0_Layer0_3_MEMBER_1_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 0.5830535888671875, 0, 0, 0.5830535888671875, -174.05,-146.1) \">\n      <use xlink:href=\"#Lock_hook_0_Layer0_3_MEMBER_2_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 0.5830535888671875, 0, 0, 0.5830535888671875, -174.05,-146.1) \">\n      <use xlink:href=\"#Lock_hook_0_Layer0_3_MEMBER_3_FILL\"/>\n      </g>\n      </g>\n\n      <g class=\"lock-body\">\n      <g transform=\"matrix( 0.5828399658203125, 0, 0, 0.5828399658203125, -173.95,-309.75) \">\n      <use xlink:href=\"#Lock_body_0_Layer0_0_MEMBER_0_MEMBER_0_MEMBER_0_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 0.5828399658203125, 0, 0, 0.6056060791015625, -173.95,-321.8) \">\n      <use xlink:href=\"#Lock_body_0_Layer0_1_MEMBER_0_MEMBER_0_MEMBER_0_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 0.5828399658203125, 0, 0, 0.5828399658203125, -173.95,-309.75) \">\n      <use xlink:href=\"#Lock_body_0_Layer0_2_MEMBER_0_MEMBER_0_MEMBER_0_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 0.5828399658203125, 0, 0, 0.5828399658203125, -173.95,-309.75) \">\n      <use xlink:href=\"#Lock_body_0_Layer0_3_MEMBER_0_MEMBER_0_MEMBER_0_FILL\"/>\n      </g>\n\n      <g transform=\"matrix( 0.5828399658203125, 0, 0, 0.5828399658203125, -173.95,-309.75) \">\n      <use xlink:href=\"#Lock_body_0_Layer0_4_MEMBER_0_MEMBER_0_MEMBER_0_FILL\"/>\n      </g>\n      </g>\n    </g>\n    </g>\n\n    <g transform=\"matrix( 1.01104736328125, 0, 0, 1.01104736328125, 116.25,215.5) \">\n      <g class=\"checkbox-only\" transform=\"matrix( 1, 0, 0, 1, 0,0) \">\n        <use xlink:href=\"#Square_67_Layer2_0_FILL\"/>\n        <use class=\"checkbox-75\" xlink:href=\"#Square_74_Layer2_0_1_STROKES\"/>\n        <use class=\"checkbox-border-final\" xlink:href=\"#Square_75_Layer2_0_1_STROKES\"/>\n      </g>\n\n      <mask id=\"Mask_Mask_1\">\n        <g class=\"checkbox-check\">\n          <g transform=\"matrix( 1, 0, 0, 1, 0,0) \">\n          <use xlink:href=\"#Mask_Mask_Tween_3_0_Layer0_0_FILL\"/>\n          </g>\n        </g>\n      </mask>\n\n      <g mask=\"url(#Mask_Mask_1)\">\n        <g class=\"checkbox-check-final\">\n          <g transform=\"matrix( 1, 0, 0, 1, 0,0) \">\n          <g transform=\"matrix( 1.391845703125, 0, 0, 1.3948974609375, -1817.65,-401.5) \">\n          <use xlink:href=\"#Tween_1_0_Layer0_0_FILL\"/>\n          </g>\n          </g>\n        </g>\n      </g>\n    </g>\n    </svg>\n  </div>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/notification/achievement-pop-up/achievement-pop-up.component.html":
/*!********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/notification/achievement-pop-up/achievement-pop-up.component.html ***!
  \********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content color=\"light\" class=\"pop-up-content\" [ngClass]=\"{'desktop-view': !utils.isMobile()}\" text-center>\n\n  <div class=\"image-content\">\n    <div class=\"image\">\n        <img alt=\"{{achievement.name}}\" [src]=\"achievement.image ? achievement.image : '/assets/achievement-popup-default.svg'\">\n    </div>\n  </div>\n\n  <div class=\"details-container ion-text-center\">\n    <div class=\"div-after-img\" *ngIf=\"type === 'notification'\">\n      <p class=\"headline-6\">Congratulations</p>\n      <p class=\"body-1\">You have earned a new badge</p>\n      <div class=\"description subtitle-1 gray-2\" *ngIf=\"achievement.name\">{{achievement.name}}</div>\n    </div>\n\n    <div class=\"div-after-img\" *ngIf=\"type !== 'notification'\">\n      <p class=\"headline-6\" *ngIf=\"achievement.name\">{{achievement.name}}</p>\n      <p class=\"body-1\" *ngIf=\"achievement.points && type !== 'notification'\">{{achievement.points}} points!</p>\n    </div>\n\n    <ion-text color=\"medium\" *ngIf=\"achievement.description\" text-center>\n      <app-description *ngIf=\"achievement.description\" class=\"body-1 gray-2\" [content]=\"achievement.description\" [isInPopup]=\"true\"></app-description>\n    </ion-text>\n\n    <div class=\"div-after-img button-container\">\n      <ion-button (click)=\"confirmed()\" shape=\"round\" color=\"primary\" expand=\"full\">OK</ion-button>\n    </div>\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/notification/activity-complete-pop-up/activity-complete-pop-up.component.html":
/*!********************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/notification/activity-complete-pop-up/activity-complete-pop-up.component.html ***!
  \********************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content class=\"ion-text-center\" [ngClass]=\"{'desktop-view': !utils.isMobile()}\">\n  <p class=\"ion-margin\">\n    You have remaining tasks in the current activity. Would you like to review them before progressing?\n  </p>\n\n  <div class=\"fixed-bottom\">\n    <ion-button (click)=\"confirmed(false)\" fill=\"clear\" color=\"primary\" expand=\"full\">REVIEW TASKS</ion-button>\n    <hr>\n    <ion-button (click)=\"confirmed(true)\" fill=\"clear\" color=\"primary\" expand=\"full\">CONTINUE</ion-button>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/notification/lock-team-assessment-pop-up/lock-team-assessment-pop-up.component.html":
/*!**************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/notification/lock-team-assessment-pop-up/lock-team-assessment-pop-up.component.html ***!
  \**************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content color=\"light\" class=\"pop-up-content\" [ngClass]=\"{'desktop-view': !utils.isMobile()}\" text-center>\n\n  <div class=\"image-content\">\n    <div class=\"image\">\n        <img alt=\"{{ name }}\" [src]=\"image ? image : 'https://my.practera.com/img/user-512.png'\">\n    </div>\n  </div>\n\n  <div class=\"details-container\">\n    <div class=\"div-after-img\">\n      <div class=\"description body-1\" *ngIf=\"name\">\n        <b>{{ name }}</b> <span class=\"gray-2\">is currently edting this team submission. Click on</span> <b>'View Read Only'</b> <span class=\"gray-2\">to open in read only mode</span>.\n      </div>\n    </div>\n\n    <div class=\"div-after-img button-container\">\n      <ion-button (click)=\"confirmed()\" shape=\"round\" color=\"primary\" expand=\"full\">View Read Only</ion-button>\n    </div>\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/notification/pop-up/pop-up.component.html":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/notification/pop-up/pop-up.component.html ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content color=\"light\" text-center>\n  <ng-container [ngSwitch]=\"type\">\n\n    <ng-container *ngSwitchCase=\"'forgotPasswordConfirmation'\">\n      <div class=\"div-logo\"></div>\n      <div class=\"div-after-logo\">\n        <p>We have sent an email to \"<i>{{ data.email }}</i>\" with a link to log into the system - please check your inbox. </p>\n        <p>If you haven't received an email in a few minutes, please make sure the email you entered is correct and check your spam folder. Thank you.</p>\n      </div>\n    </ng-container>\n\n    <ng-container *ngSwitchCase=\"'shortMessage'\">\n      <div class=\"div-logo\"></div>\n      <div class=\"div-after-logo\" text-left>\n        <p id=\"popup-message\" [innerHtml]=\"data.message\"></p>\n      </div>\n    </ng-container>\n\n  </ng-container>\n  <div class=\"div-after-logo\">\n    <ion-button id=\"btn-popup-confirm\" (click)=\"confirmed()\" shape=\"round\" color=\"primary\" expand=\"full\">OK</ion-button>\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"../chat/chat.module": [
		"./src/app/chat/chat.module.ts",
		"default~assessment-assessment-module~chat-chat-module~events-events-module~reviews-reviews-module~se~abd5c3d3",
		"chat-chat-module"
	],
	"../events/events.module": [
		"./src/app/events/events.module.ts",
		"default~assessment-assessment-module~chat-chat-module~events-events-module~reviews-reviews-module~se~abd5c3d3",
		"default~assessment-assessment-module~events-events-module~reviews-reviews-module~tasks-tasks-module~~277a831e",
		"default~assessment-assessment-module~events-events-module~reviews-reviews-module~tasks-tasks-module",
		"events-events-module"
	],
	"../overview/overview.module": [
		"./src/app/overview/overview.module.ts",
		"overview-overview-module"
	],
	"../reviews/reviews.module": [
		"./src/app/reviews/reviews.module.ts",
		"default~assessment-assessment-module~chat-chat-module~events-events-module~reviews-reviews-module~se~abd5c3d3",
		"default~assessment-assessment-module~events-events-module~reviews-reviews-module~tasks-tasks-module~~277a831e",
		"default~assessment-assessment-module~events-events-module~reviews-reviews-module~tasks-tasks-module",
		"reviews-reviews-module"
	],
	"../settings/settings.module": [
		"./src/app/settings/settings.module.ts",
		"default~assessment-assessment-module~chat-chat-module~events-events-module~reviews-reviews-module~se~abd5c3d3",
		"settings-settings-module"
	],
	"../tasks/tasks.module": [
		"./src/app/tasks/tasks.module.ts",
		"default~assessment-assessment-module~chat-chat-module~events-events-module~reviews-reviews-module~se~abd5c3d3",
		"default~assessment-assessment-module~events-events-module~reviews-reviews-module~tasks-tasks-module~~277a831e",
		"default~assessment-assessment-module~events-events-module~reviews-reviews-module~tasks-tasks-module",
		"default~tasks-tasks-module~topic-topic-module",
		"tasks-tasks-module"
	],
	"./achievements/achievements.module": [
		"./src/app/achievements/achievements.module.ts",
		"achievements-achievements-module"
	],
	"./assessment/assessment.module": [
		"./src/app/assessment/assessment.module.ts",
		"default~assessment-assessment-module~chat-chat-module~events-events-module~reviews-reviews-module~se~abd5c3d3",
		"default~assessment-assessment-module~events-events-module~reviews-reviews-module~tasks-tasks-module~~277a831e",
		"default~assessment-assessment-module~events-events-module~reviews-reviews-module~tasks-tasks-module"
	],
	"./chat/chat.module": [
		"./src/app/chat/chat.module.ts",
		"default~assessment-assessment-module~chat-chat-module~events-events-module~reviews-reviews-module~se~abd5c3d3",
		"chat-chat-module"
	],
	"./switcher/switcher.module": [
		"./src/app/switcher/switcher.module.ts",
		"switcher-switcher-module"
	],
	"./tabs/tabs.module": [
		"./src/app/tabs/tabs.module.ts",
		"tabs-tabs-module"
	],
	"./topic/topic.module": [
		"./src/app/topic/topic.module.ts",
		"default~assessment-assessment-module~chat-chat-module~events-events-module~reviews-reviews-module~se~abd5c3d3",
		"default~assessment-assessment-module~events-events-module~reviews-reviews-module~tasks-tasks-module~~277a831e",
		"default~tasks-tasks-module~topic-topic-module"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/achievements/achievements.service.ts":
/*!******************************************************!*\
  !*** ./src/app/achievements/achievements.service.ts ***!
  \******************************************************/
/*! exports provided: AchievementsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AchievementsService", function() { return AchievementsService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _shared_request_request_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @shared/request/request.service */ "./src/app/shared/request/request.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};





/**
 * @name api
 * @description list of api endpoint involved in this service
 * @type {Object}
 */
var api = {
    get: {
        achievements: 'api/v2/motivations/achievement/list.json'
    },
    post: {
        todoItem: 'api/v2/motivations/todo_item/edit.json'
    }
};
var AchievementsService = /** @class */ (function () {
    function AchievementsService(request, utils, storage) {
        this.request = request;
        this.utils = utils;
        this.storage = storage;
        this.earnedPoints = 0;
        this.totalPoints = 0;
        this.isPointsConfigured = false;
    }
    AchievementsService.prototype.getAchievements = function (order) {
        var _this = this;
        if (!order) {
            order = 'asc';
        }
        return this.request.get(api.get.achievements, { params: {
                order: order
            } })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(function (response) {
            return _this._normaliseAchievements(response.data);
        }));
    };
    AchievementsService.prototype._normaliseAchievements = function (data) {
        var _this = this;
        if (!Array.isArray(data)) {
            return this.request.apiResponseFormatError('Achievement format error');
        }
        this.earnedPoints = 0;
        this.totalPoints = 0;
        this.isPointsConfigured = false;
        var achievements = [];
        data.forEach(function (achievement) {
            if (!_this.utils.has(achievement, 'id') ||
                !_this.utils.has(achievement, 'name') ||
                !_this.utils.has(achievement, 'description') ||
                !_this.utils.has(achievement, 'badge') ||
                !_this.utils.has(achievement, 'points') ||
                !_this.utils.has(achievement, 'isEarned') ||
                !_this.utils.has(achievement, 'earnedDate')) {
                return _this.request.apiResponseFormatError('Achievement object format error');
            }
            achievements.push({
                id: achievement.id,
                name: achievement.name,
                description: achievement.description,
                points: achievement.points,
                image: achievement.badge,
                isEarned: achievement.isEarned,
                earnedDate: achievement.earnedDate,
            });
            if (achievement.points) {
                _this.totalPoints += +achievement.points;
                _this.isPointsConfigured = true;
                if (achievement.isEarned) {
                    _this.earnedPoints += +achievement.points;
                }
            }
        });
        return achievements;
    };
    AchievementsService.prototype.getEarnedPoints = function () {
        return this.earnedPoints;
    };
    AchievementsService.prototype.getTotalPoints = function () {
        return this.totalPoints;
    };
    AchievementsService.prototype.getIsPointsConfigured = function () {
        return this.isPointsConfigured;
    };
    AchievementsService.prototype.markAchievementAsSeen = function (achievementId) {
        var postData = {
            project_id: this.storage.getUser().projectId,
            identifier: 'Achievement-' + achievementId,
            is_done: true
        };
        return this.request.post(api.post.todoItem, postData).subscribe();
    };
    AchievementsService.ctorParameters = function () { return [
        { type: _shared_request_request_service__WEBPACK_IMPORTED_MODULE_2__["RequestService"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_3__["UtilsService"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_4__["BrowserStorageService"] }
    ]; };
    AchievementsService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_shared_request_request_service__WEBPACK_IMPORTED_MODULE_2__["RequestService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_3__["UtilsService"],
            _services_storage_service__WEBPACK_IMPORTED_MODULE_4__["BrowserStorageService"]])
    ], AchievementsService);
    return AchievementsService;
}());



/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _go_mobile_go_mobile_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./go-mobile/go-mobile.component */ "./src/app/go-mobile/go-mobile.component.ts");
/* harmony import */ var _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./page-not-found/page-not-found.component */ "./src/app/page-not-found/page-not-found.component.ts");
/* harmony import */ var _fast_feedback_fast_feedback_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./fast-feedback/fast-feedback.component */ "./src/app/fast-feedback/fast-feedback.component.ts");
/* harmony import */ var _device_info_device_info_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./device-info/device-info.component */ "./src/app/device-info/device-info.component.ts");
/* harmony import */ var _auth_auth_guard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./auth/auth.guard */ "./src/app/auth/auth.guard.ts");
/* harmony import */ var _auth_program_selected_guard__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./auth/program-selected.guard */ "./src/app/auth/program-selected.guard.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};








var routes = [
    {
        path: 'go-mobile',
        component: _go_mobile_go_mobile_component__WEBPACK_IMPORTED_MODULE_2__["GoMobileComponent"],
        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_6__["AuthGuard"]],
    },
    {
        path: 'switcher',
        loadChildren: './switcher/switcher.module#SwitcherModule',
        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_6__["AuthGuard"]]
    },
    {
        path: 'topic',
        loadChildren: './topic/topic.module#TopicModule',
        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_6__["AuthGuard"]]
    },
    {
        path: 'assessment',
        loadChildren: './assessment/assessment.module#AssessmentModule',
        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_6__["AuthGuard"]]
    },
    {
        path: 'achievements',
        loadChildren: './achievements/achievements.module#AchievementsModule',
        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_6__["AuthGuard"]]
    },
    {
        path: 'fast-feedback',
        component: _fast_feedback_fast_feedback_component__WEBPACK_IMPORTED_MODULE_4__["FastFeedbackComponent"],
        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_6__["AuthGuard"]]
    },
    {
        path: 'chat',
        loadChildren: './chat/chat.module#ChatModule',
        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_6__["AuthGuard"]]
    },
    {
        path: 'device-info',
        component: _device_info_device_info_component__WEBPACK_IMPORTED_MODULE_5__["DeviceInfoComponent"],
    },
    {
        path: '',
        loadChildren: './tabs/tabs.module#TabsModule',
        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_6__["AuthGuard"]],
        canActivate: [_auth_program_selected_guard__WEBPACK_IMPORTED_MODULE_7__["ProgramSelectedGuard"]],
    },
    {
        path: '',
        redirectTo: '/app',
        pathMatch: 'full',
        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_6__["AuthGuard"]]
    },
    { path: '**', component: _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_3__["PageNotFoundComponent"] },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes, {
                    enableTracing: false,
                    scrollPositionRestoration: 'enabled',
                    anchorScrolling: 'enabled',
                })],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm5/ionic-angular.js");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _services_shared_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @services/shared.service */ "./src/app/services/shared.service.ts");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./auth/auth.service */ "./src/app/auth/auth.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _services_version_check_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @services/version-check.service */ "./src/app/services/version-check.service.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _shared_pusher_pusher_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @shared/pusher/pusher.service */ "./src/app/shared/pusher/pusher.service.ts");
/* harmony import */ var _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @shared/new-relic/new-relic.service */ "./src/app/shared/new-relic/new-relic.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};











var AppComponent = /** @class */ (function () {
    function AppComponent(platform, router, utils, sharedService, authService, storage, versionCheckService, pusherService, ngZone, newRelic
    // private splashScreen: SplashScreen,
    // private statusBar: StatusBar
    ) {
        this.platform = platform;
        this.router = router;
        this.utils = utils;
        this.sharedService = sharedService;
        this.authService = authService;
        this.storage = storage;
        this.versionCheckService = versionCheckService;
        this.pusherService = pusherService;
        this.ngZone = ngZone;
        this.newRelic = newRelic;
        this.initializeApp();
    }
    // force every navigation happen under radar of angular
    AppComponent.prototype.navigate = function (direction) {
        var _this = this;
        return this.ngZone.run(function () {
            return _this.router.navigate(direction);
        });
    };
    AppComponent.prototype.configVerification = function () {
        if (this.storage.get('fastFeedbackOpening')) { // set default modal status
            this.storage.set('fastFeedbackOpening', false);
        }
    };
    AppComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.configVerification();
        this.sharedService.onPageLoad();
        // @TODO: need to build a new micro service to get the config and serve the custom branding config from a microservice
        // Get the custom branding info and update the theme color if needed
        var domain = window.location.hostname;
        this.authService.getConfig({ domain: domain }).subscribe(function (response) {
            if (response !== null) {
                var expConfig = response.data;
                var numOfConfigs = expConfig.length;
                if (numOfConfigs > 0 && numOfConfigs < 2) {
                    var logo = expConfig[0].logo;
                    var themeColor = expConfig[0].config.theme_color;
                    // add the domain if the logo url is not a full url
                    if (!logo.includes('http') && !_this.utils.isEmpty(logo)) {
                        logo = _environments_environment__WEBPACK_IMPORTED_MODULE_8__["environment"].APIEndpoint + logo;
                    }
                    _this.storage.setConfig({
                        'logo': logo,
                        'color': themeColor
                    });
                    // use brand color if no theme color
                    if (!_this.utils.has(_this.storage.getUser(), 'themeColor') || !_this.storage.getUser().themeColor) {
                        _this.utils.changeThemeColor(themeColor);
                    }
                }
            }
        }, function (err) {
            _this.newRelic.noticeError("" + JSON.stringify(err));
        });
        var searchParams = null;
        var queryString = '';
        if (window.location.search) {
            queryString = window.location.search.substring(1);
        }
        else if (window.location.hash) {
            queryString = window.location.hash.substring(2);
        }
        searchParams = new URLSearchParams(queryString);
        if (searchParams.has('do')) {
            switch (searchParams.get('do')) {
                case 'secure':
                    if (searchParams.has('auth_token')) {
                        var queries = this.utils.urlQueryToObject(queryString);
                        this.navigate([
                            'secure',
                            searchParams.get('auth_token'),
                            queries
                        ]);
                    }
                    break;
                case 'resetpassword':
                    if (searchParams.has('key') && searchParams.has('email')) {
                        this.navigate([
                            'reset_password',
                            searchParams.get('key'),
                            searchParams.get('email')
                        ]);
                    }
                    break;
                case 'registration':
                    if (searchParams.has('key') && searchParams.has('email')) {
                        this.navigate([
                            'registration',
                            searchParams.get('email'),
                            searchParams.get('key')
                        ]);
                    }
                    break;
            }
        }
    };
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (_environments_environment__WEBPACK_IMPORTED_MODULE_8__["environment"].production) {
                            // watch version update
                            this.versionCheckService.initiateVersionCheck();
                        }
                        // initialise Pusher
                        return [4 /*yield*/, this.pusherService.initialise()];
                    case 1:
                        // initialise Pusher
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        }); });
    };
    AppComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_3__["UtilsService"] },
        { type: _services_shared_service__WEBPACK_IMPORTED_MODULE_4__["SharedService"] },
        { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_6__["BrowserStorageService"] },
        { type: _services_version_check_service__WEBPACK_IMPORTED_MODULE_7__["VersionCheckService"] },
        { type: _shared_pusher_pusher_service__WEBPACK_IMPORTED_MODULE_9__["PusherService"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"] },
        { type: _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_10__["NewRelicService"] }
    ]; };
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __importDefault(__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_3__["UtilsService"],
            _services_shared_service__WEBPACK_IMPORTED_MODULE_4__["SharedService"],
            _auth_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"],
            _services_storage_service__WEBPACK_IMPORTED_MODULE_6__["BrowserStorageService"],
            _services_version_check_service__WEBPACK_IMPORTED_MODULE_7__["VersionCheckService"],
            _shared_pusher_pusher_service__WEBPACK_IMPORTED_MODULE_9__["PusherService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"],
            _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_10__["NewRelicService"]
            // private splashScreen: SplashScreen,
            // private statusBar: StatusBar
        ])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm5/ionic-angular.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _shared_request_request_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @shared/request/request.module */ "./src/app/shared/request/request.module.ts");
/* harmony import */ var _shared_new_relic_new_relic_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @shared/new-relic/new-relic.module */ "./src/app/shared/new-relic/new-relic.module.ts");
/* harmony import */ var _shared_notification_notification_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @shared/notification/notification.module */ "./src/app/shared/notification/notification.module.ts");
/* harmony import */ var _auth_auth_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./auth/auth.module */ "./src/app/auth/auth.module.ts");
/* harmony import */ var _fast_feedback_fast_feedback_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./fast-feedback/fast-feedback.module */ "./src/app/fast-feedback/fast-feedback.module.ts");
/* harmony import */ var _review_rating_review_rating_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./review-rating/review-rating.module */ "./src/app/review-rating/review-rating.module.ts");
/* harmony import */ var _event_detail_event_detail_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./event-detail/event-detail.module */ "./src/app/event-detail/event-detail.module.ts");
/* harmony import */ var _go_mobile_go_mobile_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./go-mobile/go-mobile.module */ "./src/app/go-mobile/go-mobile.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _services_version_check_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./services/version-check.service */ "./src/app/services/version-check.service.ts");
/* harmony import */ var _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./page-not-found/page-not-found.component */ "./src/app/page-not-found/page-not-found.component.ts");
/* harmony import */ var ngx_embed_video__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ngx-embed-video */ "./node_modules/ngx-embed-video/__ivy_ngcc__/dist/index.js");
/* harmony import */ var ngx_embed_video__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(ngx_embed_video__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var ng_intercom__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ng-intercom */ "./node_modules/ng-intercom/__ivy_ngcc__/fesm5/ng-intercom.js");
/* harmony import */ var _shared_pusher_pusher_module__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @shared/pusher/pusher.module */ "./src/app/shared/pusher/pusher.module.ts");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm5/animations.js");
/* harmony import */ var _components_unlocking_unlocking_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @components/unlocking/unlocking.component */ "./src/app/shared/components/unlocking/unlocking.component.ts");
/* harmony import */ var _shared_components_icon_icon_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @shared/components/icon/icon.component */ "./src/app/shared/components/icon/icon.component.ts");
/* harmony import */ var _device_info_device_info_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./device-info/device-info.component */ "./src/app/device-info/device-info.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

























var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_13__["AppComponent"],
                _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_16__["PageNotFoundComponent"],
                _components_unlocking_unlocking_component__WEBPACK_IMPORTED_MODULE_22__["UnlockingComponent"],
                _shared_components_icon_icon_component__WEBPACK_IMPORTED_MODULE_23__["IconComponent"],
                _device_info_device_info_component__WEBPACK_IMPORTED_MODULE_24__["DeviceInfoComponent"],
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_21__["BrowserAnimationsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"].forRoot(),
                _auth_auth_module__WEBPACK_IMPORTED_MODULE_8__["AuthModule"],
                _shared_request_request_module__WEBPACK_IMPORTED_MODULE_5__["RequestModule"].forRoot({
                    appkey: _environments_environment__WEBPACK_IMPORTED_MODULE_18__["environment"].appkey,
                    prefixUrl: _environments_environment__WEBPACK_IMPORTED_MODULE_18__["environment"].APIEndpoint,
                }),
                _app_routing_module__WEBPACK_IMPORTED_MODULE_4__["AppRoutingModule"],
                ngx_embed_video__WEBPACK_IMPORTED_MODULE_17__["EmbedVideo"].forRoot(),
                _shared_new_relic_new_relic_module__WEBPACK_IMPORTED_MODULE_6__["NewRelicModule"].forRoot(),
                _shared_notification_notification_module__WEBPACK_IMPORTED_MODULE_7__["NotificationModule"],
                _fast_feedback_fast_feedback_module__WEBPACK_IMPORTED_MODULE_9__["FastFeedbackModule"],
                _go_mobile_go_mobile_module__WEBPACK_IMPORTED_MODULE_12__["GoMobileModule"],
                _review_rating_review_rating_module__WEBPACK_IMPORTED_MODULE_10__["ReviewRatingModule"],
                _event_detail_event_detail_module__WEBPACK_IMPORTED_MODULE_11__["EventDetailModule"],
                _shared_pusher_pusher_module__WEBPACK_IMPORTED_MODULE_20__["PusherModule"].forRoot({
                    apiurl: _environments_environment__WEBPACK_IMPORTED_MODULE_18__["environment"].APIEndpoint,
                    pusherKey: _environments_environment__WEBPACK_IMPORTED_MODULE_18__["environment"].pusherKey,
                }),
                ng_intercom__WEBPACK_IMPORTED_MODULE_19__["IntercomModule"].forRoot({
                    appId: _environments_environment__WEBPACK_IMPORTED_MODULE_18__["environment"].intercomAppId,
                    updateOnRouterChange: true // will automatically run `update` on router event changes. Default: `false`
                })
            ],
            providers: [
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicRouteStrategy"] },
                // Custom
                _services_utils_service__WEBPACK_IMPORTED_MODULE_14__["UtilsService"],
                _services_version_check_service__WEBPACK_IMPORTED_MODULE_15__["VersionCheckService"],
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_13__["AppComponent"]],
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/auth/auth-direct-login/auth-direct-login.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/auth/auth-direct-login/auth-direct-login.component.ts ***!
  \***********************************************************************/
/*! exports provided: AuthDirectLoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthDirectLoginComponent", function() { return AuthDirectLoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth/auth.service.ts");
/* harmony import */ var _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @shared/notification/notification.service */ "./src/app/shared/notification/notification.service.ts");
/* harmony import */ var _switcher_switcher_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../switcher/switcher.service */ "./src/app/switcher/switcher.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @shared/new-relic/new-relic.service */ "./src/app/shared/new-relic/new-relic.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};








var AuthDirectLoginComponent = /** @class */ (function () {
    function AuthDirectLoginComponent(router, route, authService, notificationService, utils, switcherService, storage, ngZone, newRelic) {
        this.router = router;
        this.route = route;
        this.authService = authService;
        this.notificationService = notificationService;
        this.utils = utils;
        this.switcherService = switcherService;
        this.storage = storage;
        this.ngZone = ngZone;
        this.newRelic = newRelic;
    }
    AuthDirectLoginComponent.prototype.ngOnInit = function () {
        return __awaiter(this, void 0, void 0, function () {
            var authToken, nrDirectLoginTracer, err_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.newRelic.setPageViewName('direct-login');
                        authToken = this.route.snapshot.paramMap.get('authToken');
                        if (!authToken) {
                            return [2 /*return*/, this._error()];
                        }
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 4, , 5]);
                        nrDirectLoginTracer = this.newRelic.createTracer('Processing direct login');
                        return [4 /*yield*/, this.authService.directLogin({ authToken: authToken }).toPromise()];
                    case 2:
                        _a.sent();
                        return [4 /*yield*/, this.switcherService.getMyInfo().toPromise()];
                    case 3:
                        _a.sent();
                        nrDirectLoginTracer();
                        return [2 /*return*/, this._redirect()];
                    case 4:
                        err_1 = _a.sent();
                        this._error(err_1);
                        return [3 /*break*/, 5];
                    case 5: return [2 /*return*/];
                }
            });
        });
    };
    // force every navigation happen under radar of angular
    AuthDirectLoginComponent.prototype.navigate = function (direction) {
        var _this = this;
        return this.ngZone.run(function () {
            _this.newRelic.setCustomAttribute('redirection', direction);
            return _this.router.navigate(direction);
        });
    };
    /**
     * Redirect user to a specific page if data is passed in, otherwise redirect to program switcher page
     */
    AuthDirectLoginComponent.prototype._redirect = function (redirectLater) {
        return __awaiter(this, void 0, void 0, function () {
            var redirect, timelineId, activityId, contextId, assessmentId, submissionId, program;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        redirect = this.route.snapshot.paramMap.get('redirect');
                        timelineId = +this.route.snapshot.paramMap.get('tl');
                        activityId = +this.route.snapshot.paramMap.get('act');
                        contextId = +this.route.snapshot.paramMap.get('ctxt');
                        assessmentId = +this.route.snapshot.paramMap.get('asmt');
                        submissionId = +this.route.snapshot.paramMap.get('sm');
                        // clear the cached data
                        this.utils.clearCache();
                        if (!redirect || !timelineId) {
                            // if there's no redirection or timeline id
                            return [2 /*return*/, this._saveOrRedirect(['switcher', 'switcher-program'], redirectLater)];
                        }
                        if (this.route.snapshot.paramMap.has('return_url')) {
                            this.storage.setUser({
                                LtiReturnUrl: this.route.snapshot.paramMap.get('return_url')
                            });
                        }
                        if (!!redirectLater) return [3 /*break*/, 2];
                        program = this.utils.find(this.storage.get('programs'), function (value) {
                            return value.timeline.id === timelineId;
                        });
                        if (this.utils.isEmpty(program)) {
                            // if the timeline id is not found
                            return [2 /*return*/, this._saveOrRedirect(['switcher', 'switcher-program'])];
                        }
                        // switch to the program
                        return [4 /*yield*/, this.switcherService.switchProgram(program).toPromise()];
                    case 1:
                        // switch to the program
                        _a.sent();
                        _a.label = 2;
                    case 2:
                        switch (redirect) {
                            case 'home':
                                return [2 /*return*/, this._saveOrRedirect(['app', 'home'], redirectLater)];
                            case 'project':
                                return [2 /*return*/, this._saveOrRedirect(['app', 'home'], redirectLater)];
                            case 'activity':
                                if (!activityId) {
                                    return [2 /*return*/, this._saveOrRedirect(['app', 'home'], redirectLater)];
                                }
                                return [2 /*return*/, this._saveOrRedirect(['app', 'activity', activityId], redirectLater)];
                            case 'assessment':
                                if (!activityId || !contextId || !assessmentId) {
                                    return [2 /*return*/, this._saveOrRedirect(['app', 'home'], redirectLater)];
                                }
                                if (this.utils.isMobile()) {
                                    return [2 /*return*/, this._saveOrRedirect(['assessment', 'assessment', activityId, contextId, assessmentId], redirectLater)];
                                }
                                else {
                                    return [2 /*return*/, this._saveOrRedirect(['app', 'activity', activityId, { task: 'assessment', task_id: assessmentId, context_id: contextId }], redirectLater)];
                                }
                            case 'reviews':
                                return [2 /*return*/, this._saveOrRedirect(['app', 'reviews'], redirectLater)];
                            case 'review':
                                if (!contextId || !assessmentId || !submissionId) {
                                    return [2 /*return*/, this._saveOrRedirect(['app', 'home'], redirectLater)];
                                }
                                return [2 /*return*/, this._saveOrRedirect(['assessment', 'review', contextId, assessmentId, submissionId], redirectLater)];
                            case 'chat':
                                return [2 /*return*/, this._saveOrRedirect(['app', 'chat'], redirectLater)];
                            case 'settings':
                                return [2 /*return*/, this._saveOrRedirect(['app', 'settings'], redirectLater)];
                            default:
                                return [2 /*return*/, this._saveOrRedirect(['app', 'home'], redirectLater)];
                        }
                        return [2 /*return*/, this._saveOrRedirect(['app', 'home'], redirectLater)];
                }
            });
        });
    };
    AuthDirectLoginComponent.prototype._saveOrRedirect = function (route, save) {
        if (save === void 0) { save = false; }
        if (save) {
            return this.storage.set('directLinkRoute', route);
        }
        return this.navigate(route);
    };
    AuthDirectLoginComponent.prototype._error = function (res) {
        var _this = this;
        this.newRelic.noticeError('failed direct login', res ? JSON.stringify(res) : undefined);
        if (!this.utils.isEmpty(res) && res.status === 'forbidden' && [
            'User is not registered'
        ].includes(res.data.message)) {
            this._redirect(true);
            return this.navigate(['registration', res.data.user.email, res.data.user.key]);
        }
        return this.notificationService.alert({
            message: 'Your link is invalid or expired.',
            buttons: [
                {
                    text: 'OK',
                    role: 'cancel',
                    handler: function () {
                        _this.navigate(['login']);
                    }
                }
            ]
        });
    };
    AuthDirectLoginComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"] },
        { type: _auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] },
        { type: _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_5__["UtilsService"] },
        { type: _switcher_switcher_service__WEBPACK_IMPORTED_MODULE_4__["SwitcherService"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_6__["BrowserStorageService"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"] },
        { type: _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_7__["NewRelicService"] }
    ]; };
    AuthDirectLoginComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-auth-direct-login',
            template: __importDefault(__webpack_require__(/*! raw-loader!./auth-direct-login.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-direct-login/auth-direct-login.component.html")).default,
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"],
            _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_5__["UtilsService"],
            _switcher_switcher_service__WEBPACK_IMPORTED_MODULE_4__["SwitcherService"],
            _services_storage_service__WEBPACK_IMPORTED_MODULE_6__["BrowserStorageService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"],
            _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_7__["NewRelicService"]])
    ], AuthDirectLoginComponent);
    return AuthDirectLoginComponent;
}());



/***/ }),

/***/ "./src/app/auth/auth-forgot-password/auth-forgot-password.component.scss":
/*!*******************************************************************************!*\
  !*** ./src/app/auth/auth-forgot-password/auth-forgot-password.component.scss ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2F1dGgvYXV0aC1mb3Jnb3QtcGFzc3dvcmQvYXV0aC1mb3Jnb3QtcGFzc3dvcmQuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/auth/auth-forgot-password/auth-forgot-password.component.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/auth/auth-forgot-password/auth-forgot-password.component.ts ***!
  \*****************************************************************************/
/*! exports provided: AuthForgotPasswordComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthForgotPasswordComponent", function() { return AuthForgotPasswordComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @shared/notification/notification.service */ "./src/app/shared/notification/notification.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth/auth.service.ts");
/* harmony import */ var _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @shared/new-relic/new-relic.service */ "./src/app/shared/new-relic/new-relic.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};





var AuthForgotPasswordComponent = /** @class */ (function () {
    function AuthForgotPasswordComponent(notificationService, authService, utils, newRelic) {
        this.notificationService = notificationService;
        this.authService = authService;
        this.utils = utils;
        this.newRelic = newRelic;
        this.email = '';
        // variable to control the label of the button
        this.isSending = false;
    }
    AuthForgotPasswordComponent.prototype.send = function () {
        return __awaiter(this, void 0, void 0, function () {
            var nrForgotpasswordTracer;
            var _this = this;
            return __generator(this, function (_a) {
                // basic validation
                if (this.email.length < 0 || !this.email) {
                    this.newRelic.actionText('email missing');
                    return [2 /*return*/, this.notificationService.presentToast('Please enter email')];
                }
                this.isSending = true;
                nrForgotpasswordTracer = this.newRelic.createTracer('API Request: forgot-password');
                this.authService.forgotPassword(this.email).subscribe(function (res) {
                    nrForgotpasswordTracer();
                    _this.newRelic.actionText('forgot password request sent');
                    _this.isSending = false;
                    // show pop up message for confirmation
                    return _this.notificationService.popUp('forgotPasswordConfirmation', {
                        email: _this.email
                    }, ['/login']);
                }, function (err) {
                    nrForgotpasswordTracer();
                    _this.newRelic.noticeError("Password Reset Error", JSON.stringify(err));
                    _this.isSending = false;
                    if (_this.utils.has(err, 'data.type')) {
                        // pop up if trying to reset password too frequently
                        if (err.data.type === 'reset_too_frequently') {
                            return _this.notificationService.alert({
                                message: "Please wait 2 minutes before attempting to reset your password again",
                                buttons: [
                                    {
                                        text: 'OK',
                                        role: 'cancel'
                                    }
                                ],
                            });
                        }
                    }
                    return _this.notificationService.presentToast('Issue occured. Please try again');
                });
                return [2 /*return*/];
            });
        });
    };
    AuthForgotPasswordComponent.ctorParameters = function () { return [
        { type: _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_1__["NotificationService"] },
        { type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilsService"] },
        { type: _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_4__["NewRelicService"] }
    ]; };
    AuthForgotPasswordComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-auth-forgot-password',
            template: __importDefault(__webpack_require__(/*! raw-loader!./auth-forgot-password.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-forgot-password/auth-forgot-password.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./auth-forgot-password.component.scss */ "./src/app/auth/auth-forgot-password/auth-forgot-password.component.scss")).default]
        }),
        __metadata("design:paramtypes", [_shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_1__["NotificationService"],
            _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilsService"],
            _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_4__["NewRelicService"]])
    ], AuthForgotPasswordComponent);
    return AuthForgotPasswordComponent;
}());



/***/ }),

/***/ "./src/app/auth/auth-login/auth-login.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/auth/auth-login/auth-login.component.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2F1dGgvYXV0aC1sb2dpbi9hdXRoLWxvZ2luLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/auth/auth-login/auth-login.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/auth/auth-login/auth-login.component.ts ***!
  \*********************************************************/
/*! exports provided: AuthLoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthLoginComponent", function() { return AuthLoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth/auth.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @shared/notification/notification.service */ "./src/app/shared/notification/notification.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @shared/new-relic/new-relic.service */ "./src/app/shared/new-relic/new-relic.service.ts");
/* harmony import */ var _switcher_switcher_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../switcher/switcher.service */ "./src/app/switcher/switcher.service.ts");
/* harmony import */ var _shared_pusher_pusher_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @shared/pusher/pusher.service */ "./src/app/shared/pusher/pusher.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};









var AuthLoginComponent = /** @class */ (function () {
    function AuthLoginComponent(router, authService, notificationService, utils, newRelic, switcherService, pusherService) {
        this.router = router;
        this.authService = authService;
        this.notificationService = notificationService;
        this.utils = utils;
        this.newRelic = newRelic;
        this.switcherService = switcherService;
        this.pusherService = pusherService;
        this.loginForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormGroup"]({
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]),
        });
        this.isLoggingIn = false;
        this.showPassword = false;
    }
    AuthLoginComponent.prototype.ngOnInit = function () {
        this.newRelic.setPageViewName('login');
    };
    AuthLoginComponent.prototype.login = function () {
        var _this = this;
        if (this.utils.isEmpty(this.loginForm.value.email) || this.utils.isEmpty(this.loginForm.value.password)) {
            this.notificationService.alert({
                message: 'Your email or password is empty, please fill them in.',
                buttons: [
                    {
                        text: 'OK',
                        role: 'cancel',
                        handler: function () {
                            _this.isLoggingIn = false;
                            return;
                        }
                    }
                ]
            });
            return;
        }
        this.isLoggingIn = true;
        var nrLoginTracer = this.newRelic.createTracer('login request started', function (message) {
            _this.newRelic.setCustomAttribute('login status', message);
        });
        return this.authService.login({
            email: this.loginForm.value.email,
            password: this.loginForm.value.password,
        }).subscribe(function (res) {
            nrLoginTracer('login successful');
            _this.newRelic.actionText('login successful');
            return _this._handleNavigation(res.programs);
        }, function (err) {
            nrLoginTracer(JSON.stringify(err));
            _this.newRelic.noticeError("" + JSON.stringify(err));
            // notify user about weak password
            if (_this.utils.has(err, 'data.type')) {
                if (err.data.type === 'password_compromised') {
                    _this.isLoggingIn = false;
                    return _this.notificationService.alert({
                        message: "We\u2019ve checked this password against a global database of insecure passwords and your password was on it. <br>\n                We have sent you an email with a link to reset your password. <br>\n                You can learn more about how we check that <a href=\"https://haveibeenpwned.com/Passwords\">database</a>",
                        buttons: [
                            {
                                text: 'OK',
                                role: 'cancel'
                            }
                        ],
                    });
                }
            }
            // credential issue
            _this.notificationService.alert({
                message: 'Your email or password is incorrect, please try again.',
                buttons: [
                    {
                        text: 'OK',
                        role: 'cancel',
                        handler: function () {
                            _this.isLoggingIn = false;
                            return;
                        },
                    },
                ],
            });
        });
    };
    AuthLoginComponent.prototype._handleNavigation = function (programs) {
        return __awaiter(this, void 0, void 0, function () {
            var route;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.switcherService.switchProgramAndNavigate(programs)];
                    case 1:
                        route = _a.sent();
                        this.isLoggingIn = false;
                        return [2 /*return*/, this.router.navigate(route)];
                }
            });
        });
    };
    AuthLoginComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] },
        { type: _auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] },
        { type: _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_4__["NotificationService"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_5__["UtilsService"] },
        { type: _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_6__["NewRelicService"] },
        { type: _switcher_switcher_service__WEBPACK_IMPORTED_MODULE_7__["SwitcherService"] },
        { type: _shared_pusher_pusher_service__WEBPACK_IMPORTED_MODULE_8__["PusherService"] }
    ]; };
    AuthLoginComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-auth-login',
            template: __importDefault(__webpack_require__(/*! raw-loader!./auth-login.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-login/auth-login.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./auth-login.component.scss */ "./src/app/auth/auth-login/auth-login.component.scss")).default]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"],
            _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_4__["NotificationService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_5__["UtilsService"],
            _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_6__["NewRelicService"],
            _switcher_switcher_service__WEBPACK_IMPORTED_MODULE_7__["SwitcherService"],
            _shared_pusher_pusher_service__WEBPACK_IMPORTED_MODULE_8__["PusherService"]])
    ], AuthLoginComponent);
    return AuthLoginComponent;
}());



/***/ }),

/***/ "./src/app/auth/auth-logout/auth-logout.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/auth/auth-logout/auth-logout.component.ts ***!
  \***********************************************************/
/*! exports provided: AuthLogoutComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthLogoutComponent", function() { return AuthLogoutComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _services_router_enter_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @services/router-enter.service */ "./src/app/services/router-enter.service.ts");
/* harmony import */ var _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @shared/new-relic/new-relic.service */ "./src/app/shared/new-relic/new-relic.service.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};





var AuthLogoutComponent = /** @class */ (function (_super) {
    __extends(AuthLogoutComponent, _super);
    function AuthLogoutComponent(router, authService, route, newRelic) {
        var _this = _super.call(this, router) || this;
        _this.router = router;
        _this.authService = authService;
        _this.route = route;
        _this.newRelic = newRelic;
        _this.routeUrl = '/logout';
        return _this;
    }
    AuthLogoutComponent.prototype.onEnter = function () {
        var _this = this;
        this.newRelic.setPageViewName('logout');
        this.route.params.subscribe(function (params) {
            if (params && params.t) {
                return _this.authService.logout(params);
            }
            return _this.authService.logout();
        });
    };
    AuthLogoutComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
        { type: _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_4__["NewRelicService"] }
    ]; };
    AuthLogoutComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-auth-logout',
            template: '',
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_4__["NewRelicService"]])
    ], AuthLogoutComponent);
    return AuthLogoutComponent;
}(_services_router_enter_service__WEBPACK_IMPORTED_MODULE_3__["RouterEnter"]));



/***/ }),

/***/ "./src/app/auth/auth-registration/auth-registration.component.scss":
/*!*************************************************************************!*\
  !*** ./src/app/auth/auth-registration/auth-registration.component.scss ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".list-terms {\n  text-align: left;\n  background: transparent;\n  margin: auto;\n  margin-top: 16px;\n  max-width: 480px;\n}\n.list-terms ion-checkbox {\n  vertical-align: middle;\n  margin-right: 16px;\n}\n.list-terms a {\n  cursor: pointer;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGF3L1dvcmtzcGFjZXMvd3d3L2ludGVyc2VjdGl2ZS9wcmFjdGVyYS1hcHAtdjIvc3JjL2FwcC9hdXRoL2F1dGgtcmVnaXN0cmF0aW9uL2F1dGgtcmVnaXN0cmF0aW9uLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9hdXRoL2F1dGgtcmVnaXN0cmF0aW9uL2F1dGgtcmVnaXN0cmF0aW9uLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0FDQ0Y7QURBRTtFQUNFLHNCQUFBO0VBQ0Esa0JBQUE7QUNFSjtBREFFO0VBQ0UsZUFBQTtBQ0VKIiwiZmlsZSI6InNyYy9hcHAvYXV0aC9hdXRoLXJlZ2lzdHJhdGlvbi9hdXRoLXJlZ2lzdHJhdGlvbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5saXN0LXRlcm1zIHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIG1hcmdpbjogYXV0bztcbiAgbWFyZ2luLXRvcDogMTZweDtcbiAgbWF4LXdpZHRoOiA0ODBweDtcbiAgaW9uLWNoZWNrYm94IHtcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICAgIG1hcmdpbi1yaWdodDogMTZweDtcbiAgfVxuICBhIHtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbn1cbiIsIi5saXN0LXRlcm1zIHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIG1hcmdpbjogYXV0bztcbiAgbWFyZ2luLXRvcDogMTZweDtcbiAgbWF4LXdpZHRoOiA0ODBweDtcbn1cbi5saXN0LXRlcm1zIGlvbi1jaGVja2JveCB7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIG1hcmdpbi1yaWdodDogMTZweDtcbn1cbi5saXN0LXRlcm1zIGEge1xuICBjdXJzb3I6IHBvaW50ZXI7XG59Il19 */");

/***/ }),

/***/ "./src/app/auth/auth-registration/auth-registration.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/auth/auth-registration/auth-registration.component.ts ***!
  \***********************************************************************/
/*! exports provided: AuthRegistrationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthRegistrationComponent", function() { return AuthRegistrationComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @shared/notification/notification.service */ "./src/app/shared/notification/notification.service.ts");
/* harmony import */ var ts_md5_dist_md5__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ts-md5/dist/md5 */ "./node_modules/ts-md5/dist/md5.js");
/* harmony import */ var ts_md5_dist_md5__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(ts_md5_dist_md5__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth/auth.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @shared/new-relic/new-relic.service */ "./src/app/shared/new-relic/new-relic.service.ts");
/* harmony import */ var _switcher_switcher_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../switcher/switcher.service */ "./src/app/switcher/switcher.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};










var AuthRegistrationComponent = /** @class */ (function () {
    function AuthRegistrationComponent(route, authService, utils, storage, notificationService, newRelic, switcherService) {
        this.route = route;
        this.authService = authService;
        this.utils = utils;
        this.storage = storage;
        this.notificationService = notificationService;
        this.newRelic = newRelic;
        this.switcherService = switcherService;
        this.isAgreed = false;
        this.hide_password = false;
        this.user = {
            email: null,
            key: null,
            contact: null,
            id: null
        };
        this.domain = window.location.hostname;
        // validation errors array
        this.errors = [];
        this.showPassword = false;
        this.initForm();
    }
    AuthRegistrationComponent.prototype.ngOnInit = function () {
        this.domain =
            this.domain.indexOf('127.0.0.1') !== -1 ||
                this.domain.indexOf('localhost') !== -1
                ? 'appdev.practera.com'
                : this.domain;
        this.validateQueryParams();
        this.newRelic.setPageViewName('registration');
    };
    AuthRegistrationComponent.prototype.initForm = function () {
        this.registerationForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].email]),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"]('', [
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required,
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].minLength(8)
            ]),
            confirmPassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required])
        });
    };
    AuthRegistrationComponent.prototype.validateQueryParams = function () {
        var _this = this;
        var redirect = [];
        redirect = ['login'];
        var verifyRegistration = this.newRelic.createTracer('verify registration');
        var getConfig = this.newRelic.createTracer('retrieve configurations');
        // access query params
        this.route.queryParamMap.subscribe(function (queryParams) {
            _this.user.email = _this.route.snapshot.paramMap.get('email');
            _this.user.key = _this.route.snapshot.paramMap.get('key');
            if (_this.user.email && _this.user.key) {
                // check is Url valid or not.
                _this.authService.verifyRegistration({
                    email: _this.user.email,
                    key: _this.user.key
                }).subscribe(function (response) {
                    verifyRegistration();
                    if (response) {
                        var user = response.data.User;
                        // Setting user data after registration verified.
                        _this.user.contact = (user || {}).contact_number || null;
                        _this.user.id = user.id;
                        // Update storage data
                        _this.storage.setUser({
                            contactNumber: _this.user.contact,
                            email: _this.user.email
                        });
                        // get app configaration
                        _this.authService.checkDomain({
                            domain: _this.domain
                        }).subscribe(function (res) {
                            getConfig();
                            var data = (res.data || {}).data;
                            data = _this.utils.find(data, function (datum) {
                                return (datum.config && datum.config.auth_via_contact_number);
                            });
                            if (data && data.config) {
                                if (data.config.auth_via_contact_number === true) {
                                    _this.hide_password = true;
                                    _this.user.password = _this.autoGeneratePassword();
                                    _this.confirmPassword = _this.user.password;
                                }
                            }
                        }, function (err) {
                            getConfig();
                            _this.newRelic.noticeError('Get configurations failed', JSON.stringify(err));
                            _this.showPopupMessages('shortMessage', 'Registration link invalid!', redirect);
                        });
                    }
                }, function (error) {
                    verifyRegistration();
                    _this.newRelic.noticeError('verification failed', JSON.stringify(error));
                    _this.showPopupMessages('shortMessage', 'Registration link invalid!', redirect);
                });
            }
            else {
                _this.showPopupMessages('shortMessage', 'Registration link invalid!', redirect);
            }
        });
    };
    AuthRegistrationComponent.prototype.autoGeneratePassword = function () {
        var text = ts_md5_dist_md5__WEBPACK_IMPORTED_MODULE_4__["Md5"].hashStr('').toString();
        var autoPass = text.substr(0, 8);
        return autoPass;
    };
    AuthRegistrationComponent.prototype.openLink = function () {
        var fileURL = 'https://images.practera.com/terms_and_conditions/practera_default_terms_conditions_july2018.pdf';
        this.newRelic.actionText("opened " + fileURL);
        window.open(fileURL, '_system');
    };
    AuthRegistrationComponent.prototype.register = function () {
        var _this = this;
        if (this.validateRegistration()) {
            var nrRegisterTracer_1 = this.newRelic.createTracer('registering');
            this.newRelic.actionText('Validated registration');
            this.authService
                .saveRegistration({
                password: this.confirmPassword,
                user_id: this.user.id,
                key: this.user.key
            })
                .subscribe(function (response) {
                nrRegisterTracer_1();
                var nrAutoLoginTracer = _this.newRelic.createTracer('auto login');
                _this.authService
                    .login({
                    email: _this.user.email,
                    password: _this.confirmPassword
                })
                    .subscribe(function (res) { return __awaiter(_this, void 0, void 0, function () {
                    var route;
                    return __generator(this, function (_a) {
                        switch (_a.label) {
                            case 0:
                                nrAutoLoginTracer();
                                return [4 /*yield*/, this.switcherService.switchProgramAndNavigate(res.programs)];
                            case 1:
                                route = _a.sent();
                                this.showPopupMessages('shortMessage', 'Registration success!', route);
                                return [2 /*return*/];
                        }
                    });
                }); }, function (err) {
                    nrAutoLoginTracer();
                    _this.newRelic.noticeError('auto login failed', JSON.stringify(err));
                    _this.showPopupMessages('shortMessage', 'Registration not complete!');
                });
            }, function (error) {
                _this.newRelic.noticeError('registration failed', JSON.stringify(error));
                if (_this.utils.has(error, 'data.type')) {
                    if (error.data.type === 'password_compromised') {
                        return _this.notificationService.alert({
                            message: "We\u2019ve checked this password against a global database of insecure passwords and your password was on it. <br>\n                    Please try again. <br>\n                    You can learn more about how we check that <a href=\"https://haveibeenpwned.com/Passwords\">database</a>",
                            buttons: [
                                {
                                    text: 'OK',
                                    role: 'cancel'
                                }
                            ],
                        });
                    }
                }
                _this.showPopupMessages('shortMessage', 'Registration not complete!');
            });
        }
    };
    AuthRegistrationComponent.prototype.removeErrorMessages = function () {
        this.errors = [];
    };
    AuthRegistrationComponent.prototype.validateRegistration = function () {
        var isValid = true;
        this.errors = [];
        if (this.hide_password) {
            if (!this.isAgreed) {
                this.errors.push('You need to agree with terms and Conditions.');
                isValid = false;
                return isValid;
            }
            else {
                return isValid;
            }
        }
        else if (this.registerationForm.valid) {
            var pass = this.registerationForm.controls.password.value;
            var confirmPass = this.registerationForm.controls.confirmPassword.value;
            if (pass !== confirmPass) {
                this.errors.push('Your passwords don\'t match.');
                isValid = false;
                return isValid;
            }
            else if (!this.isAgreed) {
                this.errors.push('You need to agree with terms and Conditions.');
                isValid = false;
                return isValid;
            }
            else {
                return isValid;
            }
        }
        else {
            for (var conrtoller in this.registerationForm.controls) {
                if (this.registerationForm.controls[conrtoller].errors) {
                    isValid = false;
                    for (var key in this.registerationForm.controls[conrtoller].errors) {
                        if (this.registerationForm.controls[conrtoller].errors.hasOwnProperty(key)) {
                            switch (key) {
                                case 'required':
                                    this.errors.push('Please fill in your password');
                                    break;
                                case 'minlength':
                                    this.errors.push('Your password needs to be more than 8 characters.');
                                    break;
                                default:
                                    this.errors.push(this.registerationForm.controls.errors[key]);
                            }
                            return;
                        }
                    }
                }
            }
            return isValid;
        }
    };
    AuthRegistrationComponent.prototype.showPopupMessages = function (type, message, redirect) {
        this.notificationService
            .popUp(type, {
            message: message
        }, redirect ? redirect : false);
    };
    AuthRegistrationComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"] },
        { type: _auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilsService"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_7__["BrowserStorageService"] },
        { type: _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"] },
        { type: _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_8__["NewRelicService"] },
        { type: _switcher_switcher_service__WEBPACK_IMPORTED_MODULE_9__["SwitcherService"] }
    ]; };
    AuthRegistrationComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-auth-registration',
            template: __importDefault(__webpack_require__(/*! raw-loader!./auth-registration.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-registration/auth-registration.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./auth-registration.component.scss */ "./src/app/auth/auth-registration/auth-registration.component.scss")).default]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilsService"],
            _services_storage_service__WEBPACK_IMPORTED_MODULE_7__["BrowserStorageService"],
            _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"],
            _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_8__["NewRelicService"],
            _switcher_switcher_service__WEBPACK_IMPORTED_MODULE_9__["SwitcherService"]])
    ], AuthRegistrationComponent);
    return AuthRegistrationComponent;
}());



/***/ }),

/***/ "./src/app/auth/auth-reset-password/auth-reset-password.component.scss":
/*!*****************************************************************************!*\
  !*** ./src/app/auth/auth-reset-password/auth-reset-password.component.scss ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".invalid-field {\n  color: var(--ion-color-danger);\n  border-bottom: 1px solid var(--ion-color-danger);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGF3L1dvcmtzcGFjZXMvd3d3L2ludGVyc2VjdGl2ZS9wcmFjdGVyYS1hcHAtdjIvc3JjL2FwcC9hdXRoL2F1dGgtcmVzZXQtcGFzc3dvcmQvYXV0aC1yZXNldC1wYXNzd29yZC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvYXV0aC9hdXRoLXJlc2V0LXBhc3N3b3JkL2F1dGgtcmVzZXQtcGFzc3dvcmQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSw4QkFBQTtFQUNBLGdEQUFBO0FDQ0YiLCJmaWxlIjoic3JjL2FwcC9hdXRoL2F1dGgtcmVzZXQtcGFzc3dvcmQvYXV0aC1yZXNldC1wYXNzd29yZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5pbnZhbGlkLWZpZWxkIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYW5nZXIpO1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLWRhbmdlcik7XG59XG4iLCIuaW52YWxpZC1maWVsZCB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFuZ2VyKTtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1kYW5nZXIpO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/auth/auth-reset-password/auth-reset-password.component.ts":
/*!***************************************************************************!*\
  !*** ./src/app/auth/auth-reset-password/auth-reset-password.component.ts ***!
  \***************************************************************************/
/*! exports provided: AuthResetPasswordComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthResetPasswordComponent", function() { return AuthResetPasswordComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/notification/notification.service */ "./src/app/shared/notification/notification.service.ts");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth/auth.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @shared/new-relic/new-relic.service */ "./src/app/shared/new-relic/new-relic.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};







var AuthResetPasswordComponent = /** @class */ (function () {
    function AuthResetPasswordComponent(route, router, notificationService, authService, utils, newRelic) {
        this.route = route;
        this.router = router;
        this.notificationService = notificationService;
        this.authService = authService;
        this.utils = utils;
        this.newRelic = newRelic;
        this.verifySuccess = false;
        this.isResetting = false;
        this.showPassword = false;
        this.resetPasswordForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]({
                value: this.email,
                disabled: true,
            }, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email]),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            confirmPassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
        }, { validators: this.checkPasswordMatching });
    }
    AuthResetPasswordComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.key = this.route.snapshot.paramMap.get('key');
        this.email = this.route.snapshot.paramMap.get('email');
        if (!this.key || !this.email) {
            return this._notifyAndRedirect('Invalid reset password link');
        }
        var nrVerifyResetTracer = this.newRelic.createTracer('verify reset password');
        // Call API to verify that key and email parameters from reset password URL are valid
        this.authService.verifyResetPassword({ key: this.key, email: this.email }).subscribe(function (res) {
            nrVerifyResetTracer();
            // verification of key and email is successfuly.
            _this.verifySuccess = true;
        }, function (err) {
            nrVerifyResetTracer();
            _this.newRelic.noticeError('verify reset', JSON.stringify(err));
            return _this._notifyAndRedirect('Invalid reset password link');
        });
    };
    AuthResetPasswordComponent.prototype.resetPassword = function () {
        var _this = this;
        var data = {
            key: this.key,
            email: this.email,
            password: this.resetPasswordForm.controls.password.value,
            verify_password: this.resetPasswordForm.controls.confirmPassword.value
        };
        var nrResetPasswordTracer = this.newRelic.createTracer('reset password');
        this.authService.resetPassword(data).subscribe(function (res) {
            nrResetPasswordTracer();
            return _this._notifyAndRedirect('Password successfully changed! Please login with the new password.');
        }, function (err) {
            nrResetPasswordTracer();
            _this.newRelic.noticeError('reset password failed', JSON.stringify(err));
            if (_this.utils.has(err, 'data.type')) {
                if (err.data.type === 'password_compromised') {
                    return _this.notificationService.alert({
                        message: "We\u2019ve checked this password against a global database of insecure passwords and your password was on it. <br>\n                Please try again. <br>\n                You can learn more about how we check that <a href=\"https://haveibeenpwned.com/Passwords\">database</a>",
                        buttons: [
                            {
                                text: 'OK',
                                role: 'cancel'
                            }
                        ],
                    });
                }
            }
            return _this.notificationService.presentToast('Error updating password.Try again');
        });
    };
    AuthResetPasswordComponent.prototype.checkPasswordMatching = function (resetPasswordForm) {
        var password = resetPasswordForm.controls.password.value;
        var confirmPassword = resetPasswordForm.controls.confirmPassword.value;
        return password === confirmPassword ? null : { notMatching: true };
    };
    AuthResetPasswordComponent.prototype._notifyAndRedirect = function (msg) {
        var _this = this;
        this.notificationService.alert({
            message: msg,
            buttons: [
                {
                    text: 'OK',
                    role: 'cancel',
                    handler: function () {
                        _this.router.navigate(['login']);
                    }
                }
            ]
        });
    };
    AuthResetPasswordComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] },
        { type: _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"] },
        { type: _auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_5__["UtilsService"] },
        { type: _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_6__["NewRelicService"] }
    ]; };
    AuthResetPasswordComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-auth-reset-password',
            template: __importDefault(__webpack_require__(/*! raw-loader!./auth-reset-password.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-reset-password/auth-reset-password.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./auth-reset-password.component.scss */ "./src/app/auth/auth-reset-password/auth-reset-password.component.scss")).default]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"],
            _auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_5__["UtilsService"],
            _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_6__["NewRelicService"]])
    ], AuthResetPasswordComponent);
    return AuthResetPasswordComponent;
}());



/***/ }),

/***/ "./src/app/auth/auth-routing.module.ts":
/*!*********************************************!*\
  !*** ./src/app/auth/auth-routing.module.ts ***!
  \*********************************************/
/*! exports provided: AuthRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthRoutingModule", function() { return AuthRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _auth_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./auth.component */ "./src/app/auth/auth.component.ts");
/* harmony import */ var _auth_login_auth_login_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth-login/auth-login.component */ "./src/app/auth/auth-login/auth-login.component.ts");
/* harmony import */ var _auth_logout_auth_logout_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./auth-logout/auth-logout.component */ "./src/app/auth/auth-logout/auth-logout.component.ts");
/* harmony import */ var _auth_forgot_password_auth_forgot_password_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./auth-forgot-password/auth-forgot-password.component */ "./src/app/auth/auth-forgot-password/auth-forgot-password.component.ts");
/* harmony import */ var _auth_registration_auth_registration_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./auth-registration/auth-registration.component */ "./src/app/auth/auth-registration/auth-registration.component.ts");
/* harmony import */ var _auth_reset_password_auth_reset_password_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./auth-reset-password/auth-reset-password.component */ "./src/app/auth/auth-reset-password/auth-reset-password.component.ts");
/* harmony import */ var _auth_direct_login_auth_direct_login_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./auth-direct-login/auth-direct-login.component */ "./src/app/auth/auth-direct-login/auth-direct-login.component.ts");
/* harmony import */ var _unauthorized_guard__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./unauthorized.guard */ "./src/app/auth/unauthorized.guard.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};










var routes = [
    {
        path: '',
        component: _auth_component__WEBPACK_IMPORTED_MODULE_2__["AuthComponent"],
        children: [
            {
                path: '',
                redirectTo: '/login',
                pathMatch: 'full',
            },
            {
                path: 'login',
                component: _auth_login_auth_login_component__WEBPACK_IMPORTED_MODULE_3__["AuthLoginComponent"],
                canActivate: [_unauthorized_guard__WEBPACK_IMPORTED_MODULE_9__["UnauthorizedGuard"]],
            },
            {
                path: 'logout',
                component: _auth_logout_auth_logout_component__WEBPACK_IMPORTED_MODULE_4__["AuthLogoutComponent"],
            },
            {
                path: 'forgot_password',
                component: _auth_forgot_password_auth_forgot_password_component__WEBPACK_IMPORTED_MODULE_5__["AuthForgotPasswordComponent"],
                canActivate: [_unauthorized_guard__WEBPACK_IMPORTED_MODULE_9__["UnauthorizedGuard"]],
            },
            {
                path: 'registration/:email/:key',
                component: _auth_registration_auth_registration_component__WEBPACK_IMPORTED_MODULE_6__["AuthRegistrationComponent"],
                canActivate: [_unauthorized_guard__WEBPACK_IMPORTED_MODULE_9__["UnauthorizedGuard"]],
            },
            {
                path: 'reset_password/:key/:email',
                component: _auth_reset_password_auth_reset_password_component__WEBPACK_IMPORTED_MODULE_7__["AuthResetPasswordComponent"],
                canActivate: [_unauthorized_guard__WEBPACK_IMPORTED_MODULE_9__["UnauthorizedGuard"]],
            },
            {
                path: 'secure/:authToken',
                component: _auth_direct_login_auth_direct_login_component__WEBPACK_IMPORTED_MODULE_8__["AuthDirectLoginComponent"],
            }
        ]
    }
];
var AuthRoutingModule = /** @class */ (function () {
    function AuthRoutingModule() {
    }
    AuthRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], AuthRoutingModule);
    return AuthRoutingModule;
}());



/***/ }),

/***/ "./src/app/auth/auth.component.ts":
/*!****************************************!*\
  !*** ./src/app/auth/auth.component.ts ***!
  \****************************************/
/*! exports provided: AuthComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthComponent", function() { return AuthComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

var AuthComponent = /** @class */ (function () {
    function AuthComponent() {
    }
    AuthComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-auth',
            template: '<ion-router-outlet></ion-router-outlet>'
        })
    ], AuthComponent);
    return AuthComponent;
}());



/***/ }),

/***/ "./src/app/auth/auth.guard.ts":
/*!************************************!*\
  !*** ./src/app/auth/auth.guard.ts ***!
  \************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./auth.service */ "./src/app/auth/auth.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



var AuthGuard = /** @class */ (function () {
    function AuthGuard(authService, router) {
        this.authService = authService;
        this.router = router;
    }
    AuthGuard.prototype.canActivate = function (route, state) {
        return this.checkLogin();
    };
    AuthGuard.prototype.canActivateChild = function (route, state) {
        return this.canActivate(route, state);
    };
    AuthGuard.prototype.canLoad = function (route) {
        return this.checkLogin();
    };
    AuthGuard.prototype.checkLogin = function () {
        if (this.authService.isAuthenticated()) {
            return true;
        }
        this.router.navigate(['/login']);
        return false;
    };
    AuthGuard.ctorParameters = function () { return [
        { type: _auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }
    ]; };
    AuthGuard = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root',
        }),
        __metadata("design:paramtypes", [_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
    ], AuthGuard);
    return AuthGuard;
}());



/***/ }),

/***/ "./src/app/auth/auth.module.ts":
/*!*************************************!*\
  !*** ./src/app/auth/auth.module.ts ***!
  \*************************************/
/*! exports provided: AuthModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthModule", function() { return AuthModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @shared/shared.module */ "./src/app/shared/shared.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var _auth_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth-routing.module */ "./src/app/auth/auth-routing.module.ts");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./auth.service */ "./src/app/auth/auth.service.ts");
/* harmony import */ var _unauthorized_guard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./unauthorized.guard */ "./src/app/auth/unauthorized.guard.ts");
/* harmony import */ var _program_selected_guard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./program-selected.guard */ "./src/app/auth/program-selected.guard.ts");
/* harmony import */ var _auth_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./auth.component */ "./src/app/auth/auth.component.ts");
/* harmony import */ var _auth_login_auth_login_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./auth-login/auth-login.component */ "./src/app/auth/auth-login/auth-login.component.ts");
/* harmony import */ var _auth_logout_auth_logout_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./auth-logout/auth-logout.component */ "./src/app/auth/auth-logout/auth-logout.component.ts");
/* harmony import */ var _auth_forgot_password_auth_forgot_password_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./auth-forgot-password/auth-forgot-password.component */ "./src/app/auth/auth-forgot-password/auth-forgot-password.component.ts");
/* harmony import */ var _auth_registration_auth_registration_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./auth-registration/auth-registration.component */ "./src/app/auth/auth-registration/auth-registration.component.ts");
/* harmony import */ var _auth_reset_password_auth_reset_password_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./auth-reset-password/auth-reset-password.component */ "./src/app/auth/auth-reset-password/auth-reset-password.component.ts");
/* harmony import */ var _auth_direct_login_auth_direct_login_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./auth-direct-login/auth-direct-login.component */ "./src/app/auth/auth-direct-login/auth-direct-login.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};














var AuthModule = /** @class */ (function () {
    function AuthModule() {
    }
    AuthModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__["SharedModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"],
                _auth_routing_module__WEBPACK_IMPORTED_MODULE_3__["AuthRoutingModule"],
            ],
            declarations: [
                _auth_component__WEBPACK_IMPORTED_MODULE_7__["AuthComponent"],
                _auth_login_auth_login_component__WEBPACK_IMPORTED_MODULE_8__["AuthLoginComponent"],
                _auth_logout_auth_logout_component__WEBPACK_IMPORTED_MODULE_9__["AuthLogoutComponent"],
                _auth_forgot_password_auth_forgot_password_component__WEBPACK_IMPORTED_MODULE_10__["AuthForgotPasswordComponent"],
                _auth_registration_auth_registration_component__WEBPACK_IMPORTED_MODULE_11__["AuthRegistrationComponent"],
                _auth_reset_password_auth_reset_password_component__WEBPACK_IMPORTED_MODULE_12__["AuthResetPasswordComponent"],
                _auth_direct_login_auth_direct_login_component__WEBPACK_IMPORTED_MODULE_13__["AuthDirectLoginComponent"]
            ],
            entryComponents: [
                _auth_component__WEBPACK_IMPORTED_MODULE_7__["AuthComponent"]
            ],
            providers: [
                _auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"],
                _unauthorized_guard__WEBPACK_IMPORTED_MODULE_5__["UnauthorizedGuard"],
                _program_selected_guard__WEBPACK_IMPORTED_MODULE_6__["ProgramSelectedGuard"],
            ],
            exports: [_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__["SharedModule"]]
        })
    ], AuthModule);
    return AuthModule;
}());



/***/ }),

/***/ "./src/app/auth/auth.service.ts":
/*!**************************************!*\
  !*** ./src/app/auth/auth.service.ts ***!
  \**************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _shared_request_request_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @shared/request/request.service */ "./src/app/shared/request/request.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _shared_pusher_pusher_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @shared/pusher/pusher.service */ "./src/app/shared/pusher/pusher.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};








/**
 * @name api
 * @description list of api endpoint involved in this service
 * @type {Object}
 */
var api = {
    getConfig: 'api/v2/plan/experience/list',
    linkedin: 'api/auth_linkedin.json',
    login: 'api/auths.json',
    setProfile: 'api/v2/user/enrolment/edit.json',
    verifyRegistration: 'api/verification_codes.json',
    register: 'api/registration_details.json',
    forgotPassword: 'api/auths.json?action=forgot_password',
    verifyResetPassword: 'api/auths.json?action=verify_reset_password',
    resetPassword: 'api/auths.json?action=reset_password'
};
var AuthService = /** @class */ (function () {
    function AuthService(request, storage, utils, router, pusherService) {
        this.request = request;
        this.storage = storage;
        this.utils = utils;
        this.router = router;
        this.pusherService = pusherService;
    }
    AuthService.prototype._clearCache = function () {
        // do clear user cache here
    };
    AuthService.prototype._login = function (body) {
        var _this = this;
        return this.request.post(api.login, body.toString(), {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (res) { return _this._handleLoginResponse(res); }));
    };
    /**
     * @name login
     * @description login API specifically only accept request data in encodedUrl formdata,
     *              so must convert them into compatible formdata before submission
     * @param {object} { email, password } in string for each of the value
     */
    AuthService.prototype.login = function (_a) {
        var email = _a.email, password = _a.password;
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]({
            encoder: new _shared_request_request_service__WEBPACK_IMPORTED_MODULE_1__["QueryEncoder"]()
        })
            .set('data[User][email]', email)
            .set('data[User][password]', password)
            .set('domain', this.getDomain());
        return this._login(body);
    };
    /**
     * @name directLogin
     * @description login API specifically only accept request data in encodedUrl formdata,
     *              so must convert them into compatible formdata before submission
     * @param {object} { authToken } in string
     */
    AuthService.prototype.directLogin = function (_a) {
        var authToken = _a.authToken;
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]()
            .set('auth_token', authToken);
        this.logout({}, false);
        return this._login(body);
    };
    AuthService.prototype._handleLoginResponse = function (response) {
        var norm = this._normaliseAuth(response);
        this.storage.setUser({ apikey: norm.apikey });
        this.storage.set('programs', norm.programs);
        this.storage.set('isLoggedIn', true);
        return norm;
    };
    AuthService.prototype._normaliseAuth = function (rawData) {
        var _this = this;
        var data = rawData.data;
        return {
            success: rawData.success,
            tutorial: data.tutorial,
            apikey: data.apikey,
            programs: data.Timelines.map(function (timeline) {
                // make sure 'Program.config.theme_color' exist
                if (!_this.utils.has(timeline, 'Program.config.theme_color')) {
                    timeline.Program.config.theme_color = 'var(--ion-color-primary)';
                }
                return {
                    enrolment: timeline.Enrolment,
                    program: timeline.Program,
                    project: timeline.Project,
                    timeline: timeline.Timeline
                };
            }, this),
            config: (data.Experience || {}).config || {},
            _raw: rawData
        };
    };
    AuthService.prototype.isAuthenticated = function () {
        return this.storage.get('isLoggedIn');
    };
    /**
     * Clear user's information and log the user out
     * @param navigationParams the parameters needed when redirect
     * @param redirect         Whether redirect the user to login page or not
     */
    AuthService.prototype.logout = function (navigationParams, redirect) {
        if (navigationParams === void 0) { navigationParams = {}; }
        if (redirect === void 0) { redirect = true; }
        // use the config color
        this.utils.changeThemeColor(this.storage.getConfig().color || '#2bbfd4');
        this.pusherService.unsubscribeChannels();
        this.pusherService.disconnect();
        var config = this.storage.getConfig();
        this.storage.clear();
        // still store config info even logout
        this.storage.setConfig(config);
        if (redirect) {
            return this.router.navigate(['login'], navigationParams);
        }
    };
    /**
    * @name forgotPassword
    * @description make request to server to send out email with reset password url
    * @param  {string}}        email [user's email which will receive reset password url]
    * @return {Observable<any>}      [description]
    */
    AuthService.prototype.forgotPassword = function (email) {
        return this.request.post(api.forgotPassword, {
            email: email,
            domain: this.getDomain()
        });
    };
    AuthService.prototype.getDomain = function () {
        var domain = window.location.hostname;
        domain =
            domain.indexOf('127.0.0.1') !== -1 ||
                domain.indexOf('localhost') !== -1
                ? 'dev.app-v2.practera.com'
                : domain;
        return domain;
    };
    /**
     * @name resetPassword
     * @description make request to server to reset user password
     * @param {[type]} data [description]
     * @return {Observable<any>}      [description]
     */
    AuthService.prototype.resetPassword = function (data) {
        return this.request.post(api.resetPassword, data);
    };
    /**
     * check user linkedIn connection status
     * @return {Boolean}
     */
    AuthService.prototype.linkedinAuthenticated = function () {
        return this.storage.getUser().linkedinConnected || false;
    };
    // Activity ID is no longer used as a parameter,
    // but needs to be there so just pass in a 1
    AuthService.prototype.connectToLinkedIn = function () {
        var url = '/api/auth_linkedin.json?apikey=' + this.storage.getUser().apikey + '&appkey=' + this.storage.get('appkey') + '&timeline_id=' + this.storage.getUser().timelineId;
        this.utils.openUrl(url);
        return;
    };
    /**
     * @name contactNumberLogin
     * @description fast/quick login with contact number
     * @param  {string}}        data [description]
     * @return {Observable<any>}      [description]
     */
    AuthService.prototype.contactNumberLogin = function (data) {
        var _this = this;
        return this.request.post(api.login, {
            contact_number: data.contactNumber,
        }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (response) {
            if (response.data) {
                _this.storage.setUser({ apikey: response.data.apikey });
                _this.storage.set('tutorial', response.data.tutorial);
                _this.storage.set('programs', response.data.timelines);
            }
            // @TODO: verify if safari browser localStorage store data above properly
            return response;
        }));
    };
    AuthService.prototype.getConfig = function (data) {
        return this.request.get(api.getConfig, {
            params: data
        });
    };
    /**
     * @name checkDomain
     * @description enforced domain checking before experience config API call
     * @param {[type]} data [description]
     */
    AuthService.prototype.checkDomain = function (data) {
        if (!data.domain) {
            throw new Error('Tech Error: Domain is compulsory!');
        }
        return this.getConfig(data);
    };
    AuthService.prototype.updateProfile = function (data) {
        return this.request.post(api.setProfile, data);
    };
    AuthService.prototype.saveRegistration = function (data) {
        return this.request
            .post(api.register, data, {
            headers: { 'Content-Type': 'application/json' }
        });
    };
    AuthService.prototype.verifyRegistration = function (data) {
        return this.request
            .post(api.verifyRegistration, data, {
            headers: { 'Content-Type': 'application/json' }
        });
    };
    /**
     * @name verifyResetPassword
     * @description make request to server to verity that user's email and key are valid
     * @param {[type]} data [description]
     * @return {Observable<any>}      [description]
    */
    AuthService.prototype.verifyResetPassword = function (data) {
        return this.request
            .post(api.verifyResetPassword, data, {
            headers: { 'Content-Type': 'application/json' }
        });
    };
    AuthService.ctorParameters = function () { return [
        { type: _shared_request_request_service__WEBPACK_IMPORTED_MODULE_1__["RequestService"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_5__["BrowserStorageService"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_6__["UtilsService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
        { type: _shared_pusher_pusher_service__WEBPACK_IMPORTED_MODULE_7__["PusherService"] }
    ]; };
    AuthService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_shared_request_request_service__WEBPACK_IMPORTED_MODULE_1__["RequestService"],
            _services_storage_service__WEBPACK_IMPORTED_MODULE_5__["BrowserStorageService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_6__["UtilsService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _shared_pusher_pusher_service__WEBPACK_IMPORTED_MODULE_7__["PusherService"]])
    ], AuthService);
    return AuthService;
}());



/***/ }),

/***/ "./src/app/auth/program-selected.guard.ts":
/*!************************************************!*\
  !*** ./src/app/auth/program-selected.guard.ts ***!
  \************************************************/
/*! exports provided: ProgramSelectedGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProgramSelectedGuard", function() { return ProgramSelectedGuard; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



var ProgramSelectedGuard = /** @class */ (function () {
    function ProgramSelectedGuard(router, storage) {
        this.router = router;
        this.storage = storage;
    }
    // if user hasn't selected a program
    ProgramSelectedGuard.prototype.canActivate = function (next, state) {
        var timelineId = this.storage.getUser().timelineId;
        if (timelineId) {
            return true;
        }
        // navigate to not found page
        this.router.navigate(['switcher', 'switcher-program']);
        return false;
    };
    ProgramSelectedGuard.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__["BrowserStorageService"] }
    ]; };
    ProgramSelectedGuard = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _services_storage_service__WEBPACK_IMPORTED_MODULE_2__["BrowserStorageService"]])
    ], ProgramSelectedGuard);
    return ProgramSelectedGuard;
}());



/***/ }),

/***/ "./src/app/auth/unauthorized.guard.ts":
/*!********************************************!*\
  !*** ./src/app/auth/unauthorized.guard.ts ***!
  \********************************************/
/*! exports provided: UnauthorizedGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UnauthorizedGuard", function() { return UnauthorizedGuard; });
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../auth/auth.service */ "./src/app/auth/auth.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



var UnauthorizedGuard = /** @class */ (function () {
    function UnauthorizedGuard(authService, router) {
        this.authService = authService;
        this.router = router;
    }
    UnauthorizedGuard.prototype.canActivate = function (next, state) {
        var userIsAuthenticated = this.authService.isAuthenticated();
        if (userIsAuthenticated !== true) {
            return true;
        }
        // navigate to not found page
        this.router.navigate(['/app']);
        return false;
    };
    UnauthorizedGuard.ctorParameters = function () { return [
        { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_0__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
    ]; };
    UnauthorizedGuard = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        __metadata("design:paramtypes", [_auth_auth_service__WEBPACK_IMPORTED_MODULE_0__["AuthService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], UnauthorizedGuard);
    return UnauthorizedGuard;
}());



/***/ }),

/***/ "./src/app/device-info/device-info.component.ts":
/*!******************************************************!*\
  !*** ./src/app/device-info/device-info.component.ts ***!
  \******************************************************/
/*! exports provided: DeviceInfoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeviceInfoComponent", function() { return DeviceInfoComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm5/ionic-angular.js");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



var DeviceInfoComponent = /** @class */ (function () {
    function DeviceInfoComponent(platform, util) {
        this.platform = platform;
        this.util = util;
        this.navigator = {
            userAgent: null,
            vendor: null,
            appVersion: null,
            platform: null,
            appCodeName: null,
        };
    }
    DeviceInfoComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.platform.ready().then(function (res) {
            console.log(_this.platform);
            var _a = _this.platform, isLandscape = _a.isLandscape, isRTL = _a.isRTL, isPortrait = _a.isPortrait, platforms = _a.platforms, testUserAgent = _a.testUserAgent, backButton = _a.backButton, height = _a.height, getQueryParam = _a.getQueryParam, url = _a.url, width = _a.width;
            var navigator = window.navigator;
            _this.navigator = {
                userAgent: navigator.userAgent,
                vendor: navigator.vendor,
                appVersion: navigator.appVersion,
                platform: navigator.platform,
                appCodeName: navigator.appCodeName,
            };
        });
    };
    DeviceInfoComponent.prototype.isMobile = function () {
        return this.util.isMobile();
    };
    DeviceInfoComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["Platform"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilsService"] }
    ]; };
    DeviceInfoComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            template: __importDefault(__webpack_require__(/*! raw-loader!./device-info.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/device-info/device-info.component.html")).default,
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["Platform"], _services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilsService"]])
    ], DeviceInfoComponent);
    return DeviceInfoComponent;
}());



/***/ }),

/***/ "./src/app/event-detail/event-detail.component.scss":
/*!**********************************************************!*\
  !*** ./src/app/event-detail/event-detail.component.scss ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-icon {\n  margin-right: 10px;\n  font-size: 24px;\n}\n\n.close-icon {\n  font-size: x-large;\n}\n\nh1 {\n  margin: 0;\n}\n\n.zoom-meeting img {\n  width: 24px !important;\n  height: 24px !important;\n  margin-right: 10px;\n}\n\n.zoom-meeting .item-content {\n  width: 100%;\n}\n\n.zoom-meeting .item-content p {\n  text-overflow: ellipsis;\n  overflow: hidden;\n  white-space: nowrap;\n}\n\n.zoom-meeting .item-content p:nth-child(1) {\n  margin-bottom: 0 !important;\n  margin-top: 12px !important;\n  color: var(--practera-event-zoom-color);\n}\n\n.zoom-meeting .item-content p:nth-child(2) {\n  margin-top: 0 !important;\n  margin-bottom: 12px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGF3L1dvcmtzcGFjZXMvd3d3L2ludGVyc2VjdGl2ZS9wcmFjdGVyYS1hcHAtdjIvc3JjL2FwcC9ldmVudC1kZXRhaWwvZXZlbnQtZGV0YWlsLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9ldmVudC1kZXRhaWwvZXZlbnQtZGV0YWlsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0FDQ0Y7O0FEQ0E7RUFDRSxrQkFBQTtBQ0VGOztBREFBO0VBQ0UsU0FBQTtBQ0dGOztBRENFO0VBQ0Usc0JBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0FDRUo7O0FEQUU7RUFDRSxXQUFBO0FDRUo7O0FEREk7RUFDRSx1QkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUNHTjs7QURESTtFQUNFLDJCQUFBO0VBQ0EsMkJBQUE7RUFDQSx1Q0FBQTtBQ0dOOztBRERJO0VBQ0Usd0JBQUE7RUFDQSw4QkFBQTtBQ0dOIiwiZmlsZSI6InNyYy9hcHAvZXZlbnQtZGV0YWlsL2V2ZW50LWRldGFpbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pY29uIHtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICBmb250LXNpemU6IDI0cHg7XG59XG4uY2xvc2UtaWNvbiB7XG4gIGZvbnQtc2l6ZTogeC1sYXJnZTtcbn1cbmgxIHtcbiAgbWFyZ2luOiAwO1xufVxuXG4uem9vbS1tZWV0aW5nIHtcbiAgaW1nIHtcbiAgICB3aWR0aDogMjRweCAhaW1wb3J0YW50O1xuICAgIGhlaWdodDogMjRweCAhaW1wb3J0YW50O1xuICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgfVxuICAuaXRlbS1jb250ZW50IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBwIHtcbiAgICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gICAgfVxuICAgIHA6bnRoLWNoaWxkKDEpIHtcbiAgICAgIG1hcmdpbi1ib3R0b206IDAgIWltcG9ydGFudDtcbiAgICAgIG1hcmdpbi10b3A6IDEycHggIWltcG9ydGFudDtcbiAgICAgIGNvbG9yOiB2YXIoLS1wcmFjdGVyYS1ldmVudC16b29tLWNvbG9yKTtcbiAgICB9XG4gICAgcDpudGgtY2hpbGQoMikge1xuICAgICAgbWFyZ2luLXRvcDogMCAhaW1wb3J0YW50O1xuICAgICAgbWFyZ2luLWJvdHRvbTogMTJweCAhaW1wb3J0YW50O1xuICAgIH1cbiAgfVxufVxuIiwiaW9uLWljb24ge1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIGZvbnQtc2l6ZTogMjRweDtcbn1cblxuLmNsb3NlLWljb24ge1xuICBmb250LXNpemU6IHgtbGFyZ2U7XG59XG5cbmgxIHtcbiAgbWFyZ2luOiAwO1xufVxuXG4uem9vbS1tZWV0aW5nIGltZyB7XG4gIHdpZHRoOiAyNHB4ICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogMjRweCAhaW1wb3J0YW50O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG4uem9vbS1tZWV0aW5nIC5pdGVtLWNvbnRlbnQge1xuICB3aWR0aDogMTAwJTtcbn1cbi56b29tLW1lZXRpbmcgLml0ZW0tY29udGVudCBwIHtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG59XG4uem9vbS1tZWV0aW5nIC5pdGVtLWNvbnRlbnQgcDpudGgtY2hpbGQoMSkge1xuICBtYXJnaW4tYm90dG9tOiAwICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi10b3A6IDEycHggIWltcG9ydGFudDtcbiAgY29sb3I6IHZhcigtLXByYWN0ZXJhLWV2ZW50LXpvb20tY29sb3IpO1xufVxuLnpvb20tbWVldGluZyAuaXRlbS1jb250ZW50IHA6bnRoLWNoaWxkKDIpIHtcbiAgbWFyZ2luLXRvcDogMCAhaW1wb3J0YW50O1xuICBtYXJnaW4tYm90dG9tOiAxMnB4ICFpbXBvcnRhbnQ7XG59Il19 */");

/***/ }),

/***/ "./src/app/event-detail/event-detail.component.ts":
/*!********************************************************!*\
  !*** ./src/app/event-detail/event-detail.component.ts ***!
  \********************************************************/
/*! exports provided: EventDetailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventDetailComponent", function() { return EventDetailComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm5/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _event_detail_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./event-detail.service */ "./src/app/event-detail/event-detail.service.ts");
/* harmony import */ var _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @shared/notification/notification.service */ "./src/app/shared/notification/notification.service.ts");
/* harmony import */ var _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @shared/new-relic/new-relic.service */ "./src/app/shared/new-relic/new-relic.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};








var EventDetailComponent = /** @class */ (function () {
    function EventDetailComponent(router, modalController, eventDetailService, notificationService, utils, newRelic, storage) {
        this.router = router;
        this.modalController = modalController;
        this.eventDetailService = eventDetailService;
        this.notificationService = notificationService;
        this.utils = utils;
        this.newRelic = newRelic;
        this.storage = storage;
        // indicate that user wanna go to the checkin assessment
        this.checkin = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        // CTA button is acting or not
        this.ctaIsActing = false;
    }
    EventDetailComponent.prototype.ngOnInit = function () {
        this.ctaIsActing = false;
        this.newRelic.setPageViewName('event-detail');
    };
    EventDetailComponent.prototype.confirmed = function () {
        var _this = this;
        this.newRelic.addPageAction("Action: " + this.buttonText());
        this.ctaIsActing = true;
        switch (this.buttonText()) {
            case 'Book':
                // we only show the single booking pop up if user has booked an event under the same activity
                if (this.event.singleBooking && this.storage.getBookedEventActivityIds().includes(this.event.activityId)) {
                    this.notificationService.alert({
                        message: 'Booking this event will cancel your booking for other events within the same activity, do you still wanna book?',
                        buttons: [
                            {
                                text: 'OK',
                                handler: function () {
                                    _this._bookEvent();
                                }
                            },
                            {
                                text: 'Cancel',
                                role: 'cancel',
                                handler: function () {
                                    _this.ctaIsActing = false;
                                }
                            }
                        ]
                    });
                }
                else {
                    this._bookEvent();
                }
                break;
            case 'Cancel Booking':
                this.eventDetailService.cancelEvent(this.event).subscribe(function (response) {
                    if (response.success) {
                        _this.notificationService.alert({
                            message: 'Booking cancelled Successfully!',
                            buttons: [
                                {
                                    text: 'OK',
                                    role: 'cancel'
                                }
                            ]
                        });
                        // update the event list & activity detail page
                        _this.utils.broadcastEvent('update-event', null);
                        _this.event.isBooked = false;
                        // remove the activity id from storage if it is single booking
                        if (_this.event.singleBooking) {
                            _this.storage.removeBookedEventActivityIds(_this.event.activityId);
                        }
                    }
                    _this.ctaIsActing = false;
                });
                break;
            case 'Check In':
            case 'View Check In':
                if (this.utils.isMobile()) {
                    this.router.navigate(['assessment', 'event', this.event.assessment.contextId, this.event.assessment.id]);
                }
                else {
                    // tell parent component to go to check in assessment
                    this.checkin.emit({
                        assessmentId: this.event.assessment.id,
                        contextId: this.event.assessment.contextId
                    });
                }
                this.ctaIsActing = false;
                break;
        }
        if (this.utils.isMobile()) {
            this.modalController.dismiss();
        }
    };
    EventDetailComponent.prototype._bookEvent = function () {
        var _this = this;
        this.eventDetailService.bookEvent(this.event).subscribe(function (response) {
            _this.notificationService.alert({
                message: 'Booked Successfully!',
                buttons: [
                    {
                        text: 'OK',
                        role: 'cancel'
                    }
                ]
            });
            // update the event list & activity detail page
            _this.utils.broadcastEvent('update-event', null);
            _this.event.isBooked = true;
            // save the activity id if it is single booking
            if (_this.event.singleBooking) {
                _this.storage.setBookedEventActivityIds(_this.event.activityId);
            }
            _this.ctaIsActing = false;
        }, function (error) {
            _this.notificationService.alert({
                message: 'Booking failed, please try again later!',
                buttons: [
                    {
                        text: 'OK',
                        role: 'cancel'
                    }
                ]
            });
            _this.ctaIsActing = false;
        });
    };
    EventDetailComponent.prototype.buttonText = function () {
        // for not booked event
        if (!this.event.isBooked) {
            // for expired event
            if (this.event.isPast) {
                return 'Expired';
            }
            if (this.event.remainingCapacity > 0 && this.event.canBook) {
                return 'Book';
            }
            return false;
        }
        // can only cancel booking before event start
        if (!this.event.isPast) {
            return 'Cancel Booking';
        }
        // for event that doesn't have check in
        if (!this.utils.has(this.event, 'assessment.id')) {
            return false;
        }
        // for event that have check in
        if (this.event.assessment.isDone) {
            return 'View Check In';
        }
        return 'Check In';
    };
    EventDetailComponent.prototype.close = function () {
        this.modalController.dismiss();
    };
    EventDetailComponent.prototype.openMeetingLink = function (link) {
        window.open(link, '_system');
    };
    EventDetailComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"] },
        { type: _event_detail_service__WEBPACK_IMPORTED_MODULE_4__["EventDetailService"] },
        { type: _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_3__["UtilsService"] },
        { type: _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_6__["NewRelicService"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_7__["BrowserStorageService"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], EventDetailComponent.prototype, "event", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], EventDetailComponent.prototype, "checkin", void 0);
    EventDetailComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-event-detail',
            template: __importDefault(__webpack_require__(/*! raw-loader!./event-detail.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/event-detail/event-detail.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./event-detail.component.scss */ "./src/app/event-detail/event-detail.component.scss")).default]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"],
            _event_detail_service__WEBPACK_IMPORTED_MODULE_4__["EventDetailService"],
            _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_3__["UtilsService"],
            _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_6__["NewRelicService"],
            _services_storage_service__WEBPACK_IMPORTED_MODULE_7__["BrowserStorageService"]])
    ], EventDetailComponent);
    return EventDetailComponent;
}());



/***/ }),

/***/ "./src/app/event-detail/event-detail.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/event-detail/event-detail.module.ts ***!
  \*****************************************************/
/*! exports provided: EventDetailModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventDetailModule", function() { return EventDetailModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @shared/shared.module */ "./src/app/shared/shared.module.ts");
/* harmony import */ var _event_detail_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./event-detail.component */ "./src/app/event-detail/event-detail.component.ts");
/* harmony import */ var _event_detail_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./event-detail.service */ "./src/app/event-detail/event-detail.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};




var EventDetailModule = /** @class */ (function () {
    function EventDetailModule() {
    }
    EventDetailModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__["SharedModule"]
            ],
            declarations: [
                _event_detail_component__WEBPACK_IMPORTED_MODULE_2__["EventDetailComponent"]
            ],
            providers: [_event_detail_service__WEBPACK_IMPORTED_MODULE_3__["EventDetailService"]],
            exports: [_event_detail_component__WEBPACK_IMPORTED_MODULE_2__["EventDetailComponent"]],
            entryComponents: [_event_detail_component__WEBPACK_IMPORTED_MODULE_2__["EventDetailComponent"]]
        })
    ], EventDetailModule);
    return EventDetailModule;
}());



/***/ }),

/***/ "./src/app/event-detail/event-detail.service.ts":
/*!******************************************************!*\
  !*** ./src/app/event-detail/event-detail.service.ts ***!
  \******************************************************/
/*! exports provided: EventDetailService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventDetailService", function() { return EventDetailService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _shared_request_request_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @shared/request/request.service */ "./src/app/shared/request/request.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


var api = {
    post: {
        book: 'api/book_events.json'
    },
    delete: {
        cancel: 'api/book_events.json'
    }
};
var EventDetailService = /** @class */ (function () {
    function EventDetailService(request) {
        this.request = request;
    }
    EventDetailService.prototype.bookEvent = function (event) {
        return this.request.post(api.post.book, {
            event_id: event.id,
            delete_previous: event.singleBooking
        });
    };
    EventDetailService.prototype.cancelEvent = function (event) {
        return this.request.delete(api.delete.cancel, {
            params: {
                event_id: event.id
            }
        });
    };
    EventDetailService.ctorParameters = function () { return [
        { type: _shared_request_request_service__WEBPACK_IMPORTED_MODULE_1__["RequestService"] }
    ]; };
    EventDetailService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_shared_request_request_service__WEBPACK_IMPORTED_MODULE_1__["RequestService"]])
    ], EventDetailService);
    return EventDetailService;
}());



/***/ }),

/***/ "./src/app/event-list/event-list.service.ts":
/*!**************************************************!*\
  !*** ./src/app/event-list/event-list.service.ts ***!
  \**************************************************/
/*! exports provided: EventListService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventListService", function() { return EventListService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _shared_request_request_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @shared/request/request.service */ "./src/app/shared/request/request.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @shared/notification/notification.service */ "./src/app/shared/notification/notification.service.ts");
/* harmony import */ var _app_event_detail_event_detail_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @app/event-detail/event-detail.component */ "./src/app/event-detail/event-detail.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};







/**
 * @name api
 * @description list of api endpoint involved in this service
 * @type {Object}
 */
var api = {
    get: {
        events: 'api/v2/act/event/list.json',
        submissions: 'api/submissions.json',
        activities: 'api/v2/plan/activity/list.json'
    }
};
var EventListService = /** @class */ (function () {
    function EventListService(request, utils, storage, notificationService) {
        this.request = request;
        this.utils = utils;
        this.storage = storage;
        this.notificationService = notificationService;
    }
    EventListService.prototype.getEvents = function (activityId) {
        var _this = this;
        var params = {};
        if (activityId) {
            params = {
                type: 'activity_session',
                activity_id: activityId
            };
        }
        else {
            params = {
                type: 'activity_session'
            };
        }
        return this.request.get(api.get.events, { params: params })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(function (response) {
            return _this.normaliseEvents(response.data);
        }));
    };
    EventListService.prototype.normaliseEvents = function (data) {
        var _this = this;
        if (!Array.isArray(data)) {
            this.request.apiResponseFormatError('Event format error');
            return [];
        }
        var events = [];
        this.storage.initBookedEventActivityIds();
        data.forEach(function (event) {
            if (!_this.utils.has(event, 'id') ||
                !_this.utils.has(event, 'title') ||
                !_this.utils.has(event, 'description') ||
                !_this.utils.has(event, 'activity_id') ||
                !_this.utils.has(event, 'activity_name') ||
                !_this.utils.has(event, 'location') ||
                !_this.utils.has(event, 'start') ||
                !_this.utils.has(event, 'end') ||
                !_this.utils.has(event, 'capacity') ||
                !_this.utils.has(event, 'remaining_capacity') ||
                !_this.utils.has(event, 'is_booked') ||
                !_this.utils.has(event, 'can_book') ||
                !_this.utils.has(event, 'single_booking')) {
                return _this.request.apiResponseFormatError('Event object format error');
            }
            events.push({
                id: event.id,
                name: event.title,
                description: event.description,
                location: event.location,
                activityId: event.activity_id,
                activityName: event.activity_name,
                startTime: event.start,
                endTime: event.end,
                capacity: event.capacity,
                remainingCapacity: event.remaining_capacity,
                isBooked: event.is_booked,
                singleBooking: event.single_booking,
                canBook: event.can_book,
                isPast: _this.utils.timeComparer(event.start) < 0,
                assessment: _this.utils.has(event, 'assessment.id') ? {
                    id: event.assessment.id,
                    contextId: event.assessment.context_id,
                    isDone: event.assessment.is_done || false
                } : null,
                videoConference: _this.utils.has(event, 'video_conference.url') ? {
                    provider: event.video_conference.provider,
                    url: event.video_conference.url,
                    meetingId: event.video_conference.meeting_id,
                    password: event.video_conference.password
                } : null
            });
            // set the booked event activity id if it is single booking activity and booked
            if (event.single_booking && event.is_booked) {
                _this.storage.setBookedEventActivityIds(event.activity_id);
            }
        });
        return this._sortEvent(events);
    };
    EventListService.prototype.getSubmission = function (assessmentId, contextId) {
        var _this = this;
        return this.request.get(api.get.submissions, { params: {
                assessment_id: assessmentId,
                context_id: contextId,
                review: false
            } })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(function (response) {
            return !_this.utils.isEmpty(response.data);
        }));
    };
    EventListService.prototype._sortEvent = function (events) {
        return events.sort(function (a, b) {
            var dateA = new Date(a.startTime + 'Z');
            var dateB = new Date(b.startTime + 'Z');
            var now = new Date();
            if (dateA.getTime() === dateB.getTime()) {
                return 0;
            }
            if (dateA.getTime() > now.getTime() && now.getTime() > dateB.getTime()) {
                return -1;
            }
            if (dateA.getTime() < now.getTime() && now.getTime() < dateB.getTime()) {
                return 1;
            }
            if (dateA.getTime() > now.getTime() && dateB.getTime() > now.getTime()) {
                return dateA.getTime() < dateB.getTime() ? -1 : 1;
            }
            if (dateA.getTime() < now.getTime() && dateB.getTime() < now.getTime()) {
                return dateA.getTime() > dateB.getTime() ? -1 : 1;
            }
        });
    };
    EventListService.prototype.getActivities = function () {
        var _this = this;
        return this.request.get(api.get.activities)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(function (response) {
            if (response.success && response.data) {
                return _this._normaliseActivities(response.data);
            }
        }));
    };
    EventListService.prototype._normaliseActivities = function (data) {
        var _this = this;
        if (!Array.isArray(data)) {
            this.request.apiResponseFormatError('Activity array format error');
            return [];
        }
        return data.map(function (activity) {
            if (!_this.utils.has(activity, 'id') ||
                !_this.utils.has(activity, 'name')) {
                _this.request.apiResponseFormatError('Activity format error');
                return null;
            }
            return {
                id: activity.id,
                name: activity.name
            };
            // sort activity by name alphabetically
        }).sort(function (a, b) { return a.name.localeCompare(b.name); });
    };
    EventListService.prototype.eventDetailPopUp = function (event) {
        return this.notificationService.modal(_app_event_detail_event_detail_component__WEBPACK_IMPORTED_MODULE_6__["EventDetailComponent"], { event: event }, { cssClass: 'event-detail-popup' });
    };
    /******************
      Function used for the event card
    ******************/
    /**
     * This is used to get the proper time information need to be displayed on card
     * @param event Event Object
     */
    EventListService.prototype.timeDisplayed = function (event) {
        // display date only if it is a past event and is not booked
        if (this.utils.timeComparer(event.startTime) < 0 && !event.isBooked) {
            return this.utils.utcToLocal(event.startTime, 'date');
        }
        // otherwise display time only
        return this.utils.utcToLocal(event.startTime, 'time') + ' - ' + this.utils.utcToLocal(event.endTime, 'time');
    };
    /**
     * If the event is not actionable
     * @param event Event Object
     */
    EventListService.prototype.isNotActionable = function (event) {
        if (!event.isPast) {
            return false;
        }
        if (!event.isBooked) {
            return true;
        }
        if (!this.utils.has(event, 'assessment.id')) {
            return true;
        }
        if (event.assessment.isDone) {
            return true;
        }
        return false;
    };
    EventListService.ctorParameters = function () { return [
        { type: _shared_request_request_service__WEBPACK_IMPORTED_MODULE_2__["RequestService"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_3__["UtilsService"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_4__["BrowserStorageService"] },
        { type: _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"] }
    ]; };
    EventListService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_shared_request_request_service__WEBPACK_IMPORTED_MODULE_2__["RequestService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_3__["UtilsService"],
            _services_storage_service__WEBPACK_IMPORTED_MODULE_4__["BrowserStorageService"],
            _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"]])
    ], EventListService);
    return EventListService;
}());



/***/ }),

/***/ "./src/app/fast-feedback/fast-feedback-submitter.service.ts":
/*!******************************************************************!*\
  !*** ./src/app/fast-feedback/fast-feedback-submitter.service.ts ***!
  \******************************************************************/
/*! exports provided: FastFeedbackSubmitterService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FastFeedbackSubmitterService", function() { return FastFeedbackSubmitterService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _shared_request_request_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @shared/request/request.service */ "./src/app/shared/request/request.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


var api = {
    submit: 'api/v2/observation/slider/create.json',
};
var FastFeedbackSubmitterService = /** @class */ (function () {
    function FastFeedbackSubmitterService(request) {
        this.request = request;
    }
    FastFeedbackSubmitterService.prototype.submit = function (data, params) {
        return this.request.post(api.submit, data, { params: params });
    };
    FastFeedbackSubmitterService.ctorParameters = function () { return [
        { type: _shared_request_request_service__WEBPACK_IMPORTED_MODULE_1__["RequestService"] }
    ]; };
    FastFeedbackSubmitterService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_shared_request_request_service__WEBPACK_IMPORTED_MODULE_1__["RequestService"]])
    ], FastFeedbackSubmitterService);
    return FastFeedbackSubmitterService;
}());



/***/ }),

/***/ "./src/app/fast-feedback/fast-feedback.component.scss":
/*!************************************************************!*\
  !*** ./src/app/fast-feedback/fast-feedback.component.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("form ion-button {\n  margin-bottom: 16px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGF3L1dvcmtzcGFjZXMvd3d3L2ludGVyc2VjdGl2ZS9wcmFjdGVyYS1hcHAtdjIvc3JjL2FwcC9mYXN0LWZlZWRiYWNrL2Zhc3QtZmVlZGJhY2suY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2Zhc3QtZmVlZGJhY2svZmFzdC1mZWVkYmFjay5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG1CQUFBO0FDQ0YiLCJmaWxlIjoic3JjL2FwcC9mYXN0LWZlZWRiYWNrL2Zhc3QtZmVlZGJhY2suY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJmb3JtIGlvbi1idXR0b24ge1xuICBtYXJnaW4tYm90dG9tOiAxNnB4O1xufVxuIiwiZm9ybSBpb24tYnV0dG9uIHtcbiAgbWFyZ2luLWJvdHRvbTogMTZweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/fast-feedback/fast-feedback.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/fast-feedback/fast-feedback.component.ts ***!
  \**********************************************************/
/*! exports provided: FastFeedbackComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FastFeedbackComponent", function() { return FastFeedbackComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm5/ionic-angular.js");
/* harmony import */ var _fast_feedback_submitter_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./fast-feedback-submitter.service */ "./src/app/fast-feedback/fast-feedback-submitter.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @shared/notification/notification.service */ "./src/app/shared/notification/notification.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @shared/new-relic/new-relic.service */ "./src/app/shared/new-relic/new-relic.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};








var FastFeedbackComponent = /** @class */ (function () {
    function FastFeedbackComponent(modalController, fastFeedbackSubmitterService, utils, notification, storage, newRelic) {
        this.modalController = modalController;
        this.fastFeedbackSubmitterService = fastFeedbackSubmitterService;
        this.utils = utils;
        this.notification = notification;
        this.storage = storage;
        this.newRelic = newRelic;
        this.questions = [];
        this.loading = false;
    }
    FastFeedbackComponent.prototype.ngOnInit = function () {
        this.newRelicTracer = this.newRelic.createTracer('fastfeedback shown');
        this.newRelic.setPageViewName('Fast feedback popup');
        var group = {};
        this.questions.forEach(function (question) {
            group[question.id] = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required);
        });
        this.fastFeedbackForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormGroup"](group);
        this.submissionCompleted = false;
    };
    FastFeedbackComponent.prototype.dismiss = function (data) {
        // change the flag to false
        this.storage.set('fastFeedbackOpening', false);
        this.modalController.dismiss(data);
    };
    FastFeedbackComponent.prototype.submit = function () {
        return __awaiter(this, void 0, void 0, function () {
            var formData, data, params, nrFastFeedbackSubmissionTracer, submissionResult;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.loading = true;
                        formData = this.fastFeedbackForm.value;
                        data = [];
                        this.utils.each(formData, function (answer, questionId) {
                            data.push({
                                id: questionId,
                                choice_id: answer,
                            });
                        });
                        params = {
                            context_id: this.meta.context_id
                        };
                        // if team_id exist, pass team_id
                        if (this.meta.team_id) {
                            params['team_id'] = this.meta.team_id;
                        }
                        else if (this.meta.target_user_id) {
                            // otherwise, pass target_user_id
                            params['target_user_id'] = this.meta.target_user_id;
                        }
                        nrFastFeedbackSubmissionTracer = this.newRelic.createTracer('fastfeeback submission');
                        return [4 /*yield*/, this.fastFeedbackSubmitterService.submit(data, params).toPromise()];
                    case 1:
                        submissionResult = _a.sent();
                        nrFastFeedbackSubmissionTracer();
                        this.submissionCompleted = true;
                        return [2 /*return*/, setTimeout(function () {
                                _this.newRelicTracer();
                                return _this.dismiss(submissionResult);
                            }, 2000)];
                }
            });
        });
    };
    FastFeedbackComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"] },
        { type: _fast_feedback_submitter_service__WEBPACK_IMPORTED_MODULE_2__["FastFeedbackSubmitterService"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilsService"] },
        { type: _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_6__["BrowserStorageService"] },
        { type: _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_7__["NewRelicService"] }
    ]; };
    FastFeedbackComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-fast-feedback',
            template: __importDefault(__webpack_require__(/*! raw-loader!./fast-feedback.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/fast-feedback/fast-feedback.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./fast-feedback.component.scss */ "./src/app/fast-feedback/fast-feedback.component.scss")).default]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"],
            _fast_feedback_submitter_service__WEBPACK_IMPORTED_MODULE_2__["FastFeedbackSubmitterService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilsService"],
            _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"],
            _services_storage_service__WEBPACK_IMPORTED_MODULE_6__["BrowserStorageService"],
            _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_7__["NewRelicService"]])
    ], FastFeedbackComponent);
    return FastFeedbackComponent;
}());



/***/ }),

/***/ "./src/app/fast-feedback/fast-feedback.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/fast-feedback/fast-feedback.module.ts ***!
  \*******************************************************/
/*! exports provided: FastFeedbackModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FastFeedbackModule", function() { return FastFeedbackModule; });
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm5/ionic-angular.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var _fast_feedback_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./fast-feedback.component */ "./src/app/fast-feedback/fast-feedback.component.ts");
/* harmony import */ var _fast_feedback_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./fast-feedback.service */ "./src/app/fast-feedback/fast-feedback.service.ts");
/* harmony import */ var _question_question_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./question/question.component */ "./src/app/fast-feedback/question/question.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};







var FastFeedbackModule = /** @class */ (function () {
    function FastFeedbackModule() {
    }
    FastFeedbackModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _ionic_angular__WEBPACK_IMPORTED_MODULE_0__["IonicModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            ],
            declarations: [
                _fast_feedback_component__WEBPACK_IMPORTED_MODULE_4__["FastFeedbackComponent"],
                _question_question_component__WEBPACK_IMPORTED_MODULE_6__["QuestionComponent"],
            ],
            providers: [_fast_feedback_service__WEBPACK_IMPORTED_MODULE_5__["FastFeedbackService"]],
            exports: [
                _fast_feedback_component__WEBPACK_IMPORTED_MODULE_4__["FastFeedbackComponent"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_0__["IonicModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            ]
        })
    ], FastFeedbackModule);
    return FastFeedbackModule;
}());



/***/ }),

/***/ "./src/app/fast-feedback/fast-feedback.service.ts":
/*!********************************************************!*\
  !*** ./src/app/fast-feedback/fast-feedback.service.ts ***!
  \********************************************************/
/*! exports provided: FastFeedbackService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FastFeedbackService", function() { return FastFeedbackService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _fast_feedback_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fast-feedback.component */ "./src/app/fast-feedback/fast-feedback.component.ts");
/* harmony import */ var _shared_request_request_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @shared/request/request.service */ "./src/app/shared/request/request.service.ts");
/* harmony import */ var _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @shared/notification/notification.service */ "./src/app/shared/notification/notification.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};








var api = {
    fastFeedback: 'api/v2/observation/slider/list.json',
};
var FastFeedbackService = /** @class */ (function () {
    function FastFeedbackService(request, notificationService, storage, utils) {
        this.request = request;
        this.notificationService = notificationService;
        this.storage = storage;
        this.utils = utils;
    }
    FastFeedbackService.prototype.getFastFeedback = function () {
        return this.request.get(api.fastFeedback);
    };
    /**
     * Pop up the fast feedback modal window
     */
    FastFeedbackService.prototype.fastFeedbackModal = function (props, modalOnly) {
        if (modalOnly === void 0) { modalOnly = false; }
        if (modalOnly) {
            return this.notificationService.modalOnly(_fast_feedback_component__WEBPACK_IMPORTED_MODULE_1__["FastFeedbackComponent"], props, {
                backdropDismiss: false,
                showBackdrop: false,
            });
        }
        return this.notificationService.modal(_fast_feedback_component__WEBPACK_IMPORTED_MODULE_1__["FastFeedbackComponent"], props, {
            backdropDismiss: false,
            showBackdrop: false,
        });
    };
    FastFeedbackService.prototype.pullFastFeedback = function (options) {
        var _this = this;
        if (options === void 0) { options = {
            modalOnly: false
        }; }
        return this.getFastFeedback().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(function (res) {
            // don't open it again if there's one opening
            var fastFeedbackIsOpened = _this.storage.get('fastFeedbackOpening');
            // popup instant feedback view if question quantity found > 0
            if (!_this.utils.isEmpty(res.data) && res.data.slider.length > 0 && !fastFeedbackIsOpened) {
                // add a flag to indicate that a fast feedback pop up is opening
                _this.storage.set('fastFeedbackOpening', true);
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["from"])(_this.fastFeedbackModal({
                    questions: res.data.slider,
                    meta: res.data.meta
                }, options.modalOnly));
            }
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(res);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["retryWhen"])(function (errors) {
            // retry for 3 times if API go wrong
            return errors.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["delay"])(1000), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(3));
        }));
    };
    FastFeedbackService.ctorParameters = function () { return [
        { type: _shared_request_request_service__WEBPACK_IMPORTED_MODULE_2__["RequestService"] },
        { type: _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_4__["BrowserStorageService"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_5__["UtilsService"] }
    ]; };
    FastFeedbackService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_shared_request_request_service__WEBPACK_IMPORTED_MODULE_2__["RequestService"],
            _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"],
            _services_storage_service__WEBPACK_IMPORTED_MODULE_4__["BrowserStorageService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_5__["UtilsService"]])
    ], FastFeedbackService);
    return FastFeedbackService;
}());



/***/ }),

/***/ "./src/app/fast-feedback/question/question.component.scss":
/*!****************************************************************!*\
  !*** ./src/app/fast-feedback/question/question.component.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Zhc3QtZmVlZGJhY2svcXVlc3Rpb24vcXVlc3Rpb24uY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/fast-feedback/question/question.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/fast-feedback/question/question.component.ts ***!
  \**************************************************************/
/*! exports provided: QuestionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QuestionComponent", function() { return QuestionComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


var QuestionComponent = /** @class */ (function () {
    function QuestionComponent() {
    }
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], QuestionComponent.prototype, "question", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormGroup"])
    ], QuestionComponent.prototype, "form", void 0);
    QuestionComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'question',
            template: __importDefault(__webpack_require__(/*! raw-loader!./question.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/fast-feedback/question/question.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./question.component.scss */ "./src/app/fast-feedback/question/question.component.scss")).default]
        }),
        __metadata("design:paramtypes", [])
    ], QuestionComponent);
    return QuestionComponent;
}());



/***/ }),

/***/ "./src/app/go-mobile/go-mobile.component.scss":
/*!****************************************************!*\
  !*** ./src/app/go-mobile/go-mobile.component.scss ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".go-mobile ion-grid .glazing-effect {\n  background-image: url(/assets/img/mobile-bg.png);\n  background-size: contain;\n  background-repeat: no-repeat;\n  background-position-x: center;\n  background-origin: content-box;\n}\n.go-mobile ion-grid p {\n  padding-left: 10em;\n  padding-right: 10em;\n}\n.go-mobile ion-grid img {\n  padding-top: 2em;\n  -webkit-transform: rotate(-15deg);\n          transform: rotate(-15deg);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGF3L1dvcmtzcGFjZXMvd3d3L2ludGVyc2VjdGl2ZS9wcmFjdGVyYS1hcHAtdjIvc3JjL2FwcC9nby1tb2JpbGUvZ28tbW9iaWxlLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9nby1tb2JpbGUvZ28tbW9iaWxlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVJO0VBQ0UsZ0RBQUE7RUFDQSx3QkFBQTtFQUNBLDRCQUFBO0VBQ0EsNkJBQUE7RUFDQSw4QkFBQTtBQ0ROO0FESUk7RUFDRSxrQkFBQTtFQUNBLG1CQUFBO0FDRk47QURLSTtFQUNFLGdCQUFBO0VBQ0EsaUNBQUE7VUFBQSx5QkFBQTtBQ0hOIiwiZmlsZSI6InNyYy9hcHAvZ28tbW9iaWxlL2dvLW1vYmlsZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5nby1tb2JpbGUge1xuICBpb24tZ3JpZCB7XG4gICAgLmdsYXppbmctZWZmZWN0IHtcbiAgICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCgvYXNzZXRzL2ltZy9tb2JpbGUtYmcucG5nKTtcbiAgICAgIGJhY2tncm91bmQtc2l6ZTogY29udGFpbjtcbiAgICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uLXg6IGNlbnRlcjtcbiAgICAgIGJhY2tncm91bmQtb3JpZ2luOiBjb250ZW50LWJveDtcbiAgICB9XG5cbiAgICBwIHtcbiAgICAgIHBhZGRpbmctbGVmdDogMTBlbTtcbiAgICAgIHBhZGRpbmctcmlnaHQ6IDEwZW07XG4gICAgfVxuXG4gICAgaW1nIHtcbiAgICAgIHBhZGRpbmctdG9wOiAyZW07XG4gICAgICB0cmFuc2Zvcm06IHJvdGF0ZSgtMTVkZWcpO1xuICAgIH1cbiAgfVxufVxuIiwiLmdvLW1vYmlsZSBpb24tZ3JpZCAuZ2xhemluZy1lZmZlY3Qge1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoL2Fzc2V0cy9pbWcvbW9iaWxlLWJnLnBuZyk7XG4gIGJhY2tncm91bmQtc2l6ZTogY29udGFpbjtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbi14OiBjZW50ZXI7XG4gIGJhY2tncm91bmQtb3JpZ2luOiBjb250ZW50LWJveDtcbn1cbi5nby1tb2JpbGUgaW9uLWdyaWQgcCB7XG4gIHBhZGRpbmctbGVmdDogMTBlbTtcbiAgcGFkZGluZy1yaWdodDogMTBlbTtcbn1cbi5nby1tb2JpbGUgaW9uLWdyaWQgaW1nIHtcbiAgcGFkZGluZy10b3A6IDJlbTtcbiAgdHJhbnNmb3JtOiByb3RhdGUoLTE1ZGVnKTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/go-mobile/go-mobile.component.ts":
/*!**************************************************!*\
  !*** ./src/app/go-mobile/go-mobile.component.ts ***!
  \**************************************************/
/*! exports provided: GoMobileComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GoMobileComponent", function() { return GoMobileComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _go_mobile_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./go-mobile.service */ "./src/app/go-mobile/go-mobile.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @shared/notification/notification.service */ "./src/app/shared/notification/notification.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @shared/new-relic/new-relic.service */ "./src/app/shared/new-relic/new-relic.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};







var GoMobileComponent = /** @class */ (function () {
    function GoMobileComponent(goMobileService, utils, notification, storage, newRelic) {
        this.goMobileService = goMobileService;
        this.utils = utils;
        this.notification = notification;
        this.storage = storage;
        this.newRelic = newRelic;
        this.sendingSMS = false;
        this.saved = false;
        this.profile = {
            contactNumber: '',
            email: '',
            sendsms: true
        };
        this.invalidNumber = true;
        // default country model
        this.countryModel = 'AUS';
    }
    GoMobileComponent.prototype.ngOnInit = function () {
        this.newRelic.setPageViewName('go-mobile');
        this.profile.contactNumber = this.storage.getUser().contactNumber;
        if (this.profile.contactNumber) {
            this.saved = true;
            this.invalidNumber = false;
        }
        // by default, set Mask in Australian format.
        /*
          user has no contact number, set the default mask
            : also check which the server which the APP talks to, i.e if the APP is consuming APIs from 'us.practera.com' then, it is APP V2 in US.
              But if APP consumes APIs from 'api.practera.com' then it is APP V2 in AUS.
        */
        if (_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].APIEndpoint.indexOf('us') !== -1) {
            this.countryModel = 'US';
        }
    };
    GoMobileComponent.prototype.submit = function () {
        var _this = this;
        var nrSubmitContactTracer = this.newRelic.createTracer('submit contact');
        this.newRelic.addPageAction('submit contact info');
        this.sendingSMS = true;
        this.profile.contactNumber = this.profile.contactNumber.replace(/[^0-9+]+/ig, '');
        // check if newly input number is valid or not.
        if (!this.validateContactNumber()) {
            return this.notification.presentToast('Invalid contact number');
        }
        this.goMobileService.submit({
            contact_number: this.profile.contactNumber,
            sendsms: true,
        }).subscribe(function (res) {
            nrSubmitContactTracer();
            _this.saved = true;
            var alertBox = _this.notification.alert({
                header: 'Going Mobile!',
                message: 'You should get an SMS shortly... if not, contact our help team',
                buttons: [{
                        text: 'OK',
                        handler: function () {
                            _this.sendingSMS = false;
                            return _this.notification.dismiss();
                        },
                    }],
            });
            return alertBox;
        }, function (err) {
            var toasted = _this.notification.alert({
                header: 'Error submitting contact info',
                message: err.msg || JSON.stringify(err)
            });
            nrSubmitContactTracer();
            _this.newRelic.noticeError('submitting contact error', JSON.stringify(err));
            return toasted;
        });
    };
    GoMobileComponent.prototype.validateContactNumber = function () {
        var contactNumber = this.profile.contactNumber.replace(/[^0-9+]+/ig, '');
        switch (this.countryModel) {
            case 'AUS':
            case 'DE':
                if (contactNumber.length === 12) {
                    this.invalidNumber = false;
                    return true;
                }
                else if (contactNumber.length === 3) {
                    this.profile.contactNumber = null;
                }
                break;
            case 'NZ':
                if (contactNumber.length === 12 || contactNumber.length === 13) {
                    this.invalidNumber = false;
                    return true;
                }
                else if (contactNumber.length === 3) {
                    this.profile.contactNumber = null;
                }
                break;
            case 'US':
                if (contactNumber.length === 12) {
                    this.invalidNumber = false;
                    return true;
                }
                else if (contactNumber.length === 2) {
                    this.profile.contactNumber = null;
                }
                break;
            case 'UK':
                if (contactNumber.length === 13) {
                    this.invalidNumber = false;
                    return true;
                }
                else if (contactNumber.length === 3) {
                    this.profile.contactNumber = null;
                }
                break;
        }
        this.invalidNumber = true;
        return false;
    };
    GoMobileComponent.prototype.updateCountry = function (contactNumber) {
        this.profile.contactNumber = contactNumber;
    };
    GoMobileComponent.ctorParameters = function () { return [
        { type: _go_mobile_service__WEBPACK_IMPORTED_MODULE_1__["GoMobileService"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilsService"] },
        { type: _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_4__["BrowserStorageService"] },
        { type: _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_6__["NewRelicService"] }
    ]; };
    GoMobileComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'go-mobile',
            template: __importDefault(__webpack_require__(/*! raw-loader!./go-mobile.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/go-mobile/go-mobile.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./go-mobile.component.scss */ "./src/app/go-mobile/go-mobile.component.scss")).default]
        }),
        __metadata("design:paramtypes", [_go_mobile_service__WEBPACK_IMPORTED_MODULE_1__["GoMobileService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilsService"],
            _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"],
            _services_storage_service__WEBPACK_IMPORTED_MODULE_4__["BrowserStorageService"],
            _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_6__["NewRelicService"]])
    ], GoMobileComponent);
    return GoMobileComponent;
}());



/***/ }),

/***/ "./src/app/go-mobile/go-mobile.module.ts":
/*!***********************************************!*\
  !*** ./src/app/go-mobile/go-mobile.module.ts ***!
  \***********************************************/
/*! exports provided: GoMobileModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GoMobileModule", function() { return GoMobileModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var _go_mobile_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./go-mobile.component */ "./src/app/go-mobile/go-mobile.component.ts");
/* harmony import */ var _go_mobile_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./go-mobile.service */ "./src/app/go-mobile/go-mobile.service.ts");
/* harmony import */ var angular2_text_mask__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! angular2-text-mask */ "./node_modules/angular2-text-mask/__ivy_ngcc__/dist/angular2TextMask.js");
/* harmony import */ var angular2_text_mask__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(angular2_text_mask__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @shared/shared.module */ "./src/app/shared/shared.module.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};






var GoMobileModule = /** @class */ (function () {
    function GoMobileModule() {
    }
    GoMobileModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _shared_shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_1__["ReactiveFormsModule"],
                angular2_text_mask__WEBPACK_IMPORTED_MODULE_4__["TextMaskModule"],
            ],
            declarations: [
                _go_mobile_component__WEBPACK_IMPORTED_MODULE_2__["GoMobileComponent"]
            ],
            providers: [_go_mobile_service__WEBPACK_IMPORTED_MODULE_3__["GoMobileService"]],
            exports: [
                _go_mobile_component__WEBPACK_IMPORTED_MODULE_2__["GoMobileComponent"],
            ]
        })
    ], GoMobileModule);
    return GoMobileModule;
}());



/***/ }),

/***/ "./src/app/go-mobile/go-mobile.service.ts":
/*!************************************************!*\
  !*** ./src/app/go-mobile/go-mobile.service.ts ***!
  \************************************************/
/*! exports provided: GoMobileService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GoMobileService", function() { return GoMobileService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _services_shared_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @services/shared.service */ "./src/app/services/shared.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


var GoMobileService = /** @class */ (function () {
    function GoMobileService(sharedService) {
        this.sharedService = sharedService;
    }
    GoMobileService.prototype.submit = function (profile) {
        return this.sharedService.updateProfile(profile);
    };
    GoMobileService.ctorParameters = function () { return [
        { type: _services_shared_service__WEBPACK_IMPORTED_MODULE_1__["SharedService"] }
    ]; };
    GoMobileService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_services_shared_service__WEBPACK_IMPORTED_MODULE_1__["SharedService"]])
    ], GoMobileService);
    return GoMobileService;
}());



/***/ }),

/***/ "./src/app/page-not-found/page-not-found.component.scss":
/*!**************************************************************!*\
  !*** ./src/app/page-not-found/page-not-found.component.scss ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2Utbm90LWZvdW5kL3BhZ2Utbm90LWZvdW5kLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/page-not-found/page-not-found.component.ts":
/*!************************************************************!*\
  !*** ./src/app/page-not-found/page-not-found.component.ts ***!
  \************************************************************/
/*! exports provided: PageNotFoundComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageNotFoundComponent", function() { return PageNotFoundComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @shared/new-relic/new-relic.service */ "./src/app/shared/new-relic/new-relic.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


var PageNotFoundComponent = /** @class */ (function () {
    function PageNotFoundComponent(newRelic) {
        this.newRelic = newRelic;
    }
    PageNotFoundComponent.prototype.ngOnInit = function () {
        this.newRelic.setPageViewName('page-not-found');
    };
    PageNotFoundComponent.ctorParameters = function () { return [
        { type: _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_1__["NewRelicService"] }
    ]; };
    PageNotFoundComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-page-not-found',
            template: __importDefault(__webpack_require__(/*! raw-loader!./page-not-found.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/page-not-found/page-not-found.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./page-not-found.component.scss */ "./src/app/page-not-found/page-not-found.component.scss")).default]
        }),
        __metadata("design:paramtypes", [_shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_1__["NewRelicService"]])
    ], PageNotFoundComponent);
    return PageNotFoundComponent;
}());



/***/ }),

/***/ "./src/app/review-list/review-list.service.ts":
/*!****************************************************!*\
  !*** ./src/app/review-list/review-list.service.ts ***!
  \****************************************************/
/*! exports provided: ReviewListService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReviewListService", function() { return ReviewListService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _shared_request_request_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @shared/request/request.service */ "./src/app/shared/request/request.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};




var api = {
    reviews: 'api/reviews.json',
};
var ReviewListService = /** @class */ (function () {
    function ReviewListService(request, utils) {
        this.request = request;
        this.utils = utils;
    }
    ReviewListService.prototype.getReviews = function () {
        var _this = this;
        return this.request.get(api.reviews)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(function (response) {
            if (response.success && response.data) {
                return _this._normaliseReviews(response.data);
            }
            else {
                return [];
            }
        }));
    };
    ReviewListService.prototype._normaliseReviews = function (data) {
        var _this = this;
        if (!Array.isArray(data)) {
            return this.request.apiResponseFormatError('Reviews format error');
        }
        var reviews = [];
        data.forEach(function (review) {
            if (!_this.utils.has(review, 'Assessment.id') ||
                !_this.utils.has(review, 'Assessment.name') ||
                !_this.utils.has(review, 'AssessmentReview.is_done') ||
                !_this.utils.has(review, 'AssessmentSubmission.Submitter.name') ||
                !_this.utils.has(review, 'AssessmentSubmission.context_id') ||
                !_this.utils.has(review, 'AssessmentSubmission.id') ||
                !_this.utils.has(review, 'AssessmentReview.created') ||
                !_this.utils.has(review, 'AssessmentReview.modified')) {
                return _this.request.apiResponseFormatError('Reviews object format error');
            }
            reviews.push({
                assessmentId: review.Assessment.id,
                submissionId: review.AssessmentSubmission.id,
                isDone: review.AssessmentReview.is_done,
                name: review.Assessment.name,
                submitterName: review.AssessmentSubmission.Submitter.name,
                date: _this.utils.timeFormatter(review.AssessmentReview.is_done ? review.AssessmentReview.modified : review.AssessmentReview.created),
                teamName: _this.utils.has(review, 'AssessmentSubmission.Team.name') ? review.AssessmentSubmission.Team.name : '',
                contextId: review.AssessmentSubmission.context_id
            });
        });
        return reviews;
    };
    ReviewListService.ctorParameters = function () { return [
        { type: _shared_request_request_service__WEBPACK_IMPORTED_MODULE_2__["RequestService"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_3__["UtilsService"] }
    ]; };
    ReviewListService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root',
        }),
        __metadata("design:paramtypes", [_shared_request_request_service__WEBPACK_IMPORTED_MODULE_2__["RequestService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_3__["UtilsService"]])
    ], ReviewListService);
    return ReviewListService;
}());



/***/ }),

/***/ "./src/app/review-rating/review-rating.component.scss":
/*!************************************************************!*\
  !*** ./src/app/review-rating/review-rating.component.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".review-rating {\n  top: 0 !important;\n  padding: 0 10px 0 10px;\n}\n.review-rating .header-detail {\n  display: -webkit-inline-box;\n  display: inline-flex;\n  width: 100%;\n  margin-bottom: 10px;\n  margin-top: 20px;\n}\n.review-rating .header-detail .title {\n  margin: auto;\n  padding-left: 10px;\n  margin-left: 0;\n  font-size: 20px;\n  font-weight: normal;\n}\n.review-rating .close-button {\n  padding-right: 10px;\n  font-size: 20px;\n}\n.review-rating hr.separator {\n  border: 0;\n  height: 1px;\n  background-image: -webkit-gradient(linear, left top, right top, from(rgba(0, 0, 0, 0)), color-stop(#C7CBE1), to(rgba(0, 0, 0, 0)));\n  background-image: linear-gradient(to right, rgba(0, 0, 0, 0), #C7CBE1, rgba(0, 0, 0, 0));\n}\n.review-rating .title {\n  font-size: 20px;\n  font-weight: bold;\n  text-align: center;\n}\n.review-rating .subTitle {\n  font-size: 16px;\n  font-weight: normal;\n  text-align: center;\n  margin-top: 35px;\n}\n.review-rating .range-text {\n  display: -webkit-inline-box;\n  display: inline-flex;\n  width: 100%;\n}\n.review-rating .range-text p {\n  margin: auto;\n  font-size: 14px;\n  padding-left: 10px;\n  padding-right: 10px;\n}\n.review-rating .range-text p:nth-child(1) {\n  margin-left: 0;\n  color: #AFB5D2;\n}\n.review-rating .range-text p:nth-child(2) {\n  margin-right: 0;\n}\n.review-rating .quick-tagging {\n  display: -webkit-box;\n  display: flex;\n  flex-wrap: wrap;\n  width: 100%;\n  -webkit-box-pack: center;\n          justify-content: center;\n  margin-top: 16px;\n  padding: 0 0 0 10px;\n}\n.review-rating .quick-tagging a.toggle {\n  background-color: var(--ion-color-light);\n  font-size: 14px;\n  padding: 12px;\n  border: 1px;\n  border-style: solid;\n  margin-bottom: 12px;\n  margin-right: 12px;\n  border-radius: 12px;\n}\n.review-rating .quick-tagging a.toggle.active {\n  color: var(--ion-color-light);\n  background-color: var(--ion-color-primary);\n}\n.review-rating .comment-box {\n  font-size: 14px;\n  width: 100%;\n  border: none;\n  border-radius: 12px;\n  margin: 16px 0 0 0;\n  background-color: var(--ion-color-light-tint);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGF3L1dvcmtzcGFjZXMvd3d3L2ludGVyc2VjdGl2ZS9wcmFjdGVyYS1hcHAtdjIvc3JjL2FwcC9yZXZpZXctcmF0aW5nL3Jldmlldy1yYXRpbmcuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3Jldmlldy1yYXRpbmcvcmV2aWV3LXJhdGluZy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGlCQUFBO0VBQ0Esc0JBQUE7QUNDRjtBRENFO0VBQ0UsMkJBQUE7RUFBQSxvQkFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FDQ0o7QURDSTtFQUNFLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7QUNDTjtBREdFO0VBQ0UsbUJBQUE7RUFDQSxlQUFBO0FDREo7QURJRTtFQUNFLFNBQUE7RUFDQSxXQUFBO0VBQ0Esa0lBQUE7RUFBQSx3RkFBQTtBQ0ZKO0FES0U7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQ0hKO0FETUU7RUFDRSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FDSko7QURPRTtFQUNFLDJCQUFBO0VBQUEsb0JBQUE7RUFDQSxXQUFBO0FDTEo7QURPSTtFQUNFLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQ0xOO0FEUUk7RUFDRSxjQUFBO0VBQ0EsY0FBQTtBQ05OO0FEU0k7RUFDRSxlQUFBO0FDUE47QURZRTtFQUNFLG9CQUFBO0VBQUEsYUFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0Esd0JBQUE7VUFBQSx1QkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUNWSjtBRFlJO0VBQ0Usd0NBQUE7RUFDQSxlQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQ1ZOO0FEWU07RUFDRSw2QkFBQTtFQUNBLDBDQUFBO0FDVlI7QURpQkU7RUFDRSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsNkNBQUE7QUNmSiIsImZpbGUiOiJzcmMvYXBwL3Jldmlldy1yYXRpbmcvcmV2aWV3LXJhdGluZy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5yZXZpZXctcmF0aW5nIHtcbiAgdG9wOiAwICFpbXBvcnRhbnQ7XG4gIHBhZGRpbmc6IDAgMTBweCAwIDEwcHg7XG5cbiAgLmhlYWRlci1kZXRhaWwge1xuICAgIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgbWFyZ2luLXRvcDogMjBweDtcblxuICAgIC50aXRsZSB7XG4gICAgICBtYXJnaW46IGF1dG87XG4gICAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gICAgICBtYXJnaW4tbGVmdDogMDtcbiAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7ICAgICAgXG4gICAgfVxuICB9XG5cbiAgLmNsb3NlLWJ1dHRvbiB7XG4gICAgcGFkZGluZy1yaWdodDoxMHB4O1xuICAgIGZvbnQtc2l6ZTogMjBweDsgICAgXG4gIH1cblxuICBoci5zZXBhcmF0b3Ige1xuICAgIGJvcmRlcjogMDtcbiAgICBoZWlnaHQ6IDFweDtcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsIHJnYmEoMCwgMCwgMCwgMCksICNDN0NCRTEsIHJnYmEoMCwgMCwgMCwgMCkpO1xuICB9XG5cbiAgLnRpdGxlIHtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICB9XG5cbiAgLnN1YlRpdGxlIHtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgbWFyZ2luLXRvcDozNXB4O1xuICB9XG5cbiAgLnJhbmdlLXRleHQge1xuICAgIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICAgIHdpZHRoOiAxMDAlO1xuXG4gICAgcCB7XG4gICAgICBtYXJnaW46IGF1dG87XG4gICAgICBmb250LXNpemU6IDE0cHg7ICAgXG4gICAgICBwYWRkaW5nLWxlZnQ6MTBweDtcbiAgICAgIHBhZGRpbmctcmlnaHQ6MTBweDsgXG4gICAgfVxuXG4gICAgcDpudGgtY2hpbGQoMSkge1xuICAgICAgbWFyZ2luLWxlZnQ6IDA7XG4gICAgICBjb2xvcjogI0FGQjVEMjtcbiAgICB9XG5cbiAgICBwOm50aC1jaGlsZCgyKSB7XG4gICAgICBtYXJnaW4tcmlnaHQ6IDA7XG4gICAgfVxuXG4gIH1cblxuICAucXVpY2stdGFnZ2luZyB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LXdyYXA6IHdyYXA7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgbWFyZ2luLXRvcDogMTZweDtcbiAgICBwYWRkaW5nOiAwIDAgMCAxMHB4O1xuXG4gICAgYS50b2dnbGUgeyAgICAgIFxuICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgIHBhZGRpbmc6IDEycHg7XG4gICAgICBib3JkZXI6IDFweDtcbiAgICAgIGJvcmRlci1zdHlsZTogc29saWQ7XG4gICAgICBtYXJnaW4tYm90dG9tOiAxMnB4O1xuICAgICAgbWFyZ2luLXJpZ2h0OiAxMnB4O1xuICAgICAgYm9yZGVyLXJhZGl1czogMTJweDtcblxuICAgICAgJi5hY3RpdmUge1xuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgfVxuXG4gICAgfVxuXG4gIH1cblxuICAuY29tbWVudC1ib3ggeyAgICBcbiAgICBmb250LXNpemU6MTRweDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBib3JkZXI6IG5vbmU7XG4gICAgYm9yZGVyLXJhZGl1czogMTJweDtcbiAgICBtYXJnaW46IDE2cHggMCAwIDA7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXRpbnQpO1xuICB9XG59IiwiLnJldmlldy1yYXRpbmcge1xuICB0b3A6IDAgIWltcG9ydGFudDtcbiAgcGFkZGluZzogMCAxMHB4IDAgMTBweDtcbn1cbi5yZXZpZXctcmF0aW5nIC5oZWFkZXItZGV0YWlsIHtcbiAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICBtYXJnaW4tdG9wOiAyMHB4O1xufVxuLnJldmlldy1yYXRpbmcgLmhlYWRlci1kZXRhaWwgLnRpdGxlIHtcbiAgbWFyZ2luOiBhdXRvO1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIG1hcmdpbi1sZWZ0OiAwO1xuICBmb250LXNpemU6IDIwcHg7XG4gIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG59XG4ucmV2aWV3LXJhdGluZyAuY2xvc2UtYnV0dG9uIHtcbiAgcGFkZGluZy1yaWdodDogMTBweDtcbiAgZm9udC1zaXplOiAyMHB4O1xufVxuLnJldmlldy1yYXRpbmcgaHIuc2VwYXJhdG9yIHtcbiAgYm9yZGVyOiAwO1xuICBoZWlnaHQ6IDFweDtcbiAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCByZ2JhKDAsIDAsIDAsIDApLCAjQzdDQkUxLCByZ2JhKDAsIDAsIDAsIDApKTtcbn1cbi5yZXZpZXctcmF0aW5nIC50aXRsZSB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5yZXZpZXctcmF0aW5nIC5zdWJUaXRsZSB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW4tdG9wOiAzNXB4O1xufVxuLnJldmlldy1yYXRpbmcgLnJhbmdlLXRleHQge1xuICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbiAgd2lkdGg6IDEwMCU7XG59XG4ucmV2aWV3LXJhdGluZyAucmFuZ2UtdGV4dCBwIHtcbiAgbWFyZ2luOiBhdXRvO1xuICBmb250LXNpemU6IDE0cHg7XG4gIHBhZGRpbmctbGVmdDogMTBweDtcbiAgcGFkZGluZy1yaWdodDogMTBweDtcbn1cbi5yZXZpZXctcmF0aW5nIC5yYW5nZS10ZXh0IHA6bnRoLWNoaWxkKDEpIHtcbiAgbWFyZ2luLWxlZnQ6IDA7XG4gIGNvbG9yOiAjQUZCNUQyO1xufVxuLnJldmlldy1yYXRpbmcgLnJhbmdlLXRleHQgcDpudGgtY2hpbGQoMikge1xuICBtYXJnaW4tcmlnaHQ6IDA7XG59XG4ucmV2aWV3LXJhdGluZyAucXVpY2stdGFnZ2luZyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtd3JhcDogd3JhcDtcbiAgd2lkdGg6IDEwMCU7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBtYXJnaW4tdG9wOiAxNnB4O1xuICBwYWRkaW5nOiAwIDAgMCAxMHB4O1xufVxuLnJldmlldy1yYXRpbmcgLnF1aWNrLXRhZ2dpbmcgYS50b2dnbGUge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xuICBmb250LXNpemU6IDE0cHg7XG4gIHBhZGRpbmc6IDEycHg7XG4gIGJvcmRlcjogMXB4O1xuICBib3JkZXItc3R5bGU6IHNvbGlkO1xuICBtYXJnaW4tYm90dG9tOiAxMnB4O1xuICBtYXJnaW4tcmlnaHQ6IDEycHg7XG4gIGJvcmRlci1yYWRpdXM6IDEycHg7XG59XG4ucmV2aWV3LXJhdGluZyAucXVpY2stdGFnZ2luZyBhLnRvZ2dsZS5hY3RpdmUge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuLnJldmlldy1yYXRpbmcgLmNvbW1lbnQtYm94IHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyOiBub25lO1xuICBib3JkZXItcmFkaXVzOiAxMnB4O1xuICBtYXJnaW46IDE2cHggMCAwIDA7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC10aW50KTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/review-rating/review-rating.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/review-rating/review-rating.component.ts ***!
  \**********************************************************/
/*! exports provided: ReviewRatingComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReviewRatingComponent", function() { return ReviewRatingComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm5/ionic-angular.js");
/* harmony import */ var _review_rating_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./review-rating.service */ "./src/app/review-rating/review-rating.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../shared/notification/notification.service */ "./src/app/shared/notification/notification.service.ts");
/* harmony import */ var _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @shared/new-relic/new-relic.service */ "./src/app/shared/new-relic/new-relic.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};







var ReviewRatingComponent = /** @class */ (function () {
    function ReviewRatingComponent(reviewRatingService, modalController, router, utils, notificationService, newRelic) {
        this.reviewRatingService = reviewRatingService;
        this.modalController = modalController;
        this.router = router;
        this.utils = utils;
        this.notificationService = notificationService;
        this.newRelic = newRelic;
        // Default redirect i.e home page.
        this.redirect = ['/'];
        this.ratingData = {
            assessment_review_id: null,
            rating: 0.5,
            comment: '',
            tags: []
        };
        // variable to control the button text to indicate rating
        this.isSubmitting = false;
    }
    Object.defineProperty(ReviewRatingComponent.prototype, "reviewId", {
        // Review ID is required if this component is to be used.upon detecting incoming/changes of value, set passed reviewId into local var
        set: function (reviewId) {
            this.ratingData.assessment_review_id = reviewId;
        },
        enumerable: true,
        configurable: true
    });
    ReviewRatingComponent.prototype.ngOnInit = function () {
        this.newRelic.setPageViewName('review-rating');
    };
    ReviewRatingComponent.prototype.submitReviewRating = function () {
        var _this = this;
        var nrSubmitRatingTracer = this.newRelic.createTracer('submit rating');
        this.newRelic.addPageAction("Submit rating: " + this.ratingData.rating);
        this.isSubmitting = true;
        // round to 2 decimal place
        this.ratingData.rating = +(this.ratingData.rating.toFixed(2));
        this.reviewRatingService.submitRating(this.ratingData).subscribe(function (result) {
            nrSubmitRatingTracer();
            _this.isSubmitting = false;
            _this._closeReviewRating();
        }, function (err) {
            nrSubmitRatingTracer();
            _this.newRelic.noticeError('Submit review fail', JSON.stringify(err));
            var toasted = _this.notificationService.alert({
                header: 'Error submitting rating',
                message: err.msg || JSON.stringify(err)
            });
            throw new Error(err);
        });
    };
    ReviewRatingComponent.prototype._closeReviewRating = function () {
        this.modalController.dismiss();
        // if this.redirect == false, don't redirect to another page
        if (!this.redirect) {
            return;
        }
        if (!this.utils.isMobile()) {
            // go to the desktop view pages
            if (this.redirect.includes('assessment')) {
                return this.router.navigate([
                    'app',
                    'activity',
                    this.redirect[2],
                    {
                        task: 'assessment',
                        task_id: this.redirect[4],
                        context_id: this.redirect[3]
                    }
                ]);
            }
            if (this.redirect.includes('topic')) {
                return this.router.navigate([
                    'app',
                    'activity',
                    this.redirect[1],
                    {
                        task: 'topic',
                        task_id: this.redirect[2]
                    }
                ]);
            }
        }
        this.router.navigate(this.redirect);
    };
    ReviewRatingComponent.prototype.addOrRemoveTags = function (tag) {
        this.newRelic.addPageAction("added/removed: " + tag);
        this.ratingData.tags = this.utils.addOrRemove(this.ratingData.tags, tag);
    };
    ReviewRatingComponent.ctorParameters = function () { return [
        { type: _review_rating_service__WEBPACK_IMPORTED_MODULE_3__["ReviewRatingService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilsService"] },
        { type: _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"] },
        { type: _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_6__["NewRelicService"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Number),
        __metadata("design:paramtypes", [Number])
    ], ReviewRatingComponent.prototype, "reviewId", null);
    ReviewRatingComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-review-rating',
            template: __importDefault(__webpack_require__(/*! raw-loader!./review-rating.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/review-rating/review-rating.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./review-rating.component.scss */ "./src/app/review-rating/review-rating.component.scss")).default]
        }),
        __metadata("design:paramtypes", [_review_rating_service__WEBPACK_IMPORTED_MODULE_3__["ReviewRatingService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilsService"],
            _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"],
            _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_6__["NewRelicService"]])
    ], ReviewRatingComponent);
    return ReviewRatingComponent;
}());



/***/ }),

/***/ "./src/app/review-rating/review-rating.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/review-rating/review-rating.module.ts ***!
  \*******************************************************/
/*! exports provided: ReviewRatingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReviewRatingModule", function() { return ReviewRatingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm5/ionic-angular.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var _review_rating_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./review-rating.component */ "./src/app/review-rating/review-rating.component.ts");
/* harmony import */ var _review_rating_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./review-rating.service */ "./src/app/review-rating/review-rating.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};






var ReviewRatingModule = /** @class */ (function () {
    function ReviewRatingModule() {
    }
    ReviewRatingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"]
            ],
            declarations: [
                _review_rating_component__WEBPACK_IMPORTED_MODULE_4__["ReviewRatingComponent"]
            ],
            providers: [_review_rating_service__WEBPACK_IMPORTED_MODULE_5__["ReviewRatingService"]],
            exports: [_review_rating_component__WEBPACK_IMPORTED_MODULE_4__["ReviewRatingComponent"]],
            entryComponents: [_review_rating_component__WEBPACK_IMPORTED_MODULE_4__["ReviewRatingComponent"]]
        })
    ], ReviewRatingModule);
    return ReviewRatingModule;
}());



/***/ }),

/***/ "./src/app/review-rating/review-rating.service.ts":
/*!********************************************************!*\
  !*** ./src/app/review-rating/review-rating.service.ts ***!
  \********************************************************/
/*! exports provided: ReviewRatingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReviewRatingService", function() { return ReviewRatingService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _shared_request_request_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @shared/request/request.service */ "./src/app/shared/request/request.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


var api = {
    post: {
        reviewRating: 'api/v2/observations/review_rating/create.json',
    }
};
var ReviewRatingService = /** @class */ (function () {
    function ReviewRatingService(request) {
        this.request = request;
    }
    ReviewRatingService.prototype.submitRating = function (data) {
        var postData = {
            assessment_review_id: data.assessment_review_id,
            rating: data.rating,
            comment: data.comment,
            tags: data.tags
        };
        return this.request.post(api.post.reviewRating, postData);
    };
    ReviewRatingService.ctorParameters = function () { return [
        { type: _shared_request_request_service__WEBPACK_IMPORTED_MODULE_1__["RequestService"] }
    ]; };
    ReviewRatingService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_shared_request_request_service__WEBPACK_IMPORTED_MODULE_1__["RequestService"]])
    ], ReviewRatingService);
    return ReviewRatingService;
}());



/***/ }),

/***/ "./src/app/services/router-enter.service.ts":
/*!**************************************************!*\
  !*** ./src/app/services/router-enter.service.ts ***!
  \**************************************************/
/*! exports provided: RouterEnter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RouterEnter", function() { return RouterEnter; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

var RouterEnter = /** @class */ (function () {
    function RouterEnter(router) {
        this.router = router;
        this.subscriptions = [];
    }
    /**
     * @description
     * this ngOnInit() is designed for enforcing the invoke of onEnter()
     * on every url changes, those new url with "/app/" prefix must invoke 2 onEnter()
     * from different component
     * (particularly on screen stacked with multiple layers of different components)
     *
     * 1. onEnter() of TabComponent - routerUrl "/app/"
     * 2. onEnter() of the related url's component class - depend on what is
     *   available in the relative url
     *
     * @example
     * let's take RouterEnter as parent class of following components
     *   URL: `/app/project`
     *     - TabComponent.onEnter()
     *     - ProjectComponent.onEnter()
     *   URL: `/app/assessment/assessment/123/123`
     *     - TabComponent.onEnter()
     *     - AssessmentComponent.onEnter()
     *   URL: `/events/any-route`
     *     - EventComponent.onEnter()
     *   URL: `/switcher/switcher-program`
     *     - SwitcherProgramComponent.onEnter()
     *   URL: `/bad-url`
     *     - PageNotFoundComponent.onEnter()
     *
     * @returns void
     */
    RouterEnter.prototype.ngOnInit = function () {
        var _this = this;
        this.subscription = this.router.events.subscribe(function (event) {
            // invoke the onEnter() function of the component if the routing match current page view and stacked components' routeUrl
            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_0__["NavigationEnd"] && event.url.includes(_this.routeUrl)) {
                // always unsubscribe previously subscribed Observables to prevent duplication subscription
                if (_this.subscriptions) {
                    _this.subscriptions.forEach(function (sub) { return sub.unsubscribe(); });
                    _this.subscriptions = [];
                }
                _this.onEnter();
            }
        });
    };
    RouterEnter.prototype.ngOnDestroy = function () {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
        if (this.subscriptions) {
            this.subscriptions.forEach(function (sub) { return sub.unsubscribe(); });
        }
    };
    RouterEnter.prototype.onEnter = function () {
    };
    return RouterEnter;
}());



/***/ }),

/***/ "./src/app/services/shared.service.ts":
/*!********************************************!*\
  !*** ./src/app/services/shared.service.ts ***!
  \********************************************/
/*! exports provided: SharedService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedService", function() { return SharedService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @shared/notification/notification.service */ "./src/app/shared/notification/notification.service.ts");
/* harmony import */ var _shared_request_request_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @shared/request/request.service */ "./src/app/shared/request/request.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/http.js");
/* harmony import */ var _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @shared/new-relic/new-relic.service */ "./src/app/shared/new-relic/new-relic.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};







var api = {
    post: {
        profile: 'api/v2/user/enrolment/edit.json',
    },
};
var SharedService = /** @class */ (function () {
    function SharedService(utils, storage, notification, request, http, newrelic) {
        this.utils = utils;
        this.storage = storage;
        this.notification = notification;
        this.request = request;
        this.http = http;
        this.newrelic = newrelic;
        this.memoryCache = {};
    }
    // call this function on every page refresh and after switch program
    SharedService.prototype.onPageLoad = function () {
        var _this = this;
        this.getIpLocation();
        // only do these if a timeline is choosen
        if (!this.storage.getUser().timelineId) {
            return;
        }
        // check and change theme color on every page refresh
        var color = this.storage.getUser().themeColor;
        if (color) {
            this.utils.changeThemeColor(color);
        }
        var image = this.storage.getUser().activityCardImage;
        if (image) {
            this.utils.changeCardBackgroundImage(image);
        }
        // subscribe to the achievement event if it is not subscribed
        if (!this.achievementEvent) {
            this.achievementEvent = this.utils.getEvent('achievement').subscribe(function (event) {
                _this.notification.achievementPopUp('notification', {
                    id: event.meta.Achievement.id,
                    name: event.meta.Achievement.name,
                    description: event.meta.Achievement.description,
                    points: event.meta.Achievement.points,
                    image: event.meta.Achievement.badge
                });
            });
        }
    };
    SharedService.prototype.updateProfile = function (data) {
        return this.request.post(api.post.profile, data);
    };
    /**
     * This method check due dates of assessment or activity.
     * - Check due date is today, tomorrow, upcoming date or overdue date.
     * - If due date is upcoming one this will returns 'Due (date)' ex: 'Due 06-30-2019'.
     * - If due date is overdue one this will returns 'Overdue (date)' ex: 'Overdue 01-10-2019'.
     * - If due date is today this will return 'Due Today'.
     * - If due date is tomorrow this will return 'Due Tomorrow'.
     * @param dueDate - due date of assessment or activity.
     */
    SharedService.prototype.dueDateFormatter = function (dueDate) {
        if (!dueDate) {
            return '';
        }
        var difference = this.utils.timeComparer(dueDate);
        if (difference < 0) {
            return 'Overdue ' + this.utils.utcToLocal(dueDate);
        }
        return 'Due ' + this.utils.utcToLocal(dueDate);
    };
    /**
     * This method get all iframe and videos from documents and stop playing videos.
     */
    SharedService.prototype.stopPlayingVideos = function () {
        var iframes = Array.from(document.querySelectorAll('iframe'));
        var videos = Array.from(document.querySelectorAll('video'));
        if (iframes) {
            iframes.forEach(function (frame) {
                frame.src = null;
            });
        }
        if (videos) {
            videos.forEach(function (video) {
                video.pause();
            });
        }
    };
    /**
     * Get the user's current location from IP
     */
    SharedService.prototype.getIpLocation = function () {
        var _this = this;
        this._ipAPI().subscribe(function (res) { return _this.storage.setCountry(res.country_name); }, function (err) { return _this.newrelic.noticeError(err); });
    };
    SharedService.prototype._ipAPI = function () {
        return this.http.get('https://ipapi.co/json');
    };
    SharedService.ctorParameters = function () { return [
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_1__["UtilsService"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__["BrowserStorageService"] },
        { type: _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"] },
        { type: _shared_request_request_service__WEBPACK_IMPORTED_MODULE_4__["RequestService"] },
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"] },
        { type: _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_6__["NewRelicService"] }
    ]; };
    SharedService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_services_utils_service__WEBPACK_IMPORTED_MODULE_1__["UtilsService"],
            _services_storage_service__WEBPACK_IMPORTED_MODULE_2__["BrowserStorageService"],
            _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"],
            _shared_request_request_service__WEBPACK_IMPORTED_MODULE_4__["RequestService"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"],
            _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_6__["NewRelicService"]])
    ], SharedService);
    return SharedService;
}());



/***/ }),

/***/ "./src/app/services/storage.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/storage.service.ts ***!
  \*********************************************/
/*! exports provided: BROWSER_STORAGE, BrowserStorageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BROWSER_STORAGE", function() { return BROWSER_STORAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrowserStorageService", function() { return BrowserStorageService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

var BROWSER_STORAGE = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["InjectionToken"]('Browser Storage', {
    providedIn: 'root',
    factory: function () { return localStorage; }
});
var BrowserStorageService = /** @class */ (function () {
    function BrowserStorageService(storage) {
        this.storage = storage;
    }
    BrowserStorageService.prototype.get = function (key) {
        var cached = this.storage.getItem(key);
        if (cached) {
            return JSON.parse(this.storage.getItem(key) || null);
        }
        return null;
    };
    BrowserStorageService.prototype.set = function (key, value) {
        return this.storage.setItem(key, JSON.stringify(value));
    };
    BrowserStorageService.prototype.append = function (key, value) {
        var actual = this.get(key);
        if (!actual) {
            actual = {};
        }
        return this.set(key, Object.assign(actual, value));
    };
    BrowserStorageService.prototype.remove = function (key) {
        this.storage.removeItem(key);
    };
    BrowserStorageService.prototype.clear = function () {
        this.storage.clear();
    };
    BrowserStorageService.prototype.getUser = function () {
        return this.get('me') || {};
    };
    BrowserStorageService.prototype.setUser = function (user) {
        this.set('me', Object.assign(this.getUser(), user));
        return true;
    };
    BrowserStorageService.prototype.getConfig = function () {
        return this.get('config') || {};
    };
    BrowserStorageService.prototype.setConfig = function (config) {
        this.set('config', Object.assign(this.getConfig(), config));
        return true;
    };
    /*********
      'bookedEventActivityIds' records the single booking activity ids that event has been booked for current user
    **********/
    // get the list of activity ids in local storage to check whether we need to show the single booking pop up or not
    BrowserStorageService.prototype.getBookedEventActivityIds = function () {
        return this.get('bookedEventActivityIds') || [];
    };
    // 1. set this value when we get events data from API
    // 2. record the activity id when user book an event
    BrowserStorageService.prototype.setBookedEventActivityIds = function (id) {
        var ids = this.getBookedEventActivityIds();
        ids.push(id);
        this.set('bookedEventActivityIds', ids);
    };
    // remove the activity id when user cancel booking
    BrowserStorageService.prototype.removeBookedEventActivityIds = function (id) {
        var ids = this.getBookedEventActivityIds();
        var index = ids.indexOf(id);
        if (index < 0) {
            return;
        }
        ids.splice(index, 1);
        this.set('bookedEventActivityIds', ids);
        return;
    };
    // remove this cache from local storage
    BrowserStorageService.prototype.initBookedEventActivityIds = function () {
        this.remove('bookedEventActivityIds');
    };
    BrowserStorageService.prototype.setCountry = function (country) {
        this.set('country', country);
    };
    BrowserStorageService.prototype.getCountry = function () {
        return this.get('country');
    };
    BrowserStorageService.ctorParameters = function () { return [
        { type: Storage, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [BROWSER_STORAGE,] }] }
    ]; };
    BrowserStorageService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __param(0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(BROWSER_STORAGE)),
        __metadata("design:paramtypes", [Storage])
    ], BrowserStorageService);
    return BrowserStorageService;
}());



/***/ }),

/***/ "./src/app/services/utils.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/utils.service.ts ***!
  \*******************************************/
/*! exports provided: UtilsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UtilsService", function() { return UtilsService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/common.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm5/ionic-angular.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_6__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};







var UtilsService = /** @class */ (function () {
    function UtilsService(document, platform) {
        this.document = document;
        this.platform = platform;
        // this Subject is used to broadcast an event to the app
        this._eventsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        // this Subject is used in project.service to cache the project data
        this.projectSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"](null);
        // this Subject is used in activity.service to cache the activity data
        // it stores key => Subject pairs of all activities
        this.activitySubjects = {};
        if (lodash__WEBPACK_IMPORTED_MODULE_1__) {
            this.lodash = lodash__WEBPACK_IMPORTED_MODULE_1__;
        }
        else {
            throw new Error('Lodash not available');
        }
    }
    /**
     * @name isMobile
     * @description grouping device type into 2 group (mobile/desktop) and return true if mobile, otherwise return false
     * @example https://github.com/ionic-team/ionic/blob/master/angular/src/providers/platform.ts#L71-L115
     */
    UtilsService.prototype.isMobile = function () {
        return window.innerWidth <= 576;
    };
    /** check if a value is empty
     * precautions:
     *  - Lodash's isEmpty, by default, sees "number" type value as empty,
     *    but in our case, we just treat null/undefined/""/[]/{} as empty.
     *  - [{}] = true
     *  - [{}, {}, {}] = false
     *
     * @param  {any}     value
     * @return {boolean}       true: when empty string/object/array, otherwise false
     */
    UtilsService.prototype.isEmpty = function (value) {
        // number type value shouldn't be treat as empty
        if (typeof value === 'number') {
            return false;
        }
        return this.lodash.isEmpty(value);
    };
    UtilsService.prototype.each = function (collections, callback) {
        return this.lodash.each(collections, callback);
    };
    UtilsService.prototype.unset = function (object, path) {
        return this.lodash.unset(object, path);
    };
    UtilsService.prototype.find = function (collections, callback) {
        return this.lodash.find(collections, callback);
    };
    UtilsService.prototype.findIndex = function (collections, callback) {
        return this.lodash.findIndex(collections, callback);
    };
    UtilsService.prototype.has = function (object, path) {
        return this.lodash.has(object, path);
    };
    UtilsService.prototype.flatten = function (array) {
        return this.lodash.flatten(array);
    };
    UtilsService.prototype.indexOf = function (array, value, fromIndex) {
        if (fromIndex === void 0) { fromIndex = 0; }
        return this.lodash.indexOf(array, value, fromIndex);
    };
    UtilsService.prototype.remove = function (collections, callback) {
        return this.lodash.remove(collections, callback);
    };
    UtilsService.prototype.openUrl = function (url, options) {
        options = options || { target: '_self' };
        return window.open(url, options.target);
    };
    // given an array and a value, check if this value is in this array, if it is, remove it, if not, add it to the array
    UtilsService.prototype.addOrRemove = function (array, value) {
        var position = this.indexOf(array, value);
        if (position > -1) {
            // find the position of this value and remove it
            array.splice(position, 1);
        }
        else {
            // add it to the value array
            array.push(value);
        }
        return array;
    };
    /**
     * Given query in GraphQL format, change it to the normal query body string
     * i.e. remove the new line and additional spaces
     * @param query the query string
     */
    UtilsService.prototype.graphQLQueryStringFormatter = function (query) {
        return query.replace(/(\r\n|\n|\r) */gm, ' ');
    };
    UtilsService.prototype.changeThemeColor = function (color) {
        this.document.documentElement.style.setProperty('--ion-color-primary', color);
        this.document.documentElement.style.setProperty('--ion-color-primary-shade', color);
        // get the tint version of the color(20% opacity)
        this.document.documentElement.style.setProperty('--ion-color-primary-tint', color + '33');
        // convert hex color to rgb and update css variable
        var hex = color.replace('#', '');
        var red = parseInt(hex.substring(0, 2), 16);
        var green = parseInt(hex.substring(2, 4), 16);
        var blue = parseInt(hex.substring(4, 6), 16);
        this.document.documentElement.style.setProperty('--ion-color-primary-rgb', red + ',' + green + ',' + blue);
    };
    UtilsService.prototype.changeCardBackgroundImage = function (image) {
        this.document.documentElement.style.setProperty('--practera-card-background-image', 'url(\'' + image + '\')');
    };
    // broadcast the event to whoever subscribed
    UtilsService.prototype.broadcastEvent = function (key, value) {
        this._eventsSubject.next({ key: key, value: value });
    };
    // get Event to subscribe to
    UtilsService.prototype.getEvent = function (key) {
        return this._eventsSubject.asObservable()
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["filter"])(function (e) { return e.key === key; }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (e) { return e.value; }));
    };
    // get the activity Subject for cache
    UtilsService.prototype.getActivityCache = function (key) {
        if (!(key in this.activitySubjects)) {
            this.activitySubjects[key] = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"](null);
        }
        return this.activitySubjects[key];
    };
    // update the activity cache for given key(activity id)
    UtilsService.prototype.updateActivityCache = function (key, value) {
        if (!(key in this.activitySubjects)) {
            this.activitySubjects[key] = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"](null);
        }
        this.activitySubjects[key].next(value);
    };
    // need to clear all Subject for cache
    UtilsService.prototype.clearCache = function () {
        var _this = this;
        // initialise the Subject for caches
        this.projectSubject.next(null);
        this.each(this.activitySubjects, function (subject, key) {
            _this.activitySubjects[key].next(null);
        });
    };
    // transfer url query string to an object
    UtilsService.prototype.urlQueryToObject = function (query) {
        return JSON.parse('{"' + decodeURI(query).replace(/"/g, '\\"').replace(/&/g, '","').replace(/=/g, '":"') + '"}');
    };
    /**
     * This is a time formatter that transfer time/date string to a nice string
     * It will return different string based on the comparision with 'compareWith' (default is today)
     * Any time before yesterday(one day before 'compareWith') will return 'Yesterday'
     * Any time today(the same day as 'compareWith') will return the time
     * Any other time will just return the date in "3 May" format
     * @param {Date} time        [The time string going to be formatted (In UTC timezone)]
     * @param {Date} compareWith [The time string used to compare with]
     */
    UtilsService.prototype.timeFormatter = function (time, compareWith) {
        if (!time) {
            return '';
        }
        var date = moment__WEBPACK_IMPORTED_MODULE_6__(new Date(this.iso8601Formatter(time)));
        // if no compareWith provided, compare with today
        // and create tomorrow and yesterday from it.
        var compareDate = moment__WEBPACK_IMPORTED_MODULE_6__((compareWith) ? new Date(this.iso8601Formatter(compareWith)) : new Date());
        var tomorrow = compareDate.clone().add(1, 'day').startOf('day');
        var yesterday = compareDate.clone().subtract(1, 'day').startOf('day');
        if (date.isSame(yesterday, 'd')) {
            return 'Yesterday';
        }
        if (date.isSame(tomorrow, 'd')) {
            return 'Tomorrow';
        }
        if (date.isSame(compareDate, 'd')) {
            return new Intl.DateTimeFormat('en-GB', {
                hour12: true,
                hour: 'numeric',
                minute: 'numeric'
            }).format(date.toDate());
        }
        return new Intl.DateTimeFormat('en-GB', {
            month: 'short',
            day: 'numeric'
        }).format(date.toDate());
    };
    /**
     * turn date into customised & human-readable language (non RFC2822/ISO standard)
     * @param {Date | string}    time Date
     * @param {string}       display date: display date, time: display time, all: date + time
     */
    UtilsService.prototype.utcToLocal = function (time, display) {
        if (display === void 0) { display = 'all'; }
        if (!time) {
            return '';
        }
        var date = new Date(this.iso8601Formatter(time));
        var formattedTime = new Intl.DateTimeFormat('en-GB', {
            hour12: true,
            hour: 'numeric',
            minute: 'numeric'
        }).format(date);
        switch (display) {
            case 'date':
                return this.dateFormatter(date);
            case 'time':
                return formattedTime;
            default:
                return this.dateFormatter(date) + ' ' + formattedTime;
        }
    };
    /**
     * @description turn date into string formatted date
     * @param {Date} date targetted date
     */
    UtilsService.prototype.dateFormatter = function (date) {
        var dateToFormat = moment__WEBPACK_IMPORTED_MODULE_6__(date);
        var today = moment__WEBPACK_IMPORTED_MODULE_6__(new Date());
        var tomorrow = today.clone().add(1, 'day').startOf('day');
        var yesterday = today.clone().subtract(1, 'day').startOf('day');
        if (dateToFormat.isSame(yesterday, 'd')) {
            return 'Yesterday';
        }
        if (dateToFormat.isSame(tomorrow, 'd')) {
            return 'Tomorrow';
        }
        if (dateToFormat.isSame(today, 'd')) {
            return 'Today';
        }
        return new Intl.DateTimeFormat('en-GB', {
            month: 'short',
            day: 'numeric',
            year: 'numeric'
        }).format(dateToFormat.toDate());
    };
    /**
     * @description dates comparison (between today/provided date)
     * @param {Date    | string} timeString [description]
     * @param {boolean}            = {}} options [description]
     * @return {number} -1: before, 0: same date, 1: after
     */
    UtilsService.prototype.timeComparer = function (timeString, options) {
        if (options === void 0) { options = {}; }
        var comparedString = options.comparedString, compareDate = options.compareDate;
        var time = new Date(this.iso8601Formatter(timeString));
        var compared = new Date();
        if (comparedString) {
            compared = new Date(this.iso8601Formatter(comparedString));
        }
        if (compareDate && (time.getDate() === compared.getDate() &&
            time.getMonth() === compared.getMonth() &&
            time.getFullYear() === compared.getFullYear())) {
            return 0;
        }
        if (time.getTime() < compared.getTime()) {
            return -1;
        }
        if (time.getTime() === compared.getTime()) {
            return 0;
        }
        if (time.getTime() > compared.getTime()) {
            return 1;
        }
    };
    /**
     * get next element in an array,
     * return undefined if the next value is not available
     */
    UtilsService.prototype.getNextArrayElement = function (target, currentId) {
        var length = target.length;
        var index = target.findIndex(function (datum) {
            return datum.id === currentId;
        });
        var nextElement = target[index + 1];
        return target[index + 1];
    };
    /**
     * check if the targeted element in an array is located at the last in the last index
     */
    UtilsService.prototype.checkOrderById = function (target, currentId, options) {
        var length = target.length;
        var index = target.findIndex(function (datum) {
            return datum.id === currentId;
        });
        return (length - 1) === index;
    };
    /**
     * Format the time string
     * 1. Add 'T' between date and time, for compatibility with Safari
     * 2. Add 'Z' at last to indicate that it is UTC time, browser will automatically convert the time to local time
     *
     * Example time string: '2019-08-06 15:03:00'
     * After formatter: '2019-08-06T15:03:00Z'
     *
     * SAFARI enforce ISO 8601 (no space as time delimiter allowed)
     * T for time delimiter
     * Z for timezone (UTC) delimiter (+0000)
     */
    UtilsService.prototype.iso8601Formatter = function (time) {
        try {
            if (typeof time === 'string') {
                var tmpTime = time;
                if (!time.includes('GMT') && !(time.toLowerCase()).includes('z')) {
                    tmpTime += ' GMT+0000';
                }
                return (new Date(tmpTime)).toISOString();
            }
            return time.toISOString();
        }
        catch (err) {
            // in case the above doesn't work on Safari
            if (typeof time === 'string') {
                // add "T" between date and time, so that it works on Safari
                time = time.replace(' ', 'T');
                // add "Z" to indicate that it is UTC time, it will automatically convert to local time
                return time + 'Z';
            }
            return time.toISOString();
        }
    };
    UtilsService.ctorParameters = function () { return [
        { type: Document, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["DOCUMENT"],] }] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Platform"] }
    ]; };
    UtilsService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __param(0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_common__WEBPACK_IMPORTED_MODULE_2__["DOCUMENT"])),
        __metadata("design:paramtypes", [Document,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Platform"]])
    ], UtilsService);
    return UtilsService;
}());



/***/ }),

/***/ "./src/app/services/version-check.service.ts":
/*!***************************************************!*\
  !*** ./src/app/services/version-check.service.ts ***!
  \***************************************************/
/*! exports provided: VersionCheckService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VersionCheckService", function() { return VersionCheckService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _shared_request_request_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @shared/request/request.service */ "./src/app/shared/request/request.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};





var VersionCheckService = /** @class */ (function () {
    function VersionCheckService(requestService, router, ngZone) {
        this.requestService = requestService;
        this.router = router;
        this.ngZone = ngZone;
        this.currentHash = '';
    }
    // check every 3 minutes
    VersionCheckService.prototype.initiateVersionCheck = function (frequency) {
        var _this = this;
        if (frequency === void 0) { frequency = 1000 * 60 * 3; }
        // make the interval run outside of angular so that we can benifit from the automation test
        return this.ngZone.runOutsideAngular(function () {
            _this.trackVersion(frequency).subscribe(function (res) {
                if (_this.hasHashChanged(_this.currentHash, res.hash)) {
                    _this.router.navigate(['logout', { t: new Date().getTime() }]);
                }
            }, function (err) { return console.log; });
        });
    };
    VersionCheckService.prototype.trackVersion = function (frequency) {
        var _this = this;
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["interval"])(frequency).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["switchMap"])(function () { return _this.requestService.get(window.location.origin + "/version.json?t=" + new Date().getTime(), {
            headers: {
                'Cache-Control': 'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
                'Pragma': 'no-cache',
                'Expires': 0,
            }
        }); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["retryWhen"])(function (errors) {
            // retry for 5 times if anything go wrong
            return errors.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["delay"])(1000), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["take"])(5));
        }));
    };
    VersionCheckService.prototype.hasHashChanged = function (currentHash, newHash) {
        if (!currentHash || currentHash === '') {
            return false;
        }
        return currentHash !== newHash;
    };
    VersionCheckService.ctorParameters = function () { return [
        { type: _shared_request_request_service__WEBPACK_IMPORTED_MODULE_3__["RequestService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"] }
    ]; };
    VersionCheckService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_shared_request_request_service__WEBPACK_IMPORTED_MODULE_3__["RequestService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]])
    ], VersionCheckService);
    return VersionCheckService;
}());



/***/ }),

/***/ "./src/app/settings/setting.service.ts":
/*!*********************************************!*\
  !*** ./src/app/settings/setting.service.ts ***!
  \*********************************************/
/*! exports provided: SettingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingService", function() { return SettingService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _services_shared_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @services/shared.service */ "./src/app/services/shared.service.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _shared_request_request_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @shared/request/request.service */ "./src/app/shared/request/request.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};




var api = {
    profileImageUpload: 'api/v2/user/account/edit',
};
var SettingService = /** @class */ (function () {
    function SettingService(sharedService, request) {
        this.sharedService = sharedService;
        this.request = request;
    }
    SettingService.prototype.updateProfile = function (data) {
        return this.sharedService.updateProfile(data);
    };
    SettingService.prototype.updateProfileImage = function (data) {
        return this.request.post(api.profileImageUpload, data)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (response) {
            if (response.success && response.data) {
                return response.data;
            }
            else {
                return [];
            }
        }));
    };
    SettingService.ctorParameters = function () { return [
        { type: _services_shared_service__WEBPACK_IMPORTED_MODULE_1__["SharedService"] },
        { type: _shared_request_request_service__WEBPACK_IMPORTED_MODULE_3__["RequestService"] }
    ]; };
    SettingService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_services_shared_service__WEBPACK_IMPORTED_MODULE_1__["SharedService"],
            _shared_request_request_service__WEBPACK_IMPORTED_MODULE_3__["RequestService"]])
    ], SettingService);
    return SettingService;
}());



/***/ }),

/***/ "./src/app/shared/components/achievement-badge/achievement-badge.component.scss":
/*!**************************************************************************************!*\
  !*** ./src/app/shared/components/achievement-badge/achievement-badge.component.scss ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".badge img {\n  border-radius: 50%;\n  width: 56px;\n  height: 56px;\n}\n.badge ion-icon {\n  position: absolute;\n  font-size: 24px;\n  vertical-align: top !important;\n}\n.badge-name {\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.badge-point {\n  background-color: var(--ion-color-primary);\n  border-radius: 15px;\n  color: white;\n  padding: 0px 8px;\n  margin-left: 3px;\n  height: 24px;\n  max-height: 24px;\n  min-height: 24px;\n  max-width: 100px;\n  margin: auto;\n  margin-top: 10px;\n}\n.badge-point.desktop {\n  max-width: 200px;\n}\n.badge-point-unearned {\n  background-color: var(--ion-color-medium) !important;\n}\n.black-white-image {\n  -webkit-filter: grayscale(100%);\n          filter: grayscale(100%);\n}\n.achievement-badge {\n  width: 100%;\n  height: 100%;\n  padding: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGF3L1dvcmtzcGFjZXMvd3d3L2ludGVyc2VjdGl2ZS9wcmFjdGVyYS1hcHAtdjIvc3JjL2FwcC9zaGFyZWQvY29tcG9uZW50cy9hY2hpZXZlbWVudC1iYWRnZS9hY2hpZXZlbWVudC1iYWRnZS5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvYWNoaWV2ZW1lbnQtYmFkZ2UvYWNoaWV2ZW1lbnQtYmFkZ2UuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDQUo7QURFRTtFQUNFLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLDhCQUFBO0FDQUo7QURHQTtFQUNFLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtBQ0FGO0FERUE7RUFDRSwwQ0FBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FDQ0Y7QURBRTtFQUNFLGdCQUFBO0FDRUo7QURDQTtFQUNFLG9EQUFBO0FDRUY7QURBQTtFQUNFLCtCQUFBO1VBQUEsdUJBQUE7QUNHRjtBREFBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FDR0YiLCJmaWxlIjoic3JjL2FwcC9zaGFyZWQvY29tcG9uZW50cy9hY2hpZXZlbWVudC1iYWRnZS9hY2hpZXZlbWVudC1iYWRnZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5iYWRnZSB7XG4gIGltZyB7XG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgIHdpZHRoOiA1NnB4O1xuICAgIGhlaWdodDogNTZweDtcbiAgfVxuICBpb24taWNvbiB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGZvbnQtc2l6ZTogMjRweDtcbiAgICB2ZXJ0aWNhbC1hbGlnbjogdG9wICFpbXBvcnRhbnQ7XG4gIH1cbn1cbi5iYWRnZS1uYW1lIHtcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG59XG4uYmFkZ2UtcG9pbnQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIGJvcmRlci1yYWRpdXM6IDE1cHg7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgcGFkZGluZzogMHB4IDhweDtcbiAgbWFyZ2luLWxlZnQ6IDNweDtcbiAgaGVpZ2h0OiAyNHB4O1xuICBtYXgtaGVpZ2h0OiAyNHB4O1xuICBtaW4taGVpZ2h0OiAyNHB4O1xuICBtYXgtd2lkdGg6IDEwMHB4O1xuICBtYXJnaW46IGF1dG87XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gICYuZGVza3RvcCB7XG4gICAgbWF4LXdpZHRoOiAyMDBweDtcbiAgfVxufVxuLmJhZGdlLXBvaW50LXVuZWFybmVkIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSkgIWltcG9ydGFudDtcbn1cbi5ibGFjay13aGl0ZS1pbWFnZSB7XG4gIGZpbHRlcjogZ3JheXNjYWxlKDEwMCUpO1xufVxuXG4uYWNoaWV2ZW1lbnQtYmFkZ2Uge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBwYWRkaW5nOiA1cHg7XG59XG4iLCIuYmFkZ2UgaW1nIHtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICB3aWR0aDogNTZweDtcbiAgaGVpZ2h0OiA1NnB4O1xufVxuLmJhZGdlIGlvbi1pY29uIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBmb250LXNpemU6IDI0cHg7XG4gIHZlcnRpY2FsLWFsaWduOiB0b3AgIWltcG9ydGFudDtcbn1cblxuLmJhZGdlLW5hbWUge1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbn1cblxuLmJhZGdlLXBvaW50IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICBib3JkZXItcmFkaXVzOiAxNXB4O1xuICBjb2xvcjogd2hpdGU7XG4gIHBhZGRpbmc6IDBweCA4cHg7XG4gIG1hcmdpbi1sZWZ0OiAzcHg7XG4gIGhlaWdodDogMjRweDtcbiAgbWF4LWhlaWdodDogMjRweDtcbiAgbWluLWhlaWdodDogMjRweDtcbiAgbWF4LXdpZHRoOiAxMDBweDtcbiAgbWFyZ2luOiBhdXRvO1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuLmJhZGdlLXBvaW50LmRlc2t0b3Age1xuICBtYXgtd2lkdGg6IDIwMHB4O1xufVxuXG4uYmFkZ2UtcG9pbnQtdW5lYXJuZWQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKSAhaW1wb3J0YW50O1xufVxuXG4uYmxhY2std2hpdGUtaW1hZ2Uge1xuICBmaWx0ZXI6IGdyYXlzY2FsZSgxMDAlKTtcbn1cblxuLmFjaGlldmVtZW50LWJhZGdlIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgcGFkZGluZzogNXB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/shared/components/achievement-badge/achievement-badge.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/shared/components/achievement-badge/achievement-badge.component.ts ***!
  \************************************************************************************/
/*! exports provided: AchievementBadgeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AchievementBadgeComponent", function() { return AchievementBadgeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @shared/notification/notification.service */ "./src/app/shared/notification/notification.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



var AchievementBadgeComponent = /** @class */ (function () {
    function AchievementBadgeComponent(notificationService, utils) {
        this.notificationService = notificationService;
        this.utils = utils;
        this.showName = false;
    }
    AchievementBadgeComponent.prototype.showAchievementDetails = function () {
        this.notificationService.achievementPopUp('', this.achievement);
    };
    AchievementBadgeComponent.ctorParameters = function () { return [
        { type: _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_1__["NotificationService"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilsService"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], AchievementBadgeComponent.prototype, "achievement", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Boolean)
    ], AchievementBadgeComponent.prototype, "showName", void 0);
    AchievementBadgeComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'achievement-badge',
            template: __importDefault(__webpack_require__(/*! raw-loader!./achievement-badge.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/achievement-badge/achievement-badge.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./achievement-badge.component.scss */ "./src/app/shared/components/achievement-badge/achievement-badge.component.scss")).default]
        }),
        __metadata("design:paramtypes", [_shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_1__["NotificationService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilsService"]])
    ], AchievementBadgeComponent);
    return AchievementBadgeComponent;
}());



/***/ }),

/***/ "./src/app/shared/components/activity-card/activity-card.component.scss":
/*!******************************************************************************!*\
  !*** ./src/app/shared/components/activity-card/activity-card.component.scss ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".card {\n  margin-top: 16px;\n  margin-bottom: 16px;\n  max-height: 120px;\n  height: 120px;\n  background-size: cover;\n  width: 100%;\n  background-position: center;\n  background-blend-mode: soft-light;\n  background-color: transparent;\n  box-shadow: -3px 3px 4px rgba(0, 0, 0, 0.21);\n}\n.card .activity-name {\n  font-size: 18px;\n  font-weight: bold;\n}\n.card ion-card-content {\n  max-height: 120px;\n  height: 120px;\n  width: 100%;\n  padding-top: 12px;\n  padding-bottom: 12px;\n  padding-left: 16px;\n  padding-right: 16px;\n}\n.skeleton-card {\n  background-color: white;\n  box-shadow: none;\n}\n.locked-card {\n  background-color: var(--ion-color-medium);\n}\n.default-image-card {\n  background-image: var(--practera-card-background-image);\n  background-color: var(--ion-color-primary);\n}\n.locked-card.default-image-card {\n  background-blend-mode: color-burn;\n}\n.highlighted {\n  -webkit-animation: glow 800ms ease-out infinite alternate;\n  animation: glow 800ms ease-out infinite alternate;\n}\n@-webkit-keyframes glow {\n  0% {\n    box-shadow: 0 0 5px rgba(0, 255, 0, 0.2), inset 0 0 5px rgba(0, 255, 0, 0.1), 0 2px 0 var(--ion-color-primary);\n  }\n  100% {\n    box-shadow: 0 0 20px rgba(0, 255, 0, 0.6), inset 0 0 10px lime, 0 2px 0 var(--ion-color-primary);\n  }\n}\n@keyframes glow {\n  0% {\n    box-shadow: 0 0 5px rgba(0, 255, 0, 0.2), inset 0 0 5px rgba(0, 255, 0, 0.1), 0 2px 0 var(--ion-color-primary);\n  }\n  100% {\n    box-shadow: 0 0 20px rgba(0, 255, 0, 0.6), inset 0 0 10px lime, 0 2px 0 var(--ion-color-primary);\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGF3L1dvcmtzcGFjZXMvd3d3L2ludGVyc2VjdGl2ZS9wcmFjdGVyYS1hcHAtdjIvc3JjL2FwcC9zaGFyZWQvY29tcG9uZW50cy9hY3Rpdml0eS1jYXJkL2FjdGl2aXR5LWNhcmQuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3NoYXJlZC9jb21wb25lbnRzL2FjdGl2aXR5LWNhcmQvYWN0aXZpdHktY2FyZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLFdBQUE7RUFDQSwyQkFBQTtFQUNBLGlDQUFBO0VBQ0EsNkJBQUE7RUFDQSw0Q0FBQTtBQ0NGO0FEQUU7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7QUNFSjtBREFFO0VBQ0UsaUJBQUE7RUFDQSxhQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FDRUo7QURDQTtFQUNFLHVCQUFBO0VBQ0EsZ0JBQUE7QUNFRjtBREFBO0VBQ0UseUNBQUE7QUNHRjtBRERBO0VBQ0UsdURBQUE7RUFDQSwwQ0FBQTtBQ0lGO0FERkE7RUFDRSxpQ0FBQTtBQ0tGO0FESEE7RUFDRSx5REFBQTtFQUNBLGlEQUFBO0FDTUY7QURIQTtFQUNJO0lBQ0UsOEdBQUE7RUNNSjtFREpFO0lBQ0UsZ0dBQUE7RUNNSjtBQUNGO0FEWkE7RUFDSTtJQUNFLDhHQUFBO0VDTUo7RURKRTtJQUNFLGdHQUFBO0VDTUo7QUFDRiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9jb21wb25lbnRzL2FjdGl2aXR5LWNhcmQvYWN0aXZpdHktY2FyZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jYXJkIHtcbiAgbWFyZ2luLXRvcDogMTZweDtcbiAgbWFyZ2luLWJvdHRvbTogMTZweDtcbiAgbWF4LWhlaWdodDogMTIwcHg7XG4gIGhlaWdodDogMTIwcHg7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gIHdpZHRoOiAxMDAlO1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XG4gIGJhY2tncm91bmQtYmxlbmQtbW9kZTogc29mdC1saWdodDtcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIGJveC1zaGFkb3c6IC0zcHggM3B4IDRweCByZ2JhKDAsIDAsIDAsIDAuMjEpO1xuICAuYWN0aXZpdHktbmFtZSB7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICB9XG4gIGlvbi1jYXJkLWNvbnRlbnQge1xuICAgIG1heC1oZWlnaHQ6IDEyMHB4O1xuICAgIGhlaWdodDogMTIwcHg7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcGFkZGluZy10b3A6IDEycHg7XG4gICAgcGFkZGluZy1ib3R0b206IDEycHg7XG4gICAgcGFkZGluZy1sZWZ0OiAxNnB4O1xuICAgIHBhZGRpbmctcmlnaHQ6IDE2cHg7XG4gIH1cbn1cbi5za2VsZXRvbi1jYXJkIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gIGJveC1zaGFkb3c6IG5vbmU7XG59XG4ubG9ja2VkLWNhcmQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbn1cbi5kZWZhdWx0LWltYWdlLWNhcmQge1xuICBiYWNrZ3JvdW5kLWltYWdlOiB2YXIoLS1wcmFjdGVyYS1jYXJkLWJhY2tncm91bmQtaW1hZ2UpO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG4ubG9ja2VkLWNhcmQuZGVmYXVsdC1pbWFnZS1jYXJkICB7XG4gIGJhY2tncm91bmQtYmxlbmQtbW9kZTogY29sb3ItYnVybjtcbn1cbi5oaWdobGlnaHRlZCB7XG4gIC13ZWJraXQtYW5pbWF0aW9uOiBnbG93IDgwMG1zIGVhc2Utb3V0IGluZmluaXRlIGFsdGVybmF0ZTtcbiAgYW5pbWF0aW9uOiBnbG93IDgwMG1zIGVhc2Utb3V0IGluZmluaXRlIGFsdGVybmF0ZTtcbn1cblxuQGtleWZyYW1lcyBnbG93IHtcbiAgICAwJSB7XG4gICAgICBib3gtc2hhZG93OiAwIDAgNXB4IHJnYmEoMCwyNTUsMCwuMiksIGluc2V0IDAgMCA1cHggcmdiYSgwLDI1NSwwLC4xKSwgMCAycHggMCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgfVxuICAgIDEwMCUge1xuICAgICAgYm94LXNoYWRvdzogMCAwIDIwcHggcmdiYSgwLDI1NSwwLC42KSwgaW5zZXQgMCAwIDEwcHggcmdiYSgwLDI1NSwwLCAxKSwgMCAycHggMCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgfVxufVxuIiwiLmNhcmQge1xuICBtYXJnaW4tdG9wOiAxNnB4O1xuICBtYXJnaW4tYm90dG9tOiAxNnB4O1xuICBtYXgtaGVpZ2h0OiAxMjBweDtcbiAgaGVpZ2h0OiAxMjBweDtcbiAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1ibGVuZC1tb2RlOiBzb2Z0LWxpZ2h0O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgYm94LXNoYWRvdzogLTNweCAzcHggNHB4IHJnYmEoMCwgMCwgMCwgMC4yMSk7XG59XG4uY2FyZCAuYWN0aXZpdHktbmFtZSB7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG4uY2FyZCBpb24tY2FyZC1jb250ZW50IHtcbiAgbWF4LWhlaWdodDogMTIwcHg7XG4gIGhlaWdodDogMTIwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLXRvcDogMTJweDtcbiAgcGFkZGluZy1ib3R0b206IDEycHg7XG4gIHBhZGRpbmctbGVmdDogMTZweDtcbiAgcGFkZGluZy1yaWdodDogMTZweDtcbn1cblxuLnNrZWxldG9uLWNhcmQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgYm94LXNoYWRvdzogbm9uZTtcbn1cblxuLmxvY2tlZC1jYXJkIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG59XG5cbi5kZWZhdWx0LWltYWdlLWNhcmQge1xuICBiYWNrZ3JvdW5kLWltYWdlOiB2YXIoLS1wcmFjdGVyYS1jYXJkLWJhY2tncm91bmQtaW1hZ2UpO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG5cbi5sb2NrZWQtY2FyZC5kZWZhdWx0LWltYWdlLWNhcmQge1xuICBiYWNrZ3JvdW5kLWJsZW5kLW1vZGU6IGNvbG9yLWJ1cm47XG59XG5cbi5oaWdobGlnaHRlZCB7XG4gIC13ZWJraXQtYW5pbWF0aW9uOiBnbG93IDgwMG1zIGVhc2Utb3V0IGluZmluaXRlIGFsdGVybmF0ZTtcbiAgYW5pbWF0aW9uOiBnbG93IDgwMG1zIGVhc2Utb3V0IGluZmluaXRlIGFsdGVybmF0ZTtcbn1cblxuQGtleWZyYW1lcyBnbG93IHtcbiAgMCUge1xuICAgIGJveC1zaGFkb3c6IDAgMCA1cHggcmdiYSgwLCAyNTUsIDAsIDAuMiksIGluc2V0IDAgMCA1cHggcmdiYSgwLCAyNTUsIDAsIDAuMSksIDAgMnB4IDAgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICB9XG4gIDEwMCUge1xuICAgIGJveC1zaGFkb3c6IDAgMCAyMHB4IHJnYmEoMCwgMjU1LCAwLCAwLjYpLCBpbnNldCAwIDAgMTBweCBsaW1lLCAwIDJweCAwIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgfVxufSJdfQ== */");

/***/ }),

/***/ "./src/app/shared/components/activity-card/activity-card.component.ts":
/*!****************************************************************************!*\
  !*** ./src/app/shared/components/activity-card/activity-card.component.ts ***!
  \****************************************************************************/
/*! exports provided: ActivityCardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActivityCardComponent", function() { return ActivityCardComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/common.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



var ActivityCardComponent = /** @class */ (function () {
    function ActivityCardComponent(document) {
        this.document = document;
        this.backgroundImageStyle = '';
    }
    ActivityCardComponent.prototype.ngOnInit = function () {
        this.backgroundImageStyle = '';
        if (this.activity.leadImage) {
            this.backgroundImageStyle = 'url(' + this.activity.leadImage + '), linear-gradient( rgba(0, 0, 0, .4), rgba(0, 0, 0, 0.2) )';
        }
    };
    ActivityCardComponent.ctorParameters = function () { return [
        { type: Document, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["DOCUMENT"],] }] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Boolean)
    ], ActivityCardComponent.prototype, "loading", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], ActivityCardComponent.prototype, "activity", void 0);
    ActivityCardComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-activity-card',
            template: __importDefault(__webpack_require__(/*! raw-loader!./activity-card.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/activity-card/activity-card.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./activity-card.component.scss */ "./src/app/shared/components/activity-card/activity-card.component.scss")).default]
        }),
        __param(0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_common__WEBPACK_IMPORTED_MODULE_1__["DOCUMENT"])),
        __metadata("design:paramtypes", [Document])
    ], ActivityCardComponent);
    return ActivityCardComponent;
}());



/***/ }),

/***/ "./src/app/shared/components/branding-logo/branding-logo.component.ts":
/*!****************************************************************************!*\
  !*** ./src/app/shared/components/branding-logo/branding-logo.component.ts ***!
  \****************************************************************************/
/*! exports provided: BrandingLogoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrandingLogoComponent", function() { return BrandingLogoComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


var BrandingLogoComponent = /** @class */ (function () {
    function BrandingLogoComponent(storage) {
        this.storage = storage;
    }
    BrandingLogoComponent.ctorParameters = function () { return [
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_1__["BrowserStorageService"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], BrandingLogoComponent.prototype, "logo", void 0);
    BrandingLogoComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-branding-logo',
            template: __importDefault(__webpack_require__(/*! raw-loader!./branding-logo.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/branding-logo/branding-logo.component.html")).default,
        }),
        __metadata("design:paramtypes", [_services_storage_service__WEBPACK_IMPORTED_MODULE_1__["BrowserStorageService"]])
    ], BrandingLogoComponent);
    return BrandingLogoComponent;
}());



/***/ }),

/***/ "./src/app/shared/components/circle-progress/circle-progress.component.scss":
/*!**********************************************************************************!*\
  !*** ./src/app/shared/components/circle-progress/circle-progress.component.scss ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".skeleton {\n  display: -webkit-inline-box;\n  display: inline-flex;\n}\n.skeleton .progress-circle {\n  margin: 0;\n  border-radius: 50%;\n  max-width: 132px;\n  max-height: 132px;\n  width: 132px;\n  height: 132px;\n}\n.skeleton .progress-circle.desktop {\n  max-width: 166px;\n  max-height: 166px;\n  width: 166px;\n  height: 166px;\n}\n.skeleton .progress-content {\n  background: white !important;\n  border-radius: 50%;\n  position: absolute;\n  margin-top: 12px;\n  margin-left: 12px;\n  max-width: 108px;\n  max-height: 108px;\n  width: 108px;\n  height: 108px;\n}\n.skeleton .progress-content.desktop {\n  max-width: 142px;\n  max-height: 142px;\n  width: 142px;\n  height: 142px;\n}\n.skeleton .progress-content .labels {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n  width: 100%;\n}\n.skeleton .progress-content .labels p {\n  height: 12px;\n  min-height: 12px;\n  max-height: 12px;\n  display: inline-block;\n  margin: 0;\n}\n.skeleton .progress-content .labels p:nth-child(1) {\n  margin-bottom: 8px;\n  width: 90%;\n}\n.skeleton .progress-content .labels p:nth-child(2) {\n  width: 50%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGF3L1dvcmtzcGFjZXMvd3d3L2ludGVyc2VjdGl2ZS9wcmFjdGVyYS1hcHAtdjIvc3JjL2FwcC9zaGFyZWQvY29tcG9uZW50cy9jaXJjbGUtcHJvZ3Jlc3MvY2lyY2xlLXByb2dyZXNzLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9zaGFyZWQvY29tcG9uZW50cy9jaXJjbGUtcHJvZ3Jlc3MvY2lyY2xlLXByb2dyZXNzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksMkJBQUE7RUFBQSxvQkFBQTtBQ0NKO0FEQUk7RUFDRSxTQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNFTjtBRERNO0VBQ0UsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0FDR1I7QURBSTtFQUNFLDRCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNFTjtBRERNO0VBQ0UsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0FDR1I7QURETTtFQUNFLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSx3Q0FBQTtVQUFBLGdDQUFBO0VBQ0EsV0FBQTtBQ0dSO0FERlE7RUFDRSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLHFCQUFBO0VBQ0EsU0FBQTtBQ0lWO0FERlE7RUFDRSxrQkFBQTtFQUNBLFVBQUE7QUNJVjtBREZRO0VBQ0UsVUFBQTtBQ0lWIiwiZmlsZSI6InNyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvY2lyY2xlLXByb2dyZXNzL2NpcmNsZS1wcm9ncmVzcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5za2VsZXRvbntcbiAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbiAgICAucHJvZ3Jlc3MtY2lyY2xlIHtcbiAgICAgIG1hcmdpbjogMDtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgIG1heC13aWR0aDogMTMycHg7XG4gICAgICBtYXgtaGVpZ2h0OiAxMzJweDtcbiAgICAgIHdpZHRoOiAxMzJweDtcbiAgICAgIGhlaWdodDogMTMycHg7XG4gICAgICAmLmRlc2t0b3Age1xuICAgICAgICBtYXgtd2lkdGg6IDE2NnB4O1xuICAgICAgICBtYXgtaGVpZ2h0OiAxNjZweDtcbiAgICAgICAgd2lkdGg6IDE2NnB4O1xuICAgICAgICBoZWlnaHQ6IDE2NnB4O1xuICAgICAgfVxuICAgIH1cbiAgICAucHJvZ3Jlc3MtY29udGVudCB7XG4gICAgICBiYWNrZ3JvdW5kOiB3aGl0ZSAhaW1wb3J0YW50O1xuICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgbWFyZ2luLXRvcDogMTJweDtcbiAgICAgIG1hcmdpbi1sZWZ0OiAxMnB4O1xuICAgICAgbWF4LXdpZHRoOiAxMDhweDtcbiAgICAgIG1heC1oZWlnaHQ6IDEwOHB4O1xuICAgICAgd2lkdGg6IDEwOHB4O1xuICAgICAgaGVpZ2h0OiAxMDhweDtcbiAgICAgICYuZGVza3RvcCB7XG4gICAgICAgIG1heC13aWR0aDogMTQycHg7XG4gICAgICAgIG1heC1oZWlnaHQ6IDE0MnB4O1xuICAgICAgICB3aWR0aDogMTQycHg7XG4gICAgICAgIGhlaWdodDogMTQycHg7XG4gICAgICB9XG4gICAgICAubGFiZWxzIHtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICB0b3A6IDUwJTtcbiAgICAgICAgbGVmdDogNTAlO1xuICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIHAge1xuICAgICAgICAgIGhlaWdodDogMTJweDtcbiAgICAgICAgICBtaW4taGVpZ2h0OiAxMnB4O1xuICAgICAgICAgIG1heC1oZWlnaHQ6IDEycHg7XG4gICAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgICAgICAgIG1hcmdpbjogMDtcbiAgICAgICAgfVxuICAgICAgICBwOm50aC1jaGlsZCgxKSB7XG4gICAgICAgICAgbWFyZ2luLWJvdHRvbTogOHB4O1xuICAgICAgICAgIHdpZHRoOiA5MCU7XG4gICAgICAgIH1cbiAgICAgICAgcDpudGgtY2hpbGQoMikge1xuICAgICAgICAgIHdpZHRoOiA1MCU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgIiwiLnNrZWxldG9uIHtcbiAgZGlzcGxheTogaW5saW5lLWZsZXg7XG59XG4uc2tlbGV0b24gLnByb2dyZXNzLWNpcmNsZSB7XG4gIG1hcmdpbjogMDtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBtYXgtd2lkdGg6IDEzMnB4O1xuICBtYXgtaGVpZ2h0OiAxMzJweDtcbiAgd2lkdGg6IDEzMnB4O1xuICBoZWlnaHQ6IDEzMnB4O1xufVxuLnNrZWxldG9uIC5wcm9ncmVzcy1jaXJjbGUuZGVza3RvcCB7XG4gIG1heC13aWR0aDogMTY2cHg7XG4gIG1heC1oZWlnaHQ6IDE2NnB4O1xuICB3aWR0aDogMTY2cHg7XG4gIGhlaWdodDogMTY2cHg7XG59XG4uc2tlbGV0b24gLnByb2dyZXNzLWNvbnRlbnQge1xuICBiYWNrZ3JvdW5kOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbWFyZ2luLXRvcDogMTJweDtcbiAgbWFyZ2luLWxlZnQ6IDEycHg7XG4gIG1heC13aWR0aDogMTA4cHg7XG4gIG1heC1oZWlnaHQ6IDEwOHB4O1xuICB3aWR0aDogMTA4cHg7XG4gIGhlaWdodDogMTA4cHg7XG59XG4uc2tlbGV0b24gLnByb2dyZXNzLWNvbnRlbnQuZGVza3RvcCB7XG4gIG1heC13aWR0aDogMTQycHg7XG4gIG1heC1oZWlnaHQ6IDE0MnB4O1xuICB3aWR0aDogMTQycHg7XG4gIGhlaWdodDogMTQycHg7XG59XG4uc2tlbGV0b24gLnByb2dyZXNzLWNvbnRlbnQgLmxhYmVscyB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG4gIHdpZHRoOiAxMDAlO1xufVxuLnNrZWxldG9uIC5wcm9ncmVzcy1jb250ZW50IC5sYWJlbHMgcCB7XG4gIGhlaWdodDogMTJweDtcbiAgbWluLWhlaWdodDogMTJweDtcbiAgbWF4LWhlaWdodDogMTJweDtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBtYXJnaW46IDA7XG59XG4uc2tlbGV0b24gLnByb2dyZXNzLWNvbnRlbnQgLmxhYmVscyBwOm50aC1jaGlsZCgxKSB7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbiAgd2lkdGg6IDkwJTtcbn1cbi5za2VsZXRvbiAucHJvZ3Jlc3MtY29udGVudCAubGFiZWxzIHA6bnRoLWNoaWxkKDIpIHtcbiAgd2lkdGg6IDUwJTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/shared/components/circle-progress/circle-progress.component.ts":
/*!********************************************************************************!*\
  !*** ./src/app/shared/components/circle-progress/circle-progress.component.ts ***!
  \********************************************************************************/
/*! exports provided: CircleProgressComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CircleProgressComponent", function() { return CircleProgressComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


var CircleProgressComponent = /** @class */ (function () {
    function CircleProgressComponent(utils) {
        this.utils = utils;
        this.data = {};
        this.loading = false;
        this.largePlaceholderCircle = {
            animateTitle: false,
            animation: false,
            backgroundColor: '#e6e6e6',
            backgroundPadding: 0,
            maxPercent: 100,
            outerStrokeColor: '#f0f0f0',
            outerStrokeLinecap: 'butt',
            outerStrokeWidth: 12,
            percent: 100,
            radius: 70,
            showInnerStroke: false,
            showSubtitle: false,
            showTitle: false,
            showUnits: false,
            space: -20,
            startFromZero: false,
        };
        this.largeCircleWithData = {
            // back to default
            animateTitle: true,
            animation: true,
            outerStrokeLinecap: 'round',
            backgroundColor: 'var(--ion-color-light)',
            outerStrokeColor: 'var(--ion-color-primary)',
            innerStrokeWidth: 4,
            showInnerStroke: true,
            showSubtitle: true,
            showTitle: true,
            showUnits: true,
            space: 4,
            // custom
            backgroundPadding: -10,
            maxPercent: 100,
            outerStrokeWidth: 12,
            percent: 0,
            radius: 70,
            subtitle: 'COMPLETE',
            startFromZero: true,
        };
        this.smallPlaceholderCircle = {
            animateTitle: false,
            animation: false,
            outerStrokeWidth: 8,
            outerStrokeColor: '#f0f0f0',
            backgroundColor: '#e6e6e6',
            backgroundStrokeWidth: 1,
            backgroundPadding: 8,
            maxPercent: 100,
            outerStrokeLinecap: 'butt',
            percent: 100,
            radius: 15,
            showInnerStroke: true,
            showSubtitle: false,
            showTitle: false,
            showUnits: false,
            space: -15,
            startFromZero: false,
            toFixed: 0,
            subtitle: false,
        };
        this.smallCircleWithData = {
            animation: true,
            backgroundColor: 'var(--ion-color-light)',
            maxPercent: 100,
            innerStrokeWidth: 2,
            outerStrokeColor: 'var(--ion-color-primary)',
            percent: 0,
            space: -12,
            radius: 4,
            startFromZero: true,
        };
    }
    CircleProgressComponent.prototype.ngOnInit = function () {
        if (this.data) {
            this.config = this.setCircleProgress(this.data);
        }
        else if (this.type === 'large') {
            this.config = this.largePlaceholderCircle;
        }
        else {
            // by default, show small circle
            this.config = this.smallPlaceholderCircle;
        }
    };
    CircleProgressComponent.prototype.ngOnChanges = function (changes) {
        if (changes.data) {
            this.config = this.setCircleProgress(changes.data.currentValue);
        }
    };
    CircleProgressComponent.prototype.setCircleProgress = function (data) {
        if (this.type === 'large') {
            return __assign(__assign(__assign({}, this.largePlaceholderCircle), this.largeCircleWithData), data);
        }
        return __assign(__assign(__assign({}, this.smallPlaceholderCircle), this.smallCircleWithData), data);
    };
    CircleProgressComponent.ctorParameters = function () { return [
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_1__["UtilsService"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], CircleProgressComponent.prototype, "data", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], CircleProgressComponent.prototype, "type", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], CircleProgressComponent.prototype, "loading", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('description'),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"])
    ], CircleProgressComponent.prototype, "descriptionRef", void 0);
    CircleProgressComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-circle-progress',
            template: __importDefault(__webpack_require__(/*! raw-loader!./circle-progress.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/circle-progress/circle-progress.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./circle-progress.component.scss */ "./src/app/shared/components/circle-progress/circle-progress.component.scss")).default]
        }),
        __metadata("design:paramtypes", [_services_utils_service__WEBPACK_IMPORTED_MODULE_1__["UtilsService"]])
    ], CircleProgressComponent);
    return CircleProgressComponent;
}());



/***/ }),

/***/ "./src/app/shared/components/clickable-item/clickable-item.component.scss":
/*!********************************************************************************!*\
  !*** ./src/app/shared/components/clickable-item/clickable-item.component.scss ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".active {\n  --background: var(--ion-color-primary-tint);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGF3L1dvcmtzcGFjZXMvd3d3L2ludGVyc2VjdGl2ZS9wcmFjdGVyYS1hcHAtdjIvc3JjL2FwcC9zaGFyZWQvY29tcG9uZW50cy9jbGlja2FibGUtaXRlbS9jbGlja2FibGUtaXRlbS5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvY2xpY2thYmxlLWl0ZW0vY2xpY2thYmxlLWl0ZW0uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSwyQ0FBQTtBQ0NGIiwiZmlsZSI6InNyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvY2xpY2thYmxlLWl0ZW0vY2xpY2thYmxlLWl0ZW0uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYWN0aXZlIHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10aW50KTtcbn1cbiIsIi5hY3RpdmUge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXRpbnQpO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/shared/components/clickable-item/clickable-item.component.ts":
/*!******************************************************************************!*\
  !*** ./src/app/shared/components/clickable-item/clickable-item.component.ts ***!
  \******************************************************************************/
/*! exports provided: ClickableItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClickableItemComponent", function() { return ClickableItemComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

var ClickableItemComponent = /** @class */ (function () {
    function ClickableItemComponent() {
    }
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], ClickableItemComponent.prototype, "lines", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], ClickableItemComponent.prototype, "backgroundColor", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], ClickableItemComponent.prototype, "isSwitcherCard", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], ClickableItemComponent.prototype, "active", void 0);
    ClickableItemComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'clickable-item',
            template: __importDefault(__webpack_require__(/*! raw-loader!./clickable-item.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/clickable-item/clickable-item.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./clickable-item.component.scss */ "./src/app/shared/components/clickable-item/clickable-item.component.scss")).default]
        }),
        __metadata("design:paramtypes", [])
    ], ClickableItemComponent);
    return ClickableItemComponent;
}());



/***/ }),

/***/ "./src/app/shared/components/contact-number-form/contact-number-form.component.scss":
/*!******************************************************************************************!*\
  !*** ./src/app/shared/components/contact-number-form/contact-number-form.component.scss ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-card {\n  box-shadow: none;\n  margin: 16px 0 10px;\n}\nion-card ion-select {\n  padding-left: 0px;\n  padding-right: 10px;\n}\nion-card ion-select:after {\n  content: \"\";\n  position: absolute;\n  right: 5px;\n  width: 1px;\n  background-color: var(--practera-color-card-border);\n  height: 80%;\n  top: 10%;\n}\nion-card.desktop-view {\n  max-width: 342px !important;\n}\n.contact-input {\n  margin-top: 8px;\n  width: 100%;\n  border: none;\n}\n.contact-input:focus {\n  outline: none;\n}\n.text-field ion-col {\n  padding-top: 0px;\n  padding-left: 0;\n  padding-right: 0;\n  text-align: center;\n}\n.text-field ion-col p.country-code {\n  margin-bottom: 0;\n  margin-top: 10px;\n  font-weight: bold;\n}\n.text-field ion-col.contact-details {\n  padding-bottom: 0;\n  padding-left: 0;\n}\nion-select {\n  max-width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGF3L1dvcmtzcGFjZXMvd3d3L2ludGVyc2VjdGl2ZS9wcmFjdGVyYS1hcHAtdjIvc3JjL2FwcC9zaGFyZWQvY29tcG9uZW50cy9jb250YWN0LW51bWJlci1mb3JtL2NvbnRhY3QtbnVtYmVyLWZvcm0uY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3NoYXJlZC9jb21wb25lbnRzL2NvbnRhY3QtbnVtYmVyLWZvcm0vY29udGFjdC1udW1iZXItZm9ybS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0VBY0EsbUJBQUE7QUNaRjtBRERFO0VBQ0UsaUJBQUE7RUFDQSxtQkFBQTtBQ0dKO0FEREU7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsVUFBQTtFQUNBLG1EQUFBO0VBQ0EsV0FBQTtFQUNBLFFBQUE7QUNHSjtBREFFO0VBQ0UsMkJBQUE7QUNFSjtBREVBO0VBQ0UsZUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDQ0Y7QURBRTtFQUNFLGFBQUE7QUNFSjtBREdFO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQ0FKO0FER007RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUNEUjtBREtJO0VBQ0UsaUJBQUE7RUFDQSxlQUFBO0FDSE47QURRQTtFQUNFLGVBQUE7QUNMRiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9jb21wb25lbnRzL2NvbnRhY3QtbnVtYmVyLWZvcm0vY29udGFjdC1udW1iZXItZm9ybS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jYXJkIHtcbiAgYm94LXNoYWRvdzogbm9uZTtcbiAgaW9uLXNlbGVjdCB7XG4gICAgcGFkZGluZy1sZWZ0OiAwcHg7XG4gICAgcGFkZGluZy1yaWdodDogMTBweDtcbiAgfVxuICBpb24tc2VsZWN0OmFmdGVyIHtcbiAgICBjb250ZW50OiBcIlwiO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICByaWdodDogNXB4O1xuICAgIHdpZHRoOiAxcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tcHJhY3RlcmEtY29sb3ItY2FyZC1ib3JkZXIpO1xuICAgIGhlaWdodDogODAlO1xuICAgIHRvcDogMTAlO1xuICB9XG4gIG1hcmdpbjogMTZweCAwIDEwcHg7XG4gICYuZGVza3RvcC12aWV3IHtcbiAgICBtYXgtd2lkdGg6IDM0MnB4ICFpbXBvcnRhbnQ7XG4gIH1cbn1cblxuLmNvbnRhY3QtaW5wdXQge1xuICBtYXJnaW4tdG9wOiA4cHg7XG4gIHdpZHRoOiAxMDAlO1xuICBib3JkZXI6IG5vbmU7XG4gICY6Zm9jdXMge1xuICAgIG91dGxpbmU6IG5vbmU7XG4gIH1cbn1cblxuLnRleHQtZmllbGQge1xuICBpb24tY29sIHtcbiAgICBwYWRkaW5nLXRvcDogMHB4O1xuICAgIHBhZGRpbmctbGVmdDogMDtcbiAgICBwYWRkaW5nLXJpZ2h0OiAwO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcblxuICAgIHAge1xuICAgICAgJi5jb3VudHJ5LWNvZGUge1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAwO1xuICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAmLmNvbnRhY3QtZGV0YWlscyB7XG4gICAgICBwYWRkaW5nLWJvdHRvbTogMDtcbiAgICAgIHBhZGRpbmctbGVmdDogMDtcbiAgICB9XG4gIH1cbn1cblxuaW9uLXNlbGVjdCB7XG4gIG1heC13aWR0aDogMTAwJTtcbn1cbiIsImlvbi1jYXJkIHtcbiAgYm94LXNoYWRvdzogbm9uZTtcbiAgbWFyZ2luOiAxNnB4IDAgMTBweDtcbn1cbmlvbi1jYXJkIGlvbi1zZWxlY3Qge1xuICBwYWRkaW5nLWxlZnQ6IDBweDtcbiAgcGFkZGluZy1yaWdodDogMTBweDtcbn1cbmlvbi1jYXJkIGlvbi1zZWxlY3Q6YWZ0ZXIge1xuICBjb250ZW50OiBcIlwiO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiA1cHg7XG4gIHdpZHRoOiAxcHg7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXByYWN0ZXJhLWNvbG9yLWNhcmQtYm9yZGVyKTtcbiAgaGVpZ2h0OiA4MCU7XG4gIHRvcDogMTAlO1xufVxuaW9uLWNhcmQuZGVza3RvcC12aWV3IHtcbiAgbWF4LXdpZHRoOiAzNDJweCAhaW1wb3J0YW50O1xufVxuXG4uY29udGFjdC1pbnB1dCB7XG4gIG1hcmdpbi10b3A6IDhweDtcbiAgd2lkdGg6IDEwMCU7XG4gIGJvcmRlcjogbm9uZTtcbn1cbi5jb250YWN0LWlucHV0OmZvY3VzIHtcbiAgb3V0bGluZTogbm9uZTtcbn1cblxuLnRleHQtZmllbGQgaW9uLWNvbCB7XG4gIHBhZGRpbmctdG9wOiAwcHg7XG4gIHBhZGRpbmctbGVmdDogMDtcbiAgcGFkZGluZy1yaWdodDogMDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLnRleHQtZmllbGQgaW9uLWNvbCBwLmNvdW50cnktY29kZSB7XG4gIG1hcmdpbi1ib3R0b206IDA7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuLnRleHQtZmllbGQgaW9uLWNvbC5jb250YWN0LWRldGFpbHMge1xuICBwYWRkaW5nLWJvdHRvbTogMDtcbiAgcGFkZGluZy1sZWZ0OiAwO1xufVxuXG5pb24tc2VsZWN0IHtcbiAgbWF4LXdpZHRoOiAxMDAlO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/shared/components/contact-number-form/contact-number-form.component.ts":
/*!****************************************************************************************!*\
  !*** ./src/app/shared/components/contact-number-form/contact-number-form.component.ts ***!
  \****************************************************************************************/
/*! exports provided: ContactNumberFormComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactNumberFormComponent", function() { return ContactNumberFormComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _app_settings_setting_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @app/settings/setting.service */ "./src/app/settings/setting.service.ts");
/* harmony import */ var _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @shared/notification/notification.service */ "./src/app/shared/notification/notification.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};






var ContactNumberFormComponent = /** @class */ (function () {
    function ContactNumberFormComponent(storage, utils, settingService, notificationService) {
        this.storage = storage;
        this.utils = utils;
        this.settingService = settingService;
        this.notificationService = notificationService;
        this.updateNumber = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        // use to pass data to api
        this.profile = {
            contactNumber: '',
            email: ''
        };
        // use as a ngModel to controll contact number input
        this.contactNumber = '';
        // country model infomation
        this.activeCountryModelInfo = {
            countryCode: '',
            placeholder: '',
            pattern: '',
            length: ''
        };
        // variable to control the update button
        this.updating = false;
        this.contactNumberFormat = {
            masks: {
                AUS: {
                    format: '+61',
                    placeholder: '000 000 000',
                    pattern: '^[0-9]{3}[\s\-]?[\0-9]{3}[\s\-]?[0-9]{3}$',
                    numberLength: '11'
                },
                US: {
                    format: '+1',
                    placeholder: '000 000 0000',
                    pattern: '^[0-9]{3}[\s\-]?[\0-9]{3}[\s\-]?[0-9]{4}$',
                    numberLength: '12'
                },
                NZ: {
                    format: '+64',
                    placeholder: '0000000000',
                    pattern: '^[0-9]{9-10}$',
                    numberLength: '12'
                },
                DE: {
                    format: '+49',
                    placeholder: '000 000 000',
                    pattern: '^[0-9]{3}[\s\-]?[\0-9]{3}[\s\-]?[0-9]{4}$',
                    numberLength: '12'
                },
                UK: {
                    format: '+44',
                    placeholder: '00 0000 0000',
                    pattern: '^[0-9]{2}[\s\-]?[\0-9]{4}[\s\-]?[0-9]{4}$',
                    numberLength: '12'
                }
            },
            countryCodes: [
                {
                    name: 'Australia',
                    code: 'AUS'
                },
                {
                    name: 'US/Canada',
                    code: 'US'
                },
                {
                    name: 'New Zealand',
                    code: 'NZ'
                },
                {
                    name: 'Germany',
                    code: 'DE'
                },
                {
                    name: 'United Kingdom',
                    code: 'UK'
                }
            ]
        };
    }
    ContactNumberFormComponent.prototype.ngOnInit = function () {
        this._initcomponent();
    };
    ContactNumberFormComponent.prototype._initcomponent = function () {
        this.countryModel = _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].defaultCountryModel;
        this.activeCountryModelInfo.countryCode = this.contactNumberFormat.masks[this.countryModel].format;
        this.activeCountryModelInfo.placeholder = this.contactNumberFormat.masks[this.countryModel].placeholder;
        this.activeCountryModelInfo.pattern = this.contactNumberFormat.masks[this.countryModel].pattern;
        this.activeCountryModelInfo.length = this.contactNumberFormat.masks[this.countryModel].numberLength;
        // if user has the contact number
        if (this.page === 'settings' && (this.storage.getUser().contactNumber && this.storage.getUser().contactNumber != null)) {
            this._checkCurrentContactNumberOrigin();
        }
    };
    ContactNumberFormComponent.prototype._checkCurrentContactNumberOrigin = function () {
        var contactNum = this.storage.getUser().contactNumber;
        var prefix = contactNum.substring(0, 3);
        var number = contactNum.substring(3);
        this.contactNumber = this._separeteContactNumber(number);
        switch (prefix) {
            case '+61':
                this._setCountry('AUS');
                return;
            case '+64':
                this._setCountry('NZ');
                return;
            case '+49':
                this._setCountry('DE');
                return;
            case '+44':
                this._setCountry('UK');
                return;
        }
        prefix = contactNum.substring(0, 2);
        number = contactNum.substring(2);
        this.contactNumber = this._separeteContactNumber(number);
        switch (prefix) {
            case '61':
            case '04':
                this._setCountry('AUS');
                return;
            case '+1':
                this._setCountry('US');
                return;
        }
        prefix = contactNum.substring(0, 1);
        number = contactNum.substring(1);
        this.contactNumber = this._separeteContactNumber(number);
        if (prefix === '1') {
            this._setCountry('US');
            return;
        }
        if (prefix === '0') {
            this._setCountry('AUS');
            return;
        }
    };
    ContactNumberFormComponent.prototype._setCountry = function (country) {
        this.countryModel = country;
        this.activeCountryModelInfo.countryCode = this.contactNumberFormat.masks[this.countryModel].format;
        this.activeCountryModelInfo.placeholder = this.contactNumberFormat.masks[this.countryModel].placeholder;
        this.activeCountryModelInfo.pattern = this.contactNumberFormat.masks[this.countryModel].pattern;
        this.activeCountryModelInfo.length = this.contactNumberFormat.masks[this.countryModel].numberLength;
    };
    /**
     * Accept only certain keys
     * @description accepted keys limited to:
     *              - 'ArrowLeft', 'ArrowRight', 'Backspace', 'Delete'
     *              - numeric key input
     * @param  {KeyboardEvent} event code (function keypress) & key (for non-numeric input)
     * @return {boolean}             true: key accepted, false: key skipped
     */
    ContactNumberFormComponent.prototype.disableArrowKeys = function (event) {
        if (['ArrowLeft', 'ArrowRight', 'Backspace', 'Delete'].indexOf(event.code) !== -1) {
            return true;
        }
        // skip all non-numeric input
        if (['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'].indexOf(event.key) === -1) {
            return false;
        }
        return true;
    };
    ContactNumberFormComponent.prototype.formatContactNumber = function () {
        this.contactNumber = this._separeteContactNumber(this.contactNumber);
        if (this.page === 'go-mobile') {
            this.updateNumber.emit(this.activeCountryModelInfo.countryCode + this.contactNumber);
        }
    };
    ContactNumberFormComponent.prototype._separeteContactNumber = function (text) {
        var result = [];
        text = text.replace(/[^\d]/g, '');
        while (text.length >= 3) {
            result.push(text.substring(0, 3));
            text = text.substring(3);
        }
        if (text.length > 0) {
            result.push(text);
        }
        return result.join(' ');
    };
    ContactNumberFormComponent.prototype.updateCountry = function () {
        var selectedCountry = this.countryModel;
        var country = this.utils.find(this.contactNumberFormat.countryCodes, function (eachCountry) {
            return eachCountry.code === selectedCountry;
        });
        this.activeCountryModelInfo.countryCode = this.contactNumberFormat.masks[this.countryModel].format;
        this.activeCountryModelInfo.placeholder = this.contactNumberFormat.masks[this.countryModel].placeholder;
        this.activeCountryModelInfo.pattern = this.contactNumberFormat.masks[this.countryModel].pattern;
        this.activeCountryModelInfo.length = this.contactNumberFormat.masks[this.countryModel].numberLength;
        // set currentContactNumber to it's format.
        this.contactNumber = '';
        if (this.page === 'go-mobile') {
            this.updateNumber.emit(this.activeCountryModelInfo.countryCode + this.contactNumber);
        }
    };
    ContactNumberFormComponent.prototype.updateContactNumber = function () {
        var _this = this;
        this.profile.contactNumber = this.activeCountryModelInfo.countryCode + this.contactNumber;
        // strip out white spaces and underscores
        this.profile.contactNumber = this.profile.contactNumber.replace(/[^0-9+]+/ig, '');
        // check if newly input number is valid or not.
        if (!this.validateContactNumber(this.profile.contactNumber)) {
            return this.notificationService.presentToast('Invalid contact number');
        }
        this.updating = true;
        return this.notificationService.alert({
            header: 'Update Profile',
            message: 'Are you sure to update your profile?',
            buttons: [
                {
                    text: 'Cancel',
                    role: 'cancel',
                    handler: function () {
                        _this.updating = false;
                        return;
                    }
                },
                {
                    text: 'Okay',
                    handler: function () {
                        _this.settingService.updateProfile({
                            contact_number: _this.profile.contactNumber,
                        }).subscribe(function (result) {
                            _this.updating = false;
                            if (result.success) {
                                // update contact number in user local storage data array.
                                _this.storage.setUser({ contactNumber: _this.profile.contactNumber });
                                var newContactNumber_1 = _this.profile.contactNumber;
                                // also update contact number in program object in local storage
                                var timelineId_1 = _this.storage.getUser().timelineId; // get current timeline Id
                                var programsObj = _this.utils.each(_this.storage.get('programs'), function (program) {
                                    if (program.timeline.id === timelineId_1) {
                                        program.enrolment.contact_number = newContactNumber_1;
                                    }
                                });
                                _this.storage.set('programs', programsObj);
                                return _this.notificationService.popUp('shortMessage', { message: 'Profile successfully updated!' });
                            }
                            else {
                                return _this.notificationService.popUp('shortMessage', { message: 'Profile updating failed!' });
                            }
                        });
                    }
                }
            ]
        });
    };
    ContactNumberFormComponent.prototype.validateContactNumber = function (contactNumber) {
        switch (this.countryModel) {
            case 'AUS':
            case 'DE':
                if (contactNumber.length === 12) {
                    return true;
                }
                else if (contactNumber.length === 3) {
                    this.profile.contactNumber = null;
                    return true;
                }
                break;
            case 'NZ':
                if (contactNumber.length === 12 || contactNumber.length === 13) {
                    return true;
                }
                else if (contactNumber.length === 3) {
                    this.profile.contactNumber = null;
                    return true;
                }
                break;
            case 'US':
                if (contactNumber.length === 12) {
                    return true;
                }
                else if (contactNumber.length === 2) {
                    this.profile.contactNumber = null;
                    return true;
                }
                break;
            case 'UK':
                if (contactNumber.length === 13) {
                    return true;
                }
                else if (contactNumber.length === 3) {
                    this.profile.contactNumber = null;
                    return true;
                }
                break;
        }
        return false;
    };
    ContactNumberFormComponent.ctorParameters = function () { return [
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__["BrowserStorageService"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_1__["UtilsService"] },
        { type: _app_settings_setting_service__WEBPACK_IMPORTED_MODULE_4__["SettingService"] },
        { type: _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], ContactNumberFormComponent.prototype, "page", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], ContactNumberFormComponent.prototype, "updateNumber", void 0);
    ContactNumberFormComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-contact-number-form',
            template: __importDefault(__webpack_require__(/*! raw-loader!./contact-number-form.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/contact-number-form/contact-number-form.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./contact-number-form.component.scss */ "./src/app/shared/components/contact-number-form/contact-number-form.component.scss")).default]
        }),
        __metadata("design:paramtypes", [_services_storage_service__WEBPACK_IMPORTED_MODULE_2__["BrowserStorageService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_1__["UtilsService"],
            _app_settings_setting_service__WEBPACK_IMPORTED_MODULE_4__["SettingService"],
            _shared_notification_notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"]])
    ], ContactNumberFormComponent);
    return ContactNumberFormComponent;
}());



/***/ }),

/***/ "./src/app/shared/components/description/description.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/shared/components/description/description.component.scss ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: auto;\n  min-height: 20%;\n  overflow: hidden;\n}\n.container .text-content {\n  overflow: hidden;\n  min-height: 64px;\n  max-height: 100%;\n}\n.limit-height {\n  max-height: 90px;\n  text-overflow: ellipsis;\n  -webkit-animation-name: collapse;\n          animation-name: collapse;\n  -webkit-animation-duration: 0.5s;\n          animation-duration: 0.5s;\n}\n.full-height {\n  max-height: 100%;\n  overflow: visible;\n  -webkit-animation-name: expand;\n          animation-name: expand;\n  -webkit-animation-duration: 0.5s;\n          animation-duration: 0.5s;\n}\n.full-height-popup {\n  max-height: 200px;\n  overflow: auto;\n  -webkit-animation-name: expand;\n          animation-name: expand;\n  -webkit-animation-duration: 0.5s;\n          animation-duration: 0.5s;\n}\n@-webkit-keyframes collapse {\n  from {\n    max-height: 1000px;\n  }\n  to {\n    max-height: 90px;\n  }\n}\n@keyframes collapse {\n  from {\n    max-height: 1000px;\n  }\n  to {\n    max-height: 90px;\n  }\n}\n@-webkit-keyframes expand {\n  from {\n    max-height: 90px;\n  }\n  to {\n    max-height: 1000px;\n  }\n}\n@keyframes expand {\n  from {\n    max-height: 90px;\n  }\n  to {\n    max-height: 1000px;\n  }\n}\nion-button {\n  --background-hover: transparent !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGF3L1dvcmtzcGFjZXMvd3d3L2ludGVyc2VjdGl2ZS9wcmFjdGVyYS1hcHAtdjIvc3JjL2FwcC9zaGFyZWQvY29tcG9uZW50cy9kZXNjcmlwdGlvbi9kZXNjcmlwdGlvbi5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvZGVzY3JpcHRpb24vZGVzY3JpcHRpb24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FDQ0Y7QURBRTtFQUNFLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQ0VKO0FERUE7RUFDRSxnQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZ0NBQUE7VUFBQSx3QkFBQTtFQUNBLGdDQUFBO1VBQUEsd0JBQUE7QUNDRjtBREVBO0VBQ0UsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLDhCQUFBO1VBQUEsc0JBQUE7RUFDQSxnQ0FBQTtVQUFBLHdCQUFBO0FDQ0Y7QURFQTtFQUNFLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLDhCQUFBO1VBQUEsc0JBQUE7RUFDQSxnQ0FBQTtVQUFBLHdCQUFBO0FDQ0Y7QURFQTtFQUNFO0lBQU8sa0JBQUE7RUNFUDtFRERBO0lBQUssZ0JBQUE7RUNJTDtBQUNGO0FEUEE7RUFDRTtJQUFPLGtCQUFBO0VDRVA7RUREQTtJQUFLLGdCQUFBO0VDSUw7QUFDRjtBREZBO0VBQ0U7SUFBTyxnQkFBQTtFQ0tQO0VESkE7SUFBSyxrQkFBQTtFQ09MO0FBQ0Y7QURWQTtFQUNFO0lBQU8sZ0JBQUE7RUNLUDtFREpBO0lBQUssa0JBQUE7RUNPTDtBQUNGO0FETEE7RUFDRSwwQ0FBQTtBQ09GIiwiZmlsZSI6InNyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvZGVzY3JpcHRpb24vZGVzY3JpcHRpb24uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGFpbmVyIHtcbiAgdG9wOiAwO1xuICBsZWZ0OiAwO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiBhdXRvO1xuICBtaW4taGVpZ2h0OiAyMCU7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIC50ZXh0LWNvbnRlbnQge1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgbWluLWhlaWdodDogNjRweDtcbiAgICBtYXgtaGVpZ2h0OiAxMDAlO1xuICB9XG59XG5cbi5saW1pdC1oZWlnaHQge1xuICBtYXgtaGVpZ2h0OiA5MHB4O1xuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgYW5pbWF0aW9uLW5hbWU6IGNvbGxhcHNlO1xuICBhbmltYXRpb24tZHVyYXRpb246IDAuNXM7XG59XG5cbi5mdWxsLWhlaWdodCB7XG4gIG1heC1oZWlnaHQ6IDEwMCU7XG4gIG92ZXJmbG93OiB2aXNpYmxlO1xuICBhbmltYXRpb24tbmFtZTogZXhwYW5kO1xuICBhbmltYXRpb24tZHVyYXRpb246IDAuNXM7XG59XG5cbi5mdWxsLWhlaWdodC1wb3B1cCB7XG4gIG1heC1oZWlnaHQ6IDIwMHB4O1xuICBvdmVyZmxvdzogYXV0bztcbiAgYW5pbWF0aW9uLW5hbWU6IGV4cGFuZDtcbiAgYW5pbWF0aW9uLWR1cmF0aW9uOiAwLjVzO1xufVxuXG5Aa2V5ZnJhbWVzIGNvbGxhcHNlIHtcbiAgZnJvbSB7IG1heC1oZWlnaHQ6IDEwMDBweDt9XG4gIHRvIHsgbWF4LWhlaWdodDogOTBweDt9XG59XG5cbkBrZXlmcmFtZXMgZXhwYW5kIHtcbiAgZnJvbSB7IG1heC1oZWlnaHQ6IDkwcHg7fVxuICB0byB7IG1heC1oZWlnaHQ6IDEwMDBweDt9XG59XG5cbmlvbi1idXR0b24ge1xuICAtLWJhY2tncm91bmQtaG92ZXI6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG59XG4iLCIuY29udGFpbmVyIHtcbiAgdG9wOiAwO1xuICBsZWZ0OiAwO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiBhdXRvO1xuICBtaW4taGVpZ2h0OiAyMCU7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG4uY29udGFpbmVyIC50ZXh0LWNvbnRlbnQge1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBtaW4taGVpZ2h0OiA2NHB4O1xuICBtYXgtaGVpZ2h0OiAxMDAlO1xufVxuXG4ubGltaXQtaGVpZ2h0IHtcbiAgbWF4LWhlaWdodDogOTBweDtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIGFuaW1hdGlvbi1uYW1lOiBjb2xsYXBzZTtcbiAgYW5pbWF0aW9uLWR1cmF0aW9uOiAwLjVzO1xufVxuXG4uZnVsbC1oZWlnaHQge1xuICBtYXgtaGVpZ2h0OiAxMDAlO1xuICBvdmVyZmxvdzogdmlzaWJsZTtcbiAgYW5pbWF0aW9uLW5hbWU6IGV4cGFuZDtcbiAgYW5pbWF0aW9uLWR1cmF0aW9uOiAwLjVzO1xufVxuXG4uZnVsbC1oZWlnaHQtcG9wdXAge1xuICBtYXgtaGVpZ2h0OiAyMDBweDtcbiAgb3ZlcmZsb3c6IGF1dG87XG4gIGFuaW1hdGlvbi1uYW1lOiBleHBhbmQ7XG4gIGFuaW1hdGlvbi1kdXJhdGlvbjogMC41cztcbn1cblxuQGtleWZyYW1lcyBjb2xsYXBzZSB7XG4gIGZyb20ge1xuICAgIG1heC1oZWlnaHQ6IDEwMDBweDtcbiAgfVxuICB0byB7XG4gICAgbWF4LWhlaWdodDogOTBweDtcbiAgfVxufVxuQGtleWZyYW1lcyBleHBhbmQge1xuICBmcm9tIHtcbiAgICBtYXgtaGVpZ2h0OiA5MHB4O1xuICB9XG4gIHRvIHtcbiAgICBtYXgtaGVpZ2h0OiAxMDAwcHg7XG4gIH1cbn1cbmlvbi1idXR0b24ge1xuICAtLWJhY2tncm91bmQtaG92ZXI6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG59Il19 */");

/***/ }),

/***/ "./src/app/shared/components/description/description.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/shared/components/description/description.component.ts ***!
  \************************************************************************/
/*! exports provided: DescriptionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DescriptionComponent", function() { return DescriptionComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm5/platform-browser.js");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



var DescriptionComponent = /** @class */ (function () {
    function DescriptionComponent(storage, sanitizer) {
        this.storage = storage;
        this.sanitizer = sanitizer;
        this.heightLimit = 120;
        this.isTruncating = false;
        this.heightExceeded = false;
    }
    DescriptionComponent.prototype.ngOnChanges = function (changes) {
        this.content = this.sanitizer.bypassSecurityTrustHtml(changes.content.currentValue);
        this.calculateHeight();
    };
    DescriptionComponent.prototype.ngAfterViewInit = function () {
        this.calculateHeight();
    };
    DescriptionComponent.prototype.calculateHeight = function () {
        var _this = this;
        if (!this.storage.getUser().truncateDescription) {
            return;
        }
        setTimeout(function () {
            _this.elementHeight = _this.descriptionRef.nativeElement.clientHeight;
            _this.heightExceeded = _this.elementHeight >= _this.heightLimit;
            if (_this.heightExceeded) {
                _this.isTruncating = true;
            }
        }, 1000);
    };
    DescriptionComponent.ctorParameters = function () { return [
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__["BrowserStorageService"] },
        { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["DomSanitizer"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], DescriptionComponent.prototype, "content", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], DescriptionComponent.prototype, "isInPopup", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('description'),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"])
    ], DescriptionComponent.prototype, "descriptionRef", void 0);
    DescriptionComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-description',
            template: __importDefault(__webpack_require__(/*! raw-loader!./description.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/description/description.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./description.component.scss */ "./src/app/shared/components/description/description.component.scss")).default]
        }),
        __metadata("design:paramtypes", [_services_storage_service__WEBPACK_IMPORTED_MODULE_2__["BrowserStorageService"],
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["DomSanitizer"]])
    ], DescriptionComponent);
    return DescriptionComponent;
}());



/***/ }),

/***/ "./src/app/shared/components/icon/icon.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/shared/components/icon/icon.component.ts ***!
  \**********************************************************/
/*! exports provided: IconComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IconComponent", function() { return IconComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

var IconComponent = /** @class */ (function () {
    function IconComponent() {
        this.iconDir = this.getIcon(this.name);
    }
    IconComponent.prototype.getIcon = function (icon) {
        switch (icon) {
            case 'checkmark':
                return '/assets/checkmark.svg';
        }
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], IconComponent.prototype, "name", void 0);
    IconComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'icon-custom',
            template: __importDefault(__webpack_require__(/*! raw-loader!./icon.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/icon/icon.component.html")).default
        }),
        __metadata("design:paramtypes", [])
    ], IconComponent);
    return IconComponent;
}());



/***/ }),

/***/ "./src/app/shared/components/img/img.component.scss":
/*!**********************************************************!*\
  !*** ./src/app/shared/components/img/img.component.scss ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".flip {\n  -webkit-transform: scaleX(-1);\n  transform: scaleX(-1);\n}\n\n.rotate-180 {\n  -webkit-transform: rotate(180deg);\n          transform: rotate(180deg);\n}\n\n.flip-and-rotate-180 {\n  transform: rotateY(-180deg);\n  -ms-transform: rotateY(-180deg);\n  -webkit-transform: rotateY(-180deg);\n}\n\n.flip-and-rotate-270 {\n  transform: rotate(-270deg);\n  -ms-transform: rotate(-270deg);\n  -webkit-transform: rotate(-270deg);\n}\n\n.rotate-90 {\n  -webkit-transform: rotate(90deg);\n          transform: rotate(90deg);\n}\n\n.flip-and-rotate-90 {\n  transform: rotate(-90deg);\n  -ms-transform: rotate(-90deg);\n  -webkit-transform: rotate(-90deg);\n}\n\n.rotate-270 {\n  -webkit-transform: rotate(270deg);\n          transform: rotate(270deg);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGF3L1dvcmtzcGFjZXMvd3d3L2ludGVyc2VjdGl2ZS9wcmFjdGVyYS1hcHAtdjIvc3JjL2FwcC9zaGFyZWQvY29tcG9uZW50cy9pbWcvaW1nLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9zaGFyZWQvY29tcG9uZW50cy9pbWcvaW1nLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsNkJBQUE7RUFDQSxxQkFBQTtBQ0NGOztBRENBO0VBQ0UsaUNBQUE7VUFBQSx5QkFBQTtBQ0VGOztBREFBO0VBQ0UsMkJBQUE7RUFDQSwrQkFBQTtFQUNBLG1DQUFBO0FDR0Y7O0FEREE7RUFDRSwwQkFBQTtFQUNBLDhCQUFBO0VBQ0Esa0NBQUE7QUNJRjs7QURGQTtFQUNFLGdDQUFBO1VBQUEsd0JBQUE7QUNLRjs7QURIQTtFQUNFLHlCQUFBO0VBQ0EsNkJBQUE7RUFDQSxpQ0FBQTtBQ01GOztBREpBO0VBQ0UsaUNBQUE7VUFBQSx5QkFBQTtBQ09GIiwiZmlsZSI6InNyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvaW1nL2ltZy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5mbGlwIHtcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlWCgtMSk7XG4gIHRyYW5zZm9ybTogc2NhbGVYKC0xKTtcbn1cbi5yb3RhdGUtMTgwIHtcbiAgdHJhbnNmb3JtOiByb3RhdGUoMTgwZGVnKTtcbn1cbi5mbGlwLWFuZC1yb3RhdGUtMTgwIHtcbiAgdHJhbnNmb3JtOiByb3RhdGVZKC0xODBkZWcpO1xuICAtbXMtdHJhbnNmb3JtOiByb3RhdGVZKC0xODBkZWcpO1xuICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlWSgtMTgwZGVnKTtcbn1cbi5mbGlwLWFuZC1yb3RhdGUtMjcwIHtcbiAgdHJhbnNmb3JtOiByb3RhdGUoLTI3MGRlZyk7XG4gIC1tcy10cmFuc2Zvcm06IHJvdGF0ZSgtMjcwZGVnKTtcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZSgtMjcwZGVnKTtcbn1cbi5yb3RhdGUtOTAge1xuICB0cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZyk7XG59XG4uZmxpcC1hbmQtcm90YXRlLTkwIHtcbiAgdHJhbnNmb3JtOiByb3RhdGUoLTkwZGVnKTtcbiAgLW1zLXRyYW5zZm9ybTogcm90YXRlKC05MGRlZyk7XG4gIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGUoLTkwZGVnKTtcbn1cbi5yb3RhdGUtMjcwIHtcbiAgdHJhbnNmb3JtOiByb3RhdGUoMjcwZGVnKTtcbn1cbiIsIi5mbGlwIHtcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlWCgtMSk7XG4gIHRyYW5zZm9ybTogc2NhbGVYKC0xKTtcbn1cblxuLnJvdGF0ZS0xODAge1xuICB0cmFuc2Zvcm06IHJvdGF0ZSgxODBkZWcpO1xufVxuXG4uZmxpcC1hbmQtcm90YXRlLTE4MCB7XG4gIHRyYW5zZm9ybTogcm90YXRlWSgtMTgwZGVnKTtcbiAgLW1zLXRyYW5zZm9ybTogcm90YXRlWSgtMTgwZGVnKTtcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZVkoLTE4MGRlZyk7XG59XG5cbi5mbGlwLWFuZC1yb3RhdGUtMjcwIHtcbiAgdHJhbnNmb3JtOiByb3RhdGUoLTI3MGRlZyk7XG4gIC1tcy10cmFuc2Zvcm06IHJvdGF0ZSgtMjcwZGVnKTtcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZSgtMjcwZGVnKTtcbn1cblxuLnJvdGF0ZS05MCB7XG4gIHRyYW5zZm9ybTogcm90YXRlKDkwZGVnKTtcbn1cblxuLmZsaXAtYW5kLXJvdGF0ZS05MCB7XG4gIHRyYW5zZm9ybTogcm90YXRlKC05MGRlZyk7XG4gIC1tcy10cmFuc2Zvcm06IHJvdGF0ZSgtOTBkZWcpO1xuICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKC05MGRlZyk7XG59XG5cbi5yb3RhdGUtMjcwIHtcbiAgdHJhbnNmb3JtOiByb3RhdGUoMjcwZGVnKTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/shared/components/img/img.component.ts":
/*!********************************************************!*\
  !*** ./src/app/shared/components/img/img.component.ts ***!
  \********************************************************/
/*! exports provided: ImgComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImgComponent", function() { return ImgComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var exif_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! exif-js */ "./node_modules/exif-js/exif.js");
/* harmony import */ var exif_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(exif_js__WEBPACK_IMPORTED_MODULE_1__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


var getImageClassToFixOrientation = function (orientation) {
    switch (orientation) {
        case 2:
            return ('flip');
        case 3:
            return ('rotate-180');
        case 4:
            return ('flip-and-rotate-180');
        case 5:
            return ('flip-and-rotate-270');
        case 6:
            return ('rotate-90');
        case 7:
            return ('flip-and-rotate-90');
        case 8:
            return ('rotate-270');
    }
};
var swapWidthAndHeight = function (img) {
    var currentHeight = img.height;
    var currentWidth = img.width;
    img.height = currentWidth;
    img.width = currentHeight;
};
var ImgComponent = /** @class */ (function () {
    function ImgComponent() {
    }
    ImgComponent.prototype.imageLoaded = function (e) {
        exif_js__WEBPACK_IMPORTED_MODULE_1__["getData"](e.target, function () {
            var allMetaData = exif_js__WEBPACK_IMPORTED_MODULE_1__["getAllTags"](this);
            var orientationClassFix = getImageClassToFixOrientation(allMetaData.Orientation);
            this.classList.add(orientationClassFix);
            if (allMetaData.Orientation >= 5) {
                swapWidthAndHeight(this);
            }
        });
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], ImgComponent.prototype, "imgSrc", void 0);
    ImgComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-img',
            template: __importDefault(__webpack_require__(/*! raw-loader!./img.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/img/img.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./img.component.scss */ "./src/app/shared/components/img/img.component.scss")).default]
        })
    ], ImgComponent);
    return ImgComponent;
}());



/***/ }),

/***/ "./src/app/shared/components/list-item/list-item.component.scss":
/*!**********************************************************************!*\
  !*** ./src/app/shared/components/list-item/list-item.component.scss ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".leading-icon {\n  margin-right: 20px;\n}\n\n.item-content {\n  width: 100%;\n}\n\n.item-content p {\n  white-space: normal;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  margin: 0;\n}\n\n.skeleton-icon {\n  width: 30px;\n  height: 30px;\n  min-width: 30px;\n}\n\n.color-medium {\n  color: var(--ion-color-medium) !important;\n}\n\n.color-danger {\n  color: var(--ion-color-danger) !important;\n}\n\n/******************\n  Event Card\n******************/\n\n.content-expired {\n  padding-right: 63px;\n}\n\n.expired-batch {\n  font-size: 12px;\n  position: absolute;\n  top: 15%;\n  right: 15px;\n  color: var(--ion-color-medium);\n  border-radius: 12px;\n  border: 1px var(--ion-color-medium);\n  border-style: solid;\n  padding: 1px 10px 1px 10px;\n}\n\n.video-conference-batch {\n  font-size: 12px;\n  position: absolute;\n  top: 15%;\n  right: 15px;\n  color: var(--ion-color-primary);\n  border-radius: 12px;\n  border: 1px var(--ion-color-primary);\n  border-style: solid;\n  padding: 1px 10px 1px 10px;\n}\n\n.color-gray-2 {\n  color: var(--practera-60-Percent-gray) !important;\n}\n\n.ion-color-medium {\n  --ion-color-base: var(--practera-60-Percent-gray) !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGF3L1dvcmtzcGFjZXMvd3d3L2ludGVyc2VjdGl2ZS9wcmFjdGVyYS1hcHAtdjIvc3JjL2FwcC9zaGFyZWQvY29tcG9uZW50cy9saXN0LWl0ZW0vbGlzdC1pdGVtLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9zaGFyZWQvY29tcG9uZW50cy9saXN0LWl0ZW0vbGlzdC1pdGVtLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7QUNDRjs7QURDQTtFQUNFLFdBQUE7QUNFRjs7QURERTtFQUNFLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtFQUNBLG9CQUFBO0VBQ0EscUJBQUE7RUFDQSw0QkFBQTtFQUNBLFNBQUE7QUNHSjs7QURBQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtBQ0dGOztBRERBO0VBQ0UseUNBQUE7QUNJRjs7QURGQTtFQUNFLHlDQUFBO0FDS0Y7O0FERkE7O2tCQUFBOztBQUdBO0VBQ0UsbUJBQUE7QUNLRjs7QURIQTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxXQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtFQUNBLG1DQUFBO0VBQ0EsbUJBQUE7RUFDQSwwQkFBQTtBQ01GOztBREpBO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFdBQUE7RUFDQSwrQkFBQTtFQUNBLG1CQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQkFBQTtFQUNBLDBCQUFBO0FDT0Y7O0FESkE7RUFDRSxpREFBQTtBQ09GOztBREpBO0VBQ0UsNERBQUE7QUNPRiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9jb21wb25lbnRzL2xpc3QtaXRlbS9saXN0LWl0ZW0uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubGVhZGluZy1pY29uIHtcbiAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xufVxuLml0ZW0tY29udGVudCB7XG4gIHdpZHRoOiAxMDAlO1xuICBwIHtcbiAgICB3aGl0ZS1zcGFjZTogbm9ybWFsO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gICAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gICAgLXdlYmtpdC1saW5lLWNsYW1wOiAyO1xuICAgIC13ZWJraXQtYm94LW9yaWVudDogdmVydGljYWw7XG4gICAgbWFyZ2luOiAwO1xuICB9XG59XG4uc2tlbGV0b24taWNvbiB7XG4gIHdpZHRoOiAzMHB4O1xuICBoZWlnaHQ6IDMwcHg7XG4gIG1pbi13aWR0aDogMzBweDtcbn1cbi5jb2xvci1tZWRpdW0ge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSkgIWltcG9ydGFudDtcbn1cbi5jb2xvci1kYW5nZXIge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhbmdlcikgIWltcG9ydGFudDtcbn1cblxuLyoqKioqKioqKioqKioqKioqKlxuICBFdmVudCBDYXJkXG4qKioqKioqKioqKioqKioqKiovXG4uY29udGVudC1leHBpcmVkIHtcbiAgcGFkZGluZy1yaWdodDogNjNweDtcbn1cbi5leHBpcmVkLWJhdGNoIHtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMTUlO1xuICByaWdodDogMTVweDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xuICBib3JkZXItcmFkaXVzOiAxMnB4O1xuICBib3JkZXI6IDFweCB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbiAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcbiAgcGFkZGluZzogMXB4IDEwcHggMXB4IDEwcHg7XG59XG4udmlkZW8tY29uZmVyZW5jZS1iYXRjaCB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDE1JTtcbiAgcmlnaHQ6IDE1cHg7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIGJvcmRlci1yYWRpdXM6IDEycHg7XG4gIGJvcmRlcjogMXB4IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcbiAgcGFkZGluZzogMXB4IDEwcHggMXB4IDEwcHg7XG59XG4vLyB1c2UgZm9yIGV4cGlyZWQgZXZlbnQgdGl0bGUgQGV4dGVuZCAuZ3JheS0yIG5vdCB3b3JraW5nIGJlY2F1c2UgdGhpcyBpcyBhIGNvbXBvbmVudCBzY3NzIGZpbGUuXG4uY29sb3ItZ3JheS0yIHtcbiAgY29sb3I6IHZhcigtLXByYWN0ZXJhLTYwLVBlcmNlbnQtZ3JheSkgIWltcG9ydGFudDtcbn1cblxuLmlvbi1jb2xvci1tZWRpdW0ge1xuICAtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1wcmFjdGVyYS02MC1QZXJjZW50LWdyYXkpICFpbXBvcnRhbnQ7XG59XG4iLCIubGVhZGluZy1pY29uIHtcbiAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xufVxuXG4uaXRlbS1jb250ZW50IHtcbiAgd2lkdGg6IDEwMCU7XG59XG4uaXRlbS1jb250ZW50IHAge1xuICB3aGl0ZS1zcGFjZTogbm9ybWFsO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gIC13ZWJraXQtbGluZS1jbGFtcDogMjtcbiAgLXdlYmtpdC1ib3gtb3JpZW50OiB2ZXJ0aWNhbDtcbiAgbWFyZ2luOiAwO1xufVxuXG4uc2tlbGV0b24taWNvbiB7XG4gIHdpZHRoOiAzMHB4O1xuICBoZWlnaHQ6IDMwcHg7XG4gIG1pbi13aWR0aDogMzBweDtcbn1cblxuLmNvbG9yLW1lZGl1bSB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKSAhaW1wb3J0YW50O1xufVxuXG4uY29sb3ItZGFuZ2VyIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYW5nZXIpICFpbXBvcnRhbnQ7XG59XG5cbi8qKioqKioqKioqKioqKioqKipcbiAgRXZlbnQgQ2FyZFxuKioqKioqKioqKioqKioqKioqL1xuLmNvbnRlbnQtZXhwaXJlZCB7XG4gIHBhZGRpbmctcmlnaHQ6IDYzcHg7XG59XG5cbi5leHBpcmVkLWJhdGNoIHtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMTUlO1xuICByaWdodDogMTVweDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xuICBib3JkZXItcmFkaXVzOiAxMnB4O1xuICBib3JkZXI6IDFweCB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbiAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcbiAgcGFkZGluZzogMXB4IDEwcHggMXB4IDEwcHg7XG59XG5cbi52aWRlby1jb25mZXJlbmNlLWJhdGNoIHtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMTUlO1xuICByaWdodDogMTVweDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgYm9yZGVyLXJhZGl1czogMTJweDtcbiAgYm9yZGVyOiAxcHggdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICBib3JkZXItc3R5bGU6IHNvbGlkO1xuICBwYWRkaW5nOiAxcHggMTBweCAxcHggMTBweDtcbn1cblxuLmNvbG9yLWdyYXktMiB7XG4gIGNvbG9yOiB2YXIoLS1wcmFjdGVyYS02MC1QZXJjZW50LWdyYXkpICFpbXBvcnRhbnQ7XG59XG5cbi5pb24tY29sb3ItbWVkaXVtIHtcbiAgLS1pb24tY29sb3ItYmFzZTogdmFyKC0tcHJhY3RlcmEtNjAtUGVyY2VudC1ncmF5KSAhaW1wb3J0YW50O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/shared/components/list-item/list-item.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/shared/components/list-item/list-item.component.ts ***!
  \********************************************************************/
/*! exports provided: ListItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListItemComponent", function() { return ListItemComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

var ListItemComponent = /** @class */ (function () {
    function ListItemComponent() {
        this.lines = '';
    }
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Boolean)
    ], ListItemComponent.prototype, "loading", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], ListItemComponent.prototype, "lines", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], ListItemComponent.prototype, "leadingIcon", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], ListItemComponent.prototype, "leadingIconColor", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Boolean)
    ], ListItemComponent.prototype, "leadingIconPulsing", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], ListItemComponent.prototype, "title", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], ListItemComponent.prototype, "titleColor", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], ListItemComponent.prototype, "subtitle1", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], ListItemComponent.prototype, "subtitle1Color", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], ListItemComponent.prototype, "subtitle2", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], ListItemComponent.prototype, "endingText", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], ListItemComponent.prototype, "endingIcon", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], ListItemComponent.prototype, "endingIconColor", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Boolean)
    ], ListItemComponent.prototype, "active", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Boolean)
    ], ListItemComponent.prototype, "eventExpired", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], ListItemComponent.prototype, "eventVideoConference", void 0);
    ListItemComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-list-item',
            template: __importDefault(__webpack_require__(/*! raw-loader!./list-item.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/list-item/list-item.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./list-item.component.scss */ "./src/app/shared/components/list-item/list-item.component.scss")).default]
        })
    ], ListItemComponent);
    return ListItemComponent;
}());



/***/ }),

/***/ "./src/app/shared/components/unlocking/unlocking.component.scss":
/*!**********************************************************************!*\
  !*** ./src/app/shared/components/unlocking/unlocking.component.scss ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".contain {\n  text-align: center;\n  margin: auto;\n  background-image: url(\"/assets/img/unlocking-background.gif\");\n  background-size: 100%;\n  background-repeat: no-repeat;\n}\n.contain .badge {\n  width: 25%;\n  float: left;\n  margin: 25% 0 0 20%;\n  -webkit-animation-name: animation-badge;\n          animation-name: animation-badge;\n  -webkit-animation-duration: 1.5s;\n          animation-duration: 1.5s;\n}\n.contain .div-svg {\n  display: inline-block;\n  margin: 10% 0 30% -10%;\n  width: 60%;\n}\n.contain svg {\n  width: 100%;\n  height: 100%;\n}\n.contain svg .lock-color {\n  fill: var(--ion-color-primary);\n}\n.contain svg .lock-color-stroke {\n  stroke: var(--ion-color-primary);\n}\n.contain svg .blur-only {\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  -webkit-animation-name: animation-blur-only;\n          animation-name: animation-blur-only;\n  opacity: 0;\n}\n.contain svg .blur-filter {\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  -webkit-animation-name: animation-blur-filter;\n          animation-name: animation-blur-filter;\n  -webkit-filter: url(#blur-filter-6);\n          filter: url(#blur-filter-6);\n}\n.contain svg .blur-lock {\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  -webkit-animation-name: animation-blur-lock;\n          animation-name: animation-blur-lock;\n  -webkit-transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 173);\n          transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 173);\n}\n.contain svg .lock-only {\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  -webkit-animation-name: animation-lock-only;\n          animation-name: animation-lock-only;\n  opacity: 1;\n}\n.contain svg .lock-head {\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  -webkit-animation-name: animation-lock-head;\n          animation-name: animation-lock-head;\n  -webkit-transform: matrix(-1, 0, 0, 1, -74.2, 26.3);\n          transform: matrix(-1, 0, 0, 1, -74.2, 26.3);\n}\n.contain svg .lock-body {\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  -webkit-animation-name: animation-lock-body;\n          animation-name: animation-lock-body;\n  -webkit-transform: matrix(1, 0, 0, 1, 0, 117.85);\n          transform: matrix(1, 0, 0, 1, 0, 117.85);\n}\n.contain svg .checkbox-only {\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  -webkit-animation-name: animation-checkbox-only;\n          animation-name: animation-checkbox-only;\n  opacity: 1;\n}\n.contain svg #checkbox-68 {\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  -webkit-animation-name: animation-checkbox-68;\n          animation-name: animation-checkbox-68;\n  opacity: 0;\n}\n.contain svg #checkbox-69 {\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  -webkit-animation-name: animation-checkbox-69;\n          animation-name: animation-checkbox-69;\n  opacity: 0;\n}\n.contain svg #checkbox-70 {\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  -webkit-animation-name: animation-checkbox-70;\n          animation-name: animation-checkbox-70;\n  opacity: 0;\n}\n.contain svg #checkbox-71 {\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  -webkit-animation-name: animation-checkbox-71;\n          animation-name: animation-checkbox-71;\n  opacity: 0;\n}\n.contain svg #checkbox-72 {\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  -webkit-animation-name: animation-checkbox-72;\n          animation-name: animation-checkbox-72;\n  opacity: 0;\n}\n.contain svg #checkbox-73 {\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  -webkit-animation-name: animation-checkbox-73;\n          animation-name: animation-checkbox-73;\n  opacity: 0;\n}\n.contain svg #checkbox-74 {\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  -webkit-animation-name: animation-checkbox-74;\n          animation-name: animation-checkbox-74;\n  opacity: 0;\n}\n.contain svg .checkbox-75 {\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  -webkit-animation-name: animation-checkbox-75;\n          animation-name: animation-checkbox-75;\n  opacity: 0;\n}\n.contain svg .checkbox-border-final {\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  -webkit-animation-name: animation-checkbox-border-final;\n          animation-name: animation-checkbox-border-final;\n  opacity: 1;\n}\n.contain svg .checkbox-check-final {\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  -webkit-animation-name: animation-checkbox-check-final;\n          animation-name: animation-checkbox-check-final;\n  opacity: 1;\n}\n.contain svg .checkbox-check {\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  -webkit-animation-name: animation-checkbox-check;\n          animation-name: animation-checkbox-check;\n  -webkit-transform: matrix(1, 0, 0, 1, 0, 0);\n          transform: matrix(1, 0, 0, 1, 0, 0);\n}\n@-webkit-keyframes animation-badge {\n  0% {\n    -webkit-transform: scale(0.1, 0.1);\n            transform: scale(0.1, 0.1);\n  }\n  60% {\n    -webkit-transform: scale(1.2, 1.2);\n            transform: scale(1.2, 1.2);\n  }\n  70% {\n    -webkit-transform: scale(0.8, 0.8);\n            transform: scale(0.8, 0.8);\n  }\n  80% {\n    -webkit-transform: scale(1.1, 1.1);\n            transform: scale(1.1, 1.1);\n  }\n}\n@keyframes animation-badge {\n  0% {\n    -webkit-transform: scale(0.1, 0.1);\n            transform: scale(0.1, 0.1);\n  }\n  60% {\n    -webkit-transform: scale(1.2, 1.2);\n            transform: scale(1.2, 1.2);\n  }\n  70% {\n    -webkit-transform: scale(0.8, 0.8);\n            transform: scale(0.8, 0.8);\n  }\n  80% {\n    -webkit-transform: scale(1.1, 1.1);\n            transform: scale(1.1, 1.1);\n  }\n}\n@-webkit-keyframes animation-blur-only {\n  0% {\n    opacity: 1;\n  }\n  5% {\n    opacity: 1;\n  }\n  6% {\n    opacity: 0;\n  }\n}\n@keyframes animation-blur-only {\n  0% {\n    opacity: 1;\n  }\n  5% {\n    opacity: 1;\n  }\n  6% {\n    opacity: 0;\n  }\n}\n@-webkit-keyframes animation-blur-filter {\n  0% {\n    -webkit-filter: url(#blur-filter-1);\n            filter: url(#blur-filter-1);\n  }\n  1% {\n    -webkit-filter: url(#blur-filter-2);\n            filter: url(#blur-filter-2);\n  }\n  2% {\n    -webkit-filter: url(#blur-filter-3);\n            filter: url(#blur-filter-3);\n  }\n  3% {\n    -webkit-filter: url(#blur-filter-4);\n            filter: url(#blur-filter-4);\n  }\n  4% {\n    -webkit-filter: url(#blur-filter-5);\n            filter: url(#blur-filter-5);\n  }\n  5% {\n    -webkit-filter: url(#blur-filter-6);\n            filter: url(#blur-filter-6);\n  }\n}\n@keyframes animation-blur-filter {\n  0% {\n    -webkit-filter: url(#blur-filter-1);\n            filter: url(#blur-filter-1);\n  }\n  1% {\n    -webkit-filter: url(#blur-filter-2);\n            filter: url(#blur-filter-2);\n  }\n  2% {\n    -webkit-filter: url(#blur-filter-3);\n            filter: url(#blur-filter-3);\n  }\n  3% {\n    -webkit-filter: url(#blur-filter-4);\n            filter: url(#blur-filter-4);\n  }\n  4% {\n    -webkit-filter: url(#blur-filter-5);\n            filter: url(#blur-filter-5);\n  }\n  5% {\n    -webkit-filter: url(#blur-filter-6);\n            filter: url(#blur-filter-6);\n  }\n}\n@-webkit-keyframes animation-blur-lock {\n  0% {\n    -webkit-transform: matrix(0.8448181152, 0, 0, 0.8445739746, 199.95, 253);\n            transform: matrix(0.8448181152, 0, 0, 0.8445739746, 199.95, 253);\n  }\n  1% {\n    -webkit-transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 237);\n            transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 237);\n  }\n  2% {\n    -webkit-transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 221);\n            transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 221);\n  }\n  3% {\n    -webkit-transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 205);\n            transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 205);\n  }\n  4% {\n    -webkit-transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 189.05);\n            transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 189.05);\n  }\n  5% {\n    -webkit-transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 173);\n            transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 173);\n  }\n}\n@keyframes animation-blur-lock {\n  0% {\n    -webkit-transform: matrix(0.8448181152, 0, 0, 0.8445739746, 199.95, 253);\n            transform: matrix(0.8448181152, 0, 0, 0.8445739746, 199.95, 253);\n  }\n  1% {\n    -webkit-transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 237);\n            transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 237);\n  }\n  2% {\n    -webkit-transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 221);\n            transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 221);\n  }\n  3% {\n    -webkit-transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 205);\n            transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 205);\n  }\n  4% {\n    -webkit-transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 189.05);\n            transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 189.05);\n  }\n  5% {\n    -webkit-transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 173);\n            transform: matrix(0.8447875977, 0, 0, 0.844543457, 200, 173);\n  }\n}\n@-webkit-keyframes animation-lock-only {\n  0% {\n    opacity: 0;\n  }\n  5% {\n    opacity: 0;\n  }\n  6% {\n    opacity: 1;\n  }\n}\n@keyframes animation-lock-only {\n  0% {\n    opacity: 0;\n  }\n  5% {\n    opacity: 0;\n  }\n  6% {\n    opacity: 1;\n  }\n}\n@-webkit-keyframes animation-lock-head {\n  6% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0.1, 84.7);\n            transform: matrix(1, 0, 0, 1, 0.1, 84.7);\n  }\n  31% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0.1, 11.1);\n            transform: matrix(1, 0, 0, 1, 0.1, 11.1);\n  }\n  38% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0.1, 30.3);\n            transform: matrix(1, 0, 0, 1, 0.1, 30.3);\n  }\n  44% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0.1, 26.3);\n            transform: matrix(1, 0, 0, 1, 0.1, 26.3);\n  }\n  53% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0.1, 30.3);\n            transform: matrix(1, 0, 0, 1, 0.1, 30.3);\n  }\n  64% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0.1, 26.3);\n            transform: matrix(1, 0, 0, 1, 0.1, 26.3);\n  }\n  67% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0.1, 26.3);\n            transform: matrix(1, 0, 0, 1, 0.1, 26.3);\n  }\n  68% {\n    -webkit-transform: matrix(0.857131958, 0, 0, 1, -5.2, 26.3);\n            transform: matrix(0.857131958, 0, 0, 1, -5.2, 26.3);\n  }\n  81% {\n    -webkit-transform: matrix(-1, 0, 0, 1, -74.2, 26.3);\n            transform: matrix(-1, 0, 0, 1, -74.2, 26.3);\n  }\n}\n@keyframes animation-lock-head {\n  6% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0.1, 84.7);\n            transform: matrix(1, 0, 0, 1, 0.1, 84.7);\n  }\n  31% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0.1, 11.1);\n            transform: matrix(1, 0, 0, 1, 0.1, 11.1);\n  }\n  38% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0.1, 30.3);\n            transform: matrix(1, 0, 0, 1, 0.1, 30.3);\n  }\n  44% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0.1, 26.3);\n            transform: matrix(1, 0, 0, 1, 0.1, 26.3);\n  }\n  53% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0.1, 30.3);\n            transform: matrix(1, 0, 0, 1, 0.1, 30.3);\n  }\n  64% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0.1, 26.3);\n            transform: matrix(1, 0, 0, 1, 0.1, 26.3);\n  }\n  67% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0.1, 26.3);\n            transform: matrix(1, 0, 0, 1, 0.1, 26.3);\n  }\n  68% {\n    -webkit-transform: matrix(0.857131958, 0, 0, 1, -5.2, 26.3);\n            transform: matrix(0.857131958, 0, 0, 1, -5.2, 26.3);\n  }\n  81% {\n    -webkit-transform: matrix(-1, 0, 0, 1, -74.2, 26.3);\n            transform: matrix(-1, 0, 0, 1, -74.2, 26.3);\n  }\n}\n@-webkit-keyframes animation-lock-body {\n  19% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0, 117.85);\n            transform: matrix(1, 0, 0, 1, 0, 117.85);\n  }\n  30% {\n    -webkit-transform: matrix(0.9559783936, 0, 0, 1.0537719727, -0.05, 114.65);\n            transform: matrix(0.9559783936, 0, 0, 1.0537719727, -0.05, 114.65);\n  }\n  37% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0, 117.85);\n            transform: matrix(1, 0, 0, 1, 0, 117.85);\n  }\n  43% {\n    -webkit-transform: matrix(0.9559783936, 0, 0, 1.033416748, -0.05, 115.9);\n            transform: matrix(0.9559783936, 0, 0, 1.033416748, -0.05, 115.9);\n  }\n  53% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0, 117.85);\n            transform: matrix(1, 0, 0, 1, 0, 117.85);\n  }\n}\n@keyframes animation-lock-body {\n  19% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0, 117.85);\n            transform: matrix(1, 0, 0, 1, 0, 117.85);\n  }\n  30% {\n    -webkit-transform: matrix(0.9559783936, 0, 0, 1.0537719727, -0.05, 114.65);\n            transform: matrix(0.9559783936, 0, 0, 1.0537719727, -0.05, 114.65);\n  }\n  37% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0, 117.85);\n            transform: matrix(1, 0, 0, 1, 0, 117.85);\n  }\n  43% {\n    -webkit-transform: matrix(0.9559783936, 0, 0, 1.033416748, -0.05, 115.9);\n            transform: matrix(0.9559783936, 0, 0, 1.033416748, -0.05, 115.9);\n  }\n  53% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0, 117.85);\n            transform: matrix(1, 0, 0, 1, 0, 117.85);\n  }\n}\n@-webkit-keyframes animation-checkbox-only {\n  0% {\n    opacity: 0;\n  }\n  66% {\n    opacity: 0;\n  }\n  67% {\n    opacity: 1;\n  }\n}\n@keyframes animation-checkbox-only {\n  0% {\n    opacity: 0;\n  }\n  66% {\n    opacity: 0;\n  }\n  67% {\n    opacity: 1;\n  }\n}\n@-webkit-keyframes animation-checkbox-68 {\n  0% {\n    opacity: 0;\n  }\n  66% {\n    opacity: 0;\n  }\n  67% {\n    opacity: 1;\n  }\n  68% {\n    opacity: 0;\n  }\n}\n@keyframes animation-checkbox-68 {\n  0% {\n    opacity: 0;\n  }\n  66% {\n    opacity: 0;\n  }\n  67% {\n    opacity: 1;\n  }\n  68% {\n    opacity: 0;\n  }\n}\n@-webkit-keyframes animation-checkbox-69 {\n  0% {\n    opacity: 0;\n  }\n  67% {\n    opacity: 0;\n  }\n  68% {\n    opacity: 1;\n  }\n  69% {\n    opacity: 0;\n  }\n}\n@keyframes animation-checkbox-69 {\n  0% {\n    opacity: 0;\n  }\n  67% {\n    opacity: 0;\n  }\n  68% {\n    opacity: 1;\n  }\n  69% {\n    opacity: 0;\n  }\n}\n@-webkit-keyframes animation-checkbox-70 {\n  0% {\n    opacity: 0;\n  }\n  68% {\n    opacity: 0;\n  }\n  69% {\n    opacity: 1;\n  }\n  70% {\n    opacity: 0;\n  }\n}\n@keyframes animation-checkbox-70 {\n  0% {\n    opacity: 0;\n  }\n  68% {\n    opacity: 0;\n  }\n  69% {\n    opacity: 1;\n  }\n  70% {\n    opacity: 0;\n  }\n}\n@-webkit-keyframes animation-checkbox-71 {\n  0% {\n    opacity: 0;\n  }\n  69% {\n    opacity: 0;\n  }\n  70% {\n    opacity: 1;\n  }\n  71% {\n    opacity: 0;\n  }\n}\n@keyframes animation-checkbox-71 {\n  0% {\n    opacity: 0;\n  }\n  69% {\n    opacity: 0;\n  }\n  70% {\n    opacity: 1;\n  }\n  71% {\n    opacity: 0;\n  }\n}\n@-webkit-keyframes animation-checkbox-72 {\n  0% {\n    opacity: 0;\n  }\n  70% {\n    opacity: 0;\n  }\n  71% {\n    opacity: 1;\n  }\n  72% {\n    opacity: 0;\n  }\n}\n@keyframes animation-checkbox-72 {\n  0% {\n    opacity: 0;\n  }\n  70% {\n    opacity: 0;\n  }\n  71% {\n    opacity: 1;\n  }\n  72% {\n    opacity: 0;\n  }\n}\n@-webkit-keyframes animation-checkbox-73 {\n  0% {\n    opacity: 0;\n  }\n  71% {\n    opacity: 0;\n  }\n  72% {\n    opacity: 1;\n  }\n  73% {\n    opacity: 0;\n  }\n}\n@keyframes animation-checkbox-73 {\n  0% {\n    opacity: 0;\n  }\n  71% {\n    opacity: 0;\n  }\n  72% {\n    opacity: 1;\n  }\n  73% {\n    opacity: 0;\n  }\n}\n@-webkit-keyframes animation-checkbox-74 {\n  0% {\n    opacity: 0;\n  }\n  72% {\n    opacity: 0;\n  }\n  73% {\n    opacity: 1;\n  }\n  74% {\n    opacity: 0;\n  }\n}\n@keyframes animation-checkbox-74 {\n  0% {\n    opacity: 0;\n  }\n  72% {\n    opacity: 0;\n  }\n  73% {\n    opacity: 1;\n  }\n  74% {\n    opacity: 0;\n  }\n}\n@-webkit-keyframes animation-checkbox-75 {\n  0% {\n    opacity: 0;\n  }\n  73% {\n    opacity: 0;\n  }\n  74% {\n    opacity: 1;\n  }\n  75% {\n    opacity: 0;\n  }\n}\n@keyframes animation-checkbox-75 {\n  0% {\n    opacity: 0;\n  }\n  73% {\n    opacity: 0;\n  }\n  74% {\n    opacity: 1;\n  }\n  75% {\n    opacity: 0;\n  }\n}\n@-webkit-keyframes animation-checkbox-border-final {\n  0% {\n    opacity: 0;\n  }\n  74% {\n    opacity: 0;\n  }\n  75% {\n    opacity: 1;\n  }\n}\n@keyframes animation-checkbox-border-final {\n  0% {\n    opacity: 0;\n  }\n  74% {\n    opacity: 0;\n  }\n  75% {\n    opacity: 1;\n  }\n}\n@-webkit-keyframes animation-checkbox-check-final {\n  0% {\n    opacity: 0;\n  }\n  85% {\n    opacity: 0;\n  }\n  86% {\n    opacity: 1;\n  }\n}\n@keyframes animation-checkbox-check-final {\n  0% {\n    opacity: 0;\n  }\n  85% {\n    opacity: 0;\n  }\n  86% {\n    opacity: 1;\n  }\n}\n@-webkit-keyframes animation-checkbox-check {\n  86% {\n    -webkit-transform: matrix(1, 0, 0, 1, -34.9, 1.5);\n            transform: matrix(1, 0, 0, 1, -34.9, 1.5);\n  }\n  90% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0, 0);\n            transform: matrix(1, 0, 0, 1, 0, 0);\n  }\n}\n@keyframes animation-checkbox-check {\n  86% {\n    -webkit-transform: matrix(1, 0, 0, 1, -34.9, 1.5);\n            transform: matrix(1, 0, 0, 1, -34.9, 1.5);\n  }\n  90% {\n    -webkit-transform: matrix(1, 0, 0, 1, 0, 0);\n            transform: matrix(1, 0, 0, 1, 0, 0);\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGF3L1dvcmtzcGFjZXMvd3d3L2ludGVyc2VjdGl2ZS9wcmFjdGVyYS1hcHAtdjIvc3JjL2FwcC9zaGFyZWQvY29tcG9uZW50cy91bmxvY2tpbmcvdW5sb2NraW5nLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9zaGFyZWQvY29tcG9uZW50cy91bmxvY2tpbmcvdW5sb2NraW5nLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUtBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsNkRBQUE7RUFDQSxxQkFBQTtFQUNBLDRCQUFBO0FDSkY7QURLRTtFQUNFLFVBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSx1Q0FBQTtVQUFBLCtCQUFBO0VBQ0EsZ0NBQUE7VUFBQSx3QkFBQTtBQ0hKO0FES0U7RUFDRSxxQkFBQTtFQUNBLHNCQUFBO0VBQ0EsVUFBQTtBQ0hKO0FES0U7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQ0hKO0FESUk7RUFDRSw4QkFBQTtBQ0ZOO0FESUk7RUFDRSxnQ0FBQTtBQ0ZOO0FES0k7RUFoQ0YsOEJBQUE7VUFBQSxzQkFBQTtFQWtDSSwyQ0FBQTtVQUFBLG1DQUFBO0VBQ0EsVUFBQTtBQ0hOO0FES0k7RUFyQ0YsOEJBQUE7VUFBQSxzQkFBQTtFQXVDSSw2Q0FBQTtVQUFBLHFDQUFBO0VBQ0EsbUNBQUE7VUFBQSwyQkFBQTtBQ0hOO0FES0k7RUExQ0YsOEJBQUE7VUFBQSxzQkFBQTtFQTRDSSwyQ0FBQTtVQUFBLG1DQUFBO0VBQ0Esb0VBQUE7VUFBQSw0REFBQTtBQ0hOO0FETUk7RUFoREYsOEJBQUE7VUFBQSxzQkFBQTtFQWtESSwyQ0FBQTtVQUFBLG1DQUFBO0VBQ0EsVUFBQTtBQ0pOO0FETUk7RUFyREYsOEJBQUE7VUFBQSxzQkFBQTtFQXVESSwyQ0FBQTtVQUFBLG1DQUFBO0VBQ0EsbURBQUE7VUFBQSwyQ0FBQTtBQ0pOO0FETUk7RUExREYsOEJBQUE7VUFBQSxzQkFBQTtFQTRESSwyQ0FBQTtVQUFBLG1DQUFBO0VBQ0EsZ0RBQUE7VUFBQSx3Q0FBQTtBQ0pOO0FET0k7RUFoRUYsOEJBQUE7VUFBQSxzQkFBQTtFQWtFSSwrQ0FBQTtVQUFBLHVDQUFBO0VBQ0EsVUFBQTtBQ0xOO0FET0k7RUFyRUYsOEJBQUE7VUFBQSxzQkFBQTtFQXVFSSw2Q0FBQTtVQUFBLHFDQUFBO0VBQ0EsVUFBQTtBQ0xOO0FET0k7RUExRUYsOEJBQUE7VUFBQSxzQkFBQTtFQTRFSSw2Q0FBQTtVQUFBLHFDQUFBO0VBQ0EsVUFBQTtBQ0xOO0FET0k7RUEvRUYsOEJBQUE7VUFBQSxzQkFBQTtFQWlGSSw2Q0FBQTtVQUFBLHFDQUFBO0VBQ0EsVUFBQTtBQ0xOO0FET0k7RUFwRkYsOEJBQUE7VUFBQSxzQkFBQTtFQXNGSSw2Q0FBQTtVQUFBLHFDQUFBO0VBQ0EsVUFBQTtBQ0xOO0FET0k7RUF6RkYsOEJBQUE7VUFBQSxzQkFBQTtFQTJGSSw2Q0FBQTtVQUFBLHFDQUFBO0VBQ0EsVUFBQTtBQ0xOO0FET0k7RUE5RkYsOEJBQUE7VUFBQSxzQkFBQTtFQWdHSSw2Q0FBQTtVQUFBLHFDQUFBO0VBQ0EsVUFBQTtBQ0xOO0FET0k7RUFuR0YsOEJBQUE7VUFBQSxzQkFBQTtFQXFHSSw2Q0FBQTtVQUFBLHFDQUFBO0VBQ0EsVUFBQTtBQ0xOO0FET0k7RUF4R0YsOEJBQUE7VUFBQSxzQkFBQTtFQTBHSSw2Q0FBQTtVQUFBLHFDQUFBO0VBQ0EsVUFBQTtBQ0xOO0FEUUk7RUE5R0YsOEJBQUE7VUFBQSxzQkFBQTtFQWdISSx1REFBQTtVQUFBLCtDQUFBO0VBQ0EsVUFBQTtBQ05OO0FEU0k7RUFwSEYsOEJBQUE7VUFBQSxzQkFBQTtFQXNISSxzREFBQTtVQUFBLDhDQUFBO0VBQ0EsVUFBQTtBQ1BOO0FEVUk7RUExSEYsOEJBQUE7VUFBQSxzQkFBQTtFQTRISSxnREFBQTtVQUFBLHdDQUFBO0VBQ0EsMkNBQUE7VUFBQSxtQ0FBQTtBQ1JOO0FEWUE7RUFDRTtJQUNFLGtDQUFBO1lBQUEsMEJBQUE7RUNURjtFRFdBO0lBQ0Usa0NBQUE7WUFBQSwwQkFBQTtFQ1RGO0VEV0E7SUFDRSxrQ0FBQTtZQUFBLDBCQUFBO0VDVEY7RURXQTtJQUNFLGtDQUFBO1lBQUEsMEJBQUE7RUNURjtBQUNGO0FESEE7RUFDRTtJQUNFLGtDQUFBO1lBQUEsMEJBQUE7RUNURjtFRFdBO0lBQ0Usa0NBQUE7WUFBQSwwQkFBQTtFQ1RGO0VEV0E7SUFDRSxrQ0FBQTtZQUFBLDBCQUFBO0VDVEY7RURXQTtJQUNFLGtDQUFBO1lBQUEsMEJBQUE7RUNURjtBQUNGO0FEV0E7RUFFRTtJQUNFLFVBQUE7RUNWRjtFRFlBO0lBQ0UsVUFBQTtFQ1ZGO0VEYUE7SUFDRSxVQUFBO0VDWEY7QUFDRjtBREFBO0VBRUU7SUFDRSxVQUFBO0VDVkY7RURZQTtJQUNFLFVBQUE7RUNWRjtFRGFBO0lBQ0UsVUFBQTtFQ1hGO0FBQ0Y7QURhQTtFQUVFO0lBQ0UsbUNBQUE7WUFBQSwyQkFBQTtFQ1pGO0VEY0E7SUFDRSxtQ0FBQTtZQUFBLDJCQUFBO0VDWkY7RURjQTtJQUNFLG1DQUFBO1lBQUEsMkJBQUE7RUNaRjtFRGNBO0lBQ0UsbUNBQUE7WUFBQSwyQkFBQTtFQ1pGO0VEY0E7SUFDRSxtQ0FBQTtZQUFBLDJCQUFBO0VDWkY7RURlQTtJQUNFLG1DQUFBO1lBQUEsMkJBQUE7RUNiRjtBQUNGO0FEUEE7RUFFRTtJQUNFLG1DQUFBO1lBQUEsMkJBQUE7RUNaRjtFRGNBO0lBQ0UsbUNBQUE7WUFBQSwyQkFBQTtFQ1pGO0VEY0E7SUFDRSxtQ0FBQTtZQUFBLDJCQUFBO0VDWkY7RURjQTtJQUNFLG1DQUFBO1lBQUEsMkJBQUE7RUNaRjtFRGNBO0lBQ0UsbUNBQUE7WUFBQSwyQkFBQTtFQ1pGO0VEZUE7SUFDRSxtQ0FBQTtZQUFBLDJCQUFBO0VDYkY7QUFDRjtBRGVBO0VBRUU7SUFDRSx3RUFBQTtZQUFBLGdFQUFBO0VDZEY7RURnQkE7SUFDRSxvRUFBQTtZQUFBLDREQUFBO0VDZEY7RURnQkE7SUFDRSxvRUFBQTtZQUFBLDREQUFBO0VDZEY7RURnQkE7SUFDRSxvRUFBQTtZQUFBLDREQUFBO0VDZEY7RURnQkE7SUFDRSx1RUFBQTtZQUFBLCtEQUFBO0VDZEY7RURpQkE7SUFDRSxvRUFBQTtZQUFBLDREQUFBO0VDZkY7QUFDRjtBRExBO0VBRUU7SUFDRSx3RUFBQTtZQUFBLGdFQUFBO0VDZEY7RURnQkE7SUFDRSxvRUFBQTtZQUFBLDREQUFBO0VDZEY7RURnQkE7SUFDRSxvRUFBQTtZQUFBLDREQUFBO0VDZEY7RURnQkE7SUFDRSxvRUFBQTtZQUFBLDREQUFBO0VDZEY7RURnQkE7SUFDRSx1RUFBQTtZQUFBLCtEQUFBO0VDZEY7RURpQkE7SUFDRSxvRUFBQTtZQUFBLDREQUFBO0VDZkY7QUFDRjtBRGlCQTtFQUNFO0lBQ0UsVUFBQTtFQ2ZGO0VEaUJBO0lBQ0UsVUFBQTtFQ2ZGO0VEaUJBO0lBQ0UsVUFBQTtFQ2ZGO0FBQ0Y7QURNQTtFQUNFO0lBQ0UsVUFBQTtFQ2ZGO0VEaUJBO0lBQ0UsVUFBQTtFQ2ZGO0VEaUJBO0lBQ0UsVUFBQTtFQ2ZGO0FBQ0Y7QURpQkE7RUFFRTtJQUNFLGdEQUFBO1lBQUEsd0NBQUE7RUNoQkY7RURtQkE7SUFDRSxnREFBQTtZQUFBLHdDQUFBO0VDakJGO0VEb0JBO0lBQ0UsZ0RBQUE7WUFBQSx3Q0FBQTtFQ2xCRjtFRHFCQTtJQUNFLGdEQUFBO1lBQUEsd0NBQUE7RUNuQkY7RURzQkE7SUFDRSxnREFBQTtZQUFBLHdDQUFBO0VDcEJGO0VEdUJBO0lBQ0UsZ0RBQUE7WUFBQSx3Q0FBQTtFQ3JCRjtFRHdCQTtJQUNFLGdEQUFBO1lBQUEsd0NBQUE7RUN0QkY7RUR5QkE7SUFDRSwyREFBQTtZQUFBLG1EQUFBO0VDdkJGO0VEMEJBO0lBQ0UsbURBQUE7WUFBQSwyQ0FBQTtFQ3hCRjtBQUNGO0FEWkE7RUFFRTtJQUNFLGdEQUFBO1lBQUEsd0NBQUE7RUNoQkY7RURtQkE7SUFDRSxnREFBQTtZQUFBLHdDQUFBO0VDakJGO0VEb0JBO0lBQ0UsZ0RBQUE7WUFBQSx3Q0FBQTtFQ2xCRjtFRHFCQTtJQUNFLGdEQUFBO1lBQUEsd0NBQUE7RUNuQkY7RURzQkE7SUFDRSxnREFBQTtZQUFBLHdDQUFBO0VDcEJGO0VEdUJBO0lBQ0UsZ0RBQUE7WUFBQSx3Q0FBQTtFQ3JCRjtFRHdCQTtJQUNFLGdEQUFBO1lBQUEsd0NBQUE7RUN0QkY7RUR5QkE7SUFDRSwyREFBQTtZQUFBLG1EQUFBO0VDdkJGO0VEMEJBO0lBQ0UsbURBQUE7WUFBQSwyQ0FBQTtFQ3hCRjtBQUNGO0FEMEJBO0VBRUU7SUFDRSxnREFBQTtZQUFBLHdDQUFBO0VDekJGO0VEMkJBO0lBQ0UsMEVBQUE7WUFBQSxrRUFBQTtFQ3pCRjtFRDJCQTtJQUNFLGdEQUFBO1lBQUEsd0NBQUE7RUN6QkY7RUQyQkE7SUFDRSx3RUFBQTtZQUFBLGdFQUFBO0VDekJGO0VENEJBO0lBQ0UsZ0RBQUE7WUFBQSx3Q0FBQTtFQzFCRjtBQUNGO0FEU0E7RUFFRTtJQUNFLGdEQUFBO1lBQUEsd0NBQUE7RUN6QkY7RUQyQkE7SUFDRSwwRUFBQTtZQUFBLGtFQUFBO0VDekJGO0VEMkJBO0lBQ0UsZ0RBQUE7WUFBQSx3Q0FBQTtFQ3pCRjtFRDJCQTtJQUNFLHdFQUFBO1lBQUEsZ0VBQUE7RUN6QkY7RUQ0QkE7SUFDRSxnREFBQTtZQUFBLHdDQUFBO0VDMUJGO0FBQ0Y7QUQ0QkE7RUFDRTtJQUNFLFVBQUE7RUMxQkY7RUQ0QkE7SUFDRSxVQUFBO0VDMUJGO0VENkJBO0lBQ0UsVUFBQTtFQzNCRjtBQUNGO0FEaUJBO0VBQ0U7SUFDRSxVQUFBO0VDMUJGO0VENEJBO0lBQ0UsVUFBQTtFQzFCRjtFRDZCQTtJQUNFLFVBQUE7RUMzQkY7QUFDRjtBRDZCQTtFQUNFO0lBQ0UsVUFBQTtFQzNCRjtFRDZCQTtJQUNFLFVBQUE7RUMzQkY7RUQ4QkE7SUFDRSxVQUFBO0VDNUJGO0VEOEJBO0lBQ0UsVUFBQTtFQzVCRjtBQUNGO0FEZUE7RUFDRTtJQUNFLFVBQUE7RUMzQkY7RUQ2QkE7SUFDRSxVQUFBO0VDM0JGO0VEOEJBO0lBQ0UsVUFBQTtFQzVCRjtFRDhCQTtJQUNFLFVBQUE7RUM1QkY7QUFDRjtBRDhCQTtFQUNFO0lBQ0UsVUFBQTtFQzVCRjtFRDhCQTtJQUNFLFVBQUE7RUM1QkY7RUQrQkE7SUFDRSxVQUFBO0VDN0JGO0VEK0JBO0lBQ0UsVUFBQTtFQzdCRjtBQUNGO0FEZ0JBO0VBQ0U7SUFDRSxVQUFBO0VDNUJGO0VEOEJBO0lBQ0UsVUFBQTtFQzVCRjtFRCtCQTtJQUNFLFVBQUE7RUM3QkY7RUQrQkE7SUFDRSxVQUFBO0VDN0JGO0FBQ0Y7QUQrQkE7RUFDRTtJQUNFLFVBQUE7RUM3QkY7RUQrQkE7SUFDRSxVQUFBO0VDN0JGO0VEZ0NBO0lBQ0UsVUFBQTtFQzlCRjtFRGdDQTtJQUNFLFVBQUE7RUM5QkY7QUFDRjtBRGlCQTtFQUNFO0lBQ0UsVUFBQTtFQzdCRjtFRCtCQTtJQUNFLFVBQUE7RUM3QkY7RURnQ0E7SUFDRSxVQUFBO0VDOUJGO0VEZ0NBO0lBQ0UsVUFBQTtFQzlCRjtBQUNGO0FEZ0NBO0VBQ0U7SUFDRSxVQUFBO0VDOUJGO0VEZ0NBO0lBQ0UsVUFBQTtFQzlCRjtFRGlDQTtJQUNFLFVBQUE7RUMvQkY7RURpQ0E7SUFDRSxVQUFBO0VDL0JGO0FBQ0Y7QURrQkE7RUFDRTtJQUNFLFVBQUE7RUM5QkY7RURnQ0E7SUFDRSxVQUFBO0VDOUJGO0VEaUNBO0lBQ0UsVUFBQTtFQy9CRjtFRGlDQTtJQUNFLFVBQUE7RUMvQkY7QUFDRjtBRGlDQTtFQUNFO0lBQ0UsVUFBQTtFQy9CRjtFRGlDQTtJQUNFLFVBQUE7RUMvQkY7RURrQ0E7SUFDRSxVQUFBO0VDaENGO0VEa0NBO0lBQ0UsVUFBQTtFQ2hDRjtBQUNGO0FEbUJBO0VBQ0U7SUFDRSxVQUFBO0VDL0JGO0VEaUNBO0lBQ0UsVUFBQTtFQy9CRjtFRGtDQTtJQUNFLFVBQUE7RUNoQ0Y7RURrQ0E7SUFDRSxVQUFBO0VDaENGO0FBQ0Y7QURrQ0E7RUFDRTtJQUNFLFVBQUE7RUNoQ0Y7RURrQ0E7SUFDRSxVQUFBO0VDaENGO0VEbUNBO0lBQ0UsVUFBQTtFQ2pDRjtFRG1DQTtJQUNFLFVBQUE7RUNqQ0Y7QUFDRjtBRG9CQTtFQUNFO0lBQ0UsVUFBQTtFQ2hDRjtFRGtDQTtJQUNFLFVBQUE7RUNoQ0Y7RURtQ0E7SUFDRSxVQUFBO0VDakNGO0VEbUNBO0lBQ0UsVUFBQTtFQ2pDRjtBQUNGO0FEbUNBO0VBQ0U7SUFDRSxVQUFBO0VDakNGO0VEbUNBO0lBQ0UsVUFBQTtFQ2pDRjtFRG9DQTtJQUNFLFVBQUE7RUNsQ0Y7RURvQ0E7SUFDRSxVQUFBO0VDbENGO0FBQ0Y7QURxQkE7RUFDRTtJQUNFLFVBQUE7RUNqQ0Y7RURtQ0E7SUFDRSxVQUFBO0VDakNGO0VEb0NBO0lBQ0UsVUFBQTtFQ2xDRjtFRG9DQTtJQUNFLFVBQUE7RUNsQ0Y7QUFDRjtBRG9DQTtFQUNFO0lBQ0UsVUFBQTtFQ2xDRjtFRG9DQTtJQUNFLFVBQUE7RUNsQ0Y7RURxQ0E7SUFDRSxVQUFBO0VDbkNGO0VEcUNBO0lBQ0UsVUFBQTtFQ25DRjtBQUNGO0FEc0JBO0VBQ0U7SUFDRSxVQUFBO0VDbENGO0VEb0NBO0lBQ0UsVUFBQTtFQ2xDRjtFRHFDQTtJQUNFLFVBQUE7RUNuQ0Y7RURxQ0E7SUFDRSxVQUFBO0VDbkNGO0FBQ0Y7QURxQ0E7RUFDRTtJQUNFLFVBQUE7RUNuQ0Y7RURxQ0E7SUFDRSxVQUFBO0VDbkNGO0VEc0NBO0lBQ0UsVUFBQTtFQ3BDRjtBQUNGO0FEMEJBO0VBQ0U7SUFDRSxVQUFBO0VDbkNGO0VEcUNBO0lBQ0UsVUFBQTtFQ25DRjtFRHNDQTtJQUNFLFVBQUE7RUNwQ0Y7QUFDRjtBRHNDQTtFQUNFO0lBQ0UsVUFBQTtFQ3BDRjtFRHNDQTtJQUNFLFVBQUE7RUNwQ0Y7RUR1Q0E7SUFDRSxVQUFBO0VDckNGO0FBQ0Y7QUQyQkE7RUFDRTtJQUNFLFVBQUE7RUNwQ0Y7RURzQ0E7SUFDRSxVQUFBO0VDcENGO0VEdUNBO0lBQ0UsVUFBQTtFQ3JDRjtBQUNGO0FEdUNBO0VBRUU7SUFDRSxpREFBQTtZQUFBLHlDQUFBO0VDdENGO0VEd0NBO0lBQ0UsMkNBQUE7WUFBQSxtQ0FBQTtFQ3RDRjtBQUNGO0FEK0JBO0VBRUU7SUFDRSxpREFBQTtZQUFBLHlDQUFBO0VDdENGO0VEd0NBO0lBQ0UsMkNBQUE7WUFBQSxtQ0FBQTtFQ3RDRjtBQUNGIiwiZmlsZSI6InNyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvdW5sb2NraW5nL3VubG9ja2luZy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBtaXhpbiBhbmltYXRpb24ge1xuICBhbmltYXRpb24tZHVyYXRpb246IDNzO1xuICAvLyBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTtcbn1cblxuLmNvbnRhaW4ge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbjogYXV0bztcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiL2Fzc2V0cy9pbWcvdW5sb2NraW5nLWJhY2tncm91bmQuZ2lmXCIpO1xuICBiYWNrZ3JvdW5kLXNpemU6IDEwMCU7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIC5iYWRnZSB7XG4gICAgd2lkdGg6IDI1JTtcbiAgICBmbG9hdDogbGVmdDtcbiAgICBtYXJnaW46IDI1JSAwIDAgMjAlO1xuICAgIGFuaW1hdGlvbi1uYW1lOiBhbmltYXRpb24tYmFkZ2U7XG4gICAgYW5pbWF0aW9uLWR1cmF0aW9uOiAxLjVzO1xuICB9XG4gIC5kaXYtc3ZnIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgbWFyZ2luOiAxMCUgMCAzMCUgLTEwJTtcbiAgICB3aWR0aDogNjAlO1xuICB9XG4gIHN2ZyB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIC5sb2NrLWNvbG9yIHtcbiAgICAgIGZpbGw6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICB9XG4gICAgLmxvY2stY29sb3Itc3Ryb2tlIHtcbiAgICAgIHN0cm9rZTogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgIH1cbiAgICAvLyBibHVyIGZpbHRlciBvbmx5IGFwcGxpZXMgdG8gdGhlIGZpcnN0IDYgZnJhbWVzXG4gICAgLmJsdXItb25seSB7XG4gICAgICBAaW5jbHVkZSBhbmltYXRpb247XG4gICAgICBhbmltYXRpb24tbmFtZTogYW5pbWF0aW9uLWJsdXItb25seTtcbiAgICAgIG9wYWNpdHk6IDA7XG4gICAgfVxuICAgIC5ibHVyLWZpbHRlciB7XG4gICAgICBAaW5jbHVkZSBhbmltYXRpb247XG4gICAgICBhbmltYXRpb24tbmFtZTogYW5pbWF0aW9uLWJsdXItZmlsdGVyO1xuICAgICAgZmlsdGVyOiB1cmwoI2JsdXItZmlsdGVyLTYpO1xuICAgIH1cbiAgICAuYmx1ci1sb2NrIHtcbiAgICAgIEBpbmNsdWRlIGFuaW1hdGlvbjtcbiAgICAgIGFuaW1hdGlvbi1uYW1lOiBhbmltYXRpb24tYmx1ci1sb2NrO1xuICAgICAgdHJhbnNmb3JtOiBtYXRyaXgoIDAuODQ0Nzg3NTk3NjU2MjUsIDAsIDAsIDAuODQ0NTQzNDU3MDMxMjUsIDIwMCwxNzMpO1xuICAgIH1cbiAgICAvLyBsb2NrIHN0YXJ0cyBmcm9tIGZyYW1lIDdcbiAgICAubG9jay1vbmx5IHtcbiAgICAgIEBpbmNsdWRlIGFuaW1hdGlvbjtcbiAgICAgIGFuaW1hdGlvbi1uYW1lOiBhbmltYXRpb24tbG9jay1vbmx5O1xuICAgICAgb3BhY2l0eTogMTtcbiAgICB9XG4gICAgLmxvY2staGVhZCB7XG4gICAgICBAaW5jbHVkZSBhbmltYXRpb247XG4gICAgICBhbmltYXRpb24tbmFtZTogYW5pbWF0aW9uLWxvY2staGVhZDtcbiAgICAgIHRyYW5zZm9ybTogbWF0cml4KCAtMSwgMCwgMCwgMSwgLTc0LjIsMjYuMyk7XG4gICAgfVxuICAgIC5sb2NrLWJvZHkge1xuICAgICAgQGluY2x1ZGUgYW5pbWF0aW9uO1xuICAgICAgYW5pbWF0aW9uLW5hbWU6IGFuaW1hdGlvbi1sb2NrLWJvZHk7XG4gICAgICB0cmFuc2Zvcm06IG1hdHJpeCggMSwgMCwgMCwgMSwgMCwxMTcuODUpO1xuICAgIH1cbiAgICAvLyBjaGVja2JveCBzdGFydHMgZnJvbSBmcmFtZSA2OFxuICAgIC5jaGVja2JveC1vbmx5IHtcbiAgICAgIEBpbmNsdWRlIGFuaW1hdGlvbjtcbiAgICAgIGFuaW1hdGlvbi1uYW1lOiBhbmltYXRpb24tY2hlY2tib3gtb25seTtcbiAgICAgIG9wYWNpdHk6IDE7XG4gICAgfVxuICAgICNjaGVja2JveC02OCB7XG4gICAgICBAaW5jbHVkZSBhbmltYXRpb247XG4gICAgICBhbmltYXRpb24tbmFtZTogYW5pbWF0aW9uLWNoZWNrYm94LTY4O1xuICAgICAgb3BhY2l0eTogMDtcbiAgICB9XG4gICAgI2NoZWNrYm94LTY5IHtcbiAgICAgIEBpbmNsdWRlIGFuaW1hdGlvbjtcbiAgICAgIGFuaW1hdGlvbi1uYW1lOiBhbmltYXRpb24tY2hlY2tib3gtNjk7XG4gICAgICBvcGFjaXR5OiAwO1xuICAgIH1cbiAgICAjY2hlY2tib3gtNzAge1xuICAgICAgQGluY2x1ZGUgYW5pbWF0aW9uO1xuICAgICAgYW5pbWF0aW9uLW5hbWU6IGFuaW1hdGlvbi1jaGVja2JveC03MDtcbiAgICAgIG9wYWNpdHk6IDA7XG4gICAgfVxuICAgICNjaGVja2JveC03MSB7XG4gICAgICBAaW5jbHVkZSBhbmltYXRpb247XG4gICAgICBhbmltYXRpb24tbmFtZTogYW5pbWF0aW9uLWNoZWNrYm94LTcxO1xuICAgICAgb3BhY2l0eTogMDtcbiAgICB9XG4gICAgI2NoZWNrYm94LTcyIHtcbiAgICAgIEBpbmNsdWRlIGFuaW1hdGlvbjtcbiAgICAgIGFuaW1hdGlvbi1uYW1lOiBhbmltYXRpb24tY2hlY2tib3gtNzI7XG4gICAgICBvcGFjaXR5OiAwO1xuICAgIH1cbiAgICAjY2hlY2tib3gtNzMge1xuICAgICAgQGluY2x1ZGUgYW5pbWF0aW9uO1xuICAgICAgYW5pbWF0aW9uLW5hbWU6IGFuaW1hdGlvbi1jaGVja2JveC03MztcbiAgICAgIG9wYWNpdHk6IDA7XG4gICAgfVxuICAgICNjaGVja2JveC03NCB7XG4gICAgICBAaW5jbHVkZSBhbmltYXRpb247XG4gICAgICBhbmltYXRpb24tbmFtZTogYW5pbWF0aW9uLWNoZWNrYm94LTc0O1xuICAgICAgb3BhY2l0eTogMDtcbiAgICB9XG4gICAgLmNoZWNrYm94LTc1IHtcbiAgICAgIEBpbmNsdWRlIGFuaW1hdGlvbjtcbiAgICAgIGFuaW1hdGlvbi1uYW1lOiBhbmltYXRpb24tY2hlY2tib3gtNzU7XG4gICAgICBvcGFjaXR5OiAwO1xuICAgIH1cbiAgICAvLyBjaGVja2JveCBib3JkZXIgZmluYWwgc3RhcnQgZnJvbSBmcmFtZSA3NlxuICAgIC5jaGVja2JveC1ib3JkZXItZmluYWwge1xuICAgICAgQGluY2x1ZGUgYW5pbWF0aW9uO1xuICAgICAgYW5pbWF0aW9uLW5hbWU6IGFuaW1hdGlvbi1jaGVja2JveC1ib3JkZXItZmluYWw7XG4gICAgICBvcGFjaXR5OiAxO1xuICAgIH1cbiAgICAvLyBzdGFydCBmcm9tIGZyYW1lIDg3XG4gICAgLmNoZWNrYm94LWNoZWNrLWZpbmFsIHtcbiAgICAgIEBpbmNsdWRlIGFuaW1hdGlvbjtcbiAgICAgIGFuaW1hdGlvbi1uYW1lOiBhbmltYXRpb24tY2hlY2tib3gtY2hlY2stZmluYWw7XG4gICAgICBvcGFjaXR5OiAxO1xuICAgIH1cbiAgICAvLyBzdGFydCBmcm9tIGZyYW1lIDg3XG4gICAgLmNoZWNrYm94LWNoZWNrIHtcbiAgICAgIEBpbmNsdWRlIGFuaW1hdGlvbjtcbiAgICAgIGFuaW1hdGlvbi1uYW1lOiBhbmltYXRpb24tY2hlY2tib3gtY2hlY2s7XG4gICAgICB0cmFuc2Zvcm06IG1hdHJpeCggMSwgMCwgMCwgMSwgMCwwKTtcbiAgICB9XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWJhZGdlIHtcbiAgMCUge1xuICAgIHRyYW5zZm9ybTogc2NhbGUoMC4xLCAwLjEpO1xuICB9XG4gIDYwJSB7XG4gICAgdHJhbnNmb3JtOiBzY2FsZSgxLjIsIDEuMik7XG4gIH1cbiAgNzAlIHtcbiAgICB0cmFuc2Zvcm06IHNjYWxlKDAuOCwgMC44KTtcbiAgfVxuICA4MCUge1xuICAgIHRyYW5zZm9ybTogc2NhbGUoMS4xLCAxLjEpO1xuICB9XG59XG5Aa2V5ZnJhbWVzIGFuaW1hdGlvbi1ibHVyLW9ubHkge1xuICAvLyBmcmFtZSAxXG4gIDAlIHtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG4gIDUlIHtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG4gIC8vIGZyYW1lIDdcbiAgNiUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWJsdXItZmlsdGVyIHtcbiAgLy8gZnJhbWUgMVxuICAwJSB7XG4gICAgZmlsdGVyOiB1cmwoI2JsdXItZmlsdGVyLTEpO1xuICB9XG4gIDElIHtcbiAgICBmaWx0ZXI6IHVybCgjYmx1ci1maWx0ZXItMik7XG4gIH1cbiAgMiUge1xuICAgIGZpbHRlcjogdXJsKCNibHVyLWZpbHRlci0zKTtcbiAgfVxuICAzJSB7XG4gICAgZmlsdGVyOiB1cmwoI2JsdXItZmlsdGVyLTQpO1xuICB9XG4gIDQlIHtcbiAgICBmaWx0ZXI6IHVybCgjYmx1ci1maWx0ZXItNSk7XG4gIH1cbiAgLy8gZnJhbWUgNlxuICA1JSB7XG4gICAgZmlsdGVyOiB1cmwoI2JsdXItZmlsdGVyLTYpO1xuICB9XG59XG5Aa2V5ZnJhbWVzIGFuaW1hdGlvbi1ibHVyLWxvY2sge1xuICAvLyBmcmFtZSAxXG4gIDAlIHtcbiAgICB0cmFuc2Zvcm06IG1hdHJpeCggMC44NDQ4MTgxMTUyMzQzNzUsIDAsIDAsIDAuODQ0NTczOTc0NjA5Mzc1LCAxOTkuOTUsMjUzKTtcbiAgfVxuICAxJSB7XG4gICAgdHJhbnNmb3JtOiBtYXRyaXgoIDAuODQ0Nzg3NTk3NjU2MjUsIDAsIDAsIDAuODQ0NTQzNDU3MDMxMjUsIDIwMCwyMzcpO1xuICB9XG4gIDIlIHtcbiAgICB0cmFuc2Zvcm06IG1hdHJpeCggMC44NDQ3ODc1OTc2NTYyNSwgMCwgMCwgMC44NDQ1NDM0NTcwMzEyNSwgMjAwLDIyMSk7XG4gIH1cbiAgMyUge1xuICAgIHRyYW5zZm9ybTogbWF0cml4KCAwLjg0NDc4NzU5NzY1NjI1LCAwLCAwLCAwLjg0NDU0MzQ1NzAzMTI1LCAyMDAsMjA1KTtcbiAgfVxuICA0JSB7XG4gICAgdHJhbnNmb3JtOiBtYXRyaXgoIDAuODQ0Nzg3NTk3NjU2MjUsIDAsIDAsIDAuODQ0NTQzNDU3MDMxMjUsIDIwMCwxODkuMDUpO1xuICB9XG4gIC8vIGZyYW1lIDZcbiAgNSUge1xuICAgIHRyYW5zZm9ybTogbWF0cml4KCAwLjg0NDc4NzU5NzY1NjI1LCAwLCAwLCAwLjg0NDU0MzQ1NzAzMTI1LCAyMDAsMTczKTtcbiAgfVxufVxuQGtleWZyYW1lcyBhbmltYXRpb24tbG9jay1vbmx5IHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgNSUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgNiUge1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWxvY2staGVhZCB7XG4gIC8vIGZyYW1lIDdcbiAgNiUge1xuICAgIHRyYW5zZm9ybTogbWF0cml4KCAxLCAwLCAwLCAxLCAwLjEsODQuNyk7XG4gIH1cbiAgLy8gZnJhbWUgMzJcbiAgMzElIHtcbiAgICB0cmFuc2Zvcm06IG1hdHJpeCggMSwgMCwgMCwgMSwgMC4xLDExLjEpO1xuICB9XG4gIC8vIGZyYW1lIDM5XG4gIDM4JSB7XG4gICAgdHJhbnNmb3JtOiBtYXRyaXgoIDEsIDAsIDAsIDEsIDAuMSwzMC4zKTtcbiAgfVxuICAvLyBmcmFtZSA0NVxuICA0NCUge1xuICAgIHRyYW5zZm9ybTogbWF0cml4KCAxLCAwLCAwLCAxLCAwLjEsMjYuMyk7XG4gIH1cbiAgLy8gZnJhbWUgNTRcbiAgNTMlIHtcbiAgICB0cmFuc2Zvcm06IG1hdHJpeCggMSwgMCwgMCwgMSwgMC4xLDMwLjMpO1xuICB9XG4gIC8vIGZyYW1lIDY1XG4gIDY0JSB7XG4gICAgdHJhbnNmb3JtOiBtYXRyaXgoIDEsIDAsIDAsIDEsIDAuMSwyNi4zKTtcbiAgfVxuICAvLyBmcmFtZSA2OFxuICA2NyUge1xuICAgIHRyYW5zZm9ybTogbWF0cml4KCAxLCAwLCAwLCAxLCAwLjEsMjYuMyk7XG4gIH1cbiAgLy8gZnJhbWUgNjlcbiAgNjglIHtcbiAgICB0cmFuc2Zvcm06IG1hdHJpeCggMC44NTcxMzE5NTgwMDc4MTI1LCAwLCAwLCAxLCAtNS4yLDI2LjMpO1xuICB9XG4gIC8vIGZyYW1lIDgyXG4gIDgxJSB7XG4gICAgdHJhbnNmb3JtOiBtYXRyaXgoIC0xLCAwLCAwLCAxLCAtNzQuMiwyNi4zKTtcbiAgfVxufVxuQGtleWZyYW1lcyBhbmltYXRpb24tbG9jay1ib2R5IHtcbiAgLy8gZnJhbWUgMjBcbiAgMTklIHtcbiAgICB0cmFuc2Zvcm06IG1hdHJpeCggMSwgMCwgMCwgMSwgMCwxMTcuODUpO1xuICB9XG4gIDMwJSB7XG4gICAgdHJhbnNmb3JtOiBtYXRyaXgoIDAuOTU1OTc4MzkzNTU0Njg3NSwgMCwgMCwgMS4wNTM3NzE5NzI2NTYyNSwgLTAuMDUsMTE0LjY1KTtcbiAgfVxuICAzNyUge1xuICAgIHRyYW5zZm9ybTogbWF0cml4KCAxLCAwLCAwLCAxLCAwLDExNy44NSk7XG4gIH1cbiAgNDMlIHtcbiAgICB0cmFuc2Zvcm06IG1hdHJpeCggMC45NTU5NzgzOTM1NTQ2ODc1LCAwLCAwLCAxLjAzMzQxNjc0ODA0Njg3NSwgLTAuMDUsMTE1LjkpO1xuICB9XG4gIC8vIGZyYW1lIDU0XG4gIDUzJSB7XG4gICAgdHJhbnNmb3JtOiBtYXRyaXgoIDEsIDAsIDAsIDEsIDAsMTE3Ljg1KTtcbiAgfVxufVxuQGtleWZyYW1lcyBhbmltYXRpb24tY2hlY2tib3gtb25seSB7XG4gIDAlIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIDY2JSB7XG4gICAgb3BhY2l0eTogMDtcbiAgfVxuICAvLyBmcmFtZSA2OFxuICA2NyUge1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LTY4IHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgNjYlIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIC8vIGZyYW1lIDY4XG4gIDY3JSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuICA2OCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LTY5IHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgNjclIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIC8vIGZyYW1lIDY5XG4gIDY4JSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuICA2OSUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LTcwIHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgNjglIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIC8vIGZyYW1lIDcwXG4gIDY5JSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuICA3MCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LTcxIHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgNjklIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIC8vIGZyYW1lIDcxXG4gIDcwJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuICA3MSUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LTcyIHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgNzAlIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIC8vIGZyYW1lIDcyXG4gIDcxJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuICA3MiUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LTczIHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgNzElIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIC8vIGZyYW1lIDczXG4gIDcyJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuICA3MyUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LTc0IHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgNzIlIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIC8vIGZyYW1lIDc0XG4gIDczJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuICA3NCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LTc1IHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgNzMlIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIC8vIGZyYW1lIDc1XG4gIDc0JSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuICA3NSUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LWJvcmRlci1maW5hbCB7XG4gIDAlIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIDc0JSB7XG4gICAgb3BhY2l0eTogMDtcbiAgfVxuICAvLyBmcmFtZSA3NlxuICA3NSUge1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LWNoZWNrLWZpbmFsIHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgODUlIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIC8vIGZyYW1lIDg3XG4gIDg2JSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxufVxuQGtleWZyYW1lcyBhbmltYXRpb24tY2hlY2tib3gtY2hlY2sge1xuICAvLyBmcmFtZSA4N1xuICA4NiUge1xuICAgIHRyYW5zZm9ybTogbWF0cml4KCAxLCAwLCAwLCAxLCAtMzQuOSwxLjUpO1xuICB9XG4gIDkwJSB7XG4gICAgdHJhbnNmb3JtOiBtYXRyaXgoIDEsIDAsIDAsIDEsIDAsMCk7XG4gIH1cbn1cbiIsIi5jb250YWluIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW46IGF1dG87XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi9hc3NldHMvaW1nL3VubG9ja2luZy1iYWNrZ3JvdW5kLmdpZlwiKTtcbiAgYmFja2dyb3VuZC1zaXplOiAxMDAlO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xufVxuLmNvbnRhaW4gLmJhZGdlIHtcbiAgd2lkdGg6IDI1JTtcbiAgZmxvYXQ6IGxlZnQ7XG4gIG1hcmdpbjogMjUlIDAgMCAyMCU7XG4gIGFuaW1hdGlvbi1uYW1lOiBhbmltYXRpb24tYmFkZ2U7XG4gIGFuaW1hdGlvbi1kdXJhdGlvbjogMS41cztcbn1cbi5jb250YWluIC5kaXYtc3ZnIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBtYXJnaW46IDEwJSAwIDMwJSAtMTAlO1xuICB3aWR0aDogNjAlO1xufVxuLmNvbnRhaW4gc3ZnIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbn1cbi5jb250YWluIHN2ZyAubG9jay1jb2xvciB7XG4gIGZpbGw6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cbi5jb250YWluIHN2ZyAubG9jay1jb2xvci1zdHJva2Uge1xuICBzdHJva2U6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cbi5jb250YWluIHN2ZyAuYmx1ci1vbmx5IHtcbiAgYW5pbWF0aW9uLWR1cmF0aW9uOiAzcztcbiAgYW5pbWF0aW9uLW5hbWU6IGFuaW1hdGlvbi1ibHVyLW9ubHk7XG4gIG9wYWNpdHk6IDA7XG59XG4uY29udGFpbiBzdmcgLmJsdXItZmlsdGVyIHtcbiAgYW5pbWF0aW9uLWR1cmF0aW9uOiAzcztcbiAgYW5pbWF0aW9uLW5hbWU6IGFuaW1hdGlvbi1ibHVyLWZpbHRlcjtcbiAgZmlsdGVyOiB1cmwoI2JsdXItZmlsdGVyLTYpO1xufVxuLmNvbnRhaW4gc3ZnIC5ibHVyLWxvY2sge1xuICBhbmltYXRpb24tZHVyYXRpb246IDNzO1xuICBhbmltYXRpb24tbmFtZTogYW5pbWF0aW9uLWJsdXItbG9jaztcbiAgdHJhbnNmb3JtOiBtYXRyaXgoMC44NDQ3ODc1OTc3LCAwLCAwLCAwLjg0NDU0MzQ1NywgMjAwLCAxNzMpO1xufVxuLmNvbnRhaW4gc3ZnIC5sb2NrLW9ubHkge1xuICBhbmltYXRpb24tZHVyYXRpb246IDNzO1xuICBhbmltYXRpb24tbmFtZTogYW5pbWF0aW9uLWxvY2stb25seTtcbiAgb3BhY2l0eTogMTtcbn1cbi5jb250YWluIHN2ZyAubG9jay1oZWFkIHtcbiAgYW5pbWF0aW9uLWR1cmF0aW9uOiAzcztcbiAgYW5pbWF0aW9uLW5hbWU6IGFuaW1hdGlvbi1sb2NrLWhlYWQ7XG4gIHRyYW5zZm9ybTogbWF0cml4KC0xLCAwLCAwLCAxLCAtNzQuMiwgMjYuMyk7XG59XG4uY29udGFpbiBzdmcgLmxvY2stYm9keSB7XG4gIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7XG4gIGFuaW1hdGlvbi1uYW1lOiBhbmltYXRpb24tbG9jay1ib2R5O1xuICB0cmFuc2Zvcm06IG1hdHJpeCgxLCAwLCAwLCAxLCAwLCAxMTcuODUpO1xufVxuLmNvbnRhaW4gc3ZnIC5jaGVja2JveC1vbmx5IHtcbiAgYW5pbWF0aW9uLWR1cmF0aW9uOiAzcztcbiAgYW5pbWF0aW9uLW5hbWU6IGFuaW1hdGlvbi1jaGVja2JveC1vbmx5O1xuICBvcGFjaXR5OiAxO1xufVxuLmNvbnRhaW4gc3ZnICNjaGVja2JveC02OCB7XG4gIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7XG4gIGFuaW1hdGlvbi1uYW1lOiBhbmltYXRpb24tY2hlY2tib3gtNjg7XG4gIG9wYWNpdHk6IDA7XG59XG4uY29udGFpbiBzdmcgI2NoZWNrYm94LTY5IHtcbiAgYW5pbWF0aW9uLWR1cmF0aW9uOiAzcztcbiAgYW5pbWF0aW9uLW5hbWU6IGFuaW1hdGlvbi1jaGVja2JveC02OTtcbiAgb3BhY2l0eTogMDtcbn1cbi5jb250YWluIHN2ZyAjY2hlY2tib3gtNzAge1xuICBhbmltYXRpb24tZHVyYXRpb246IDNzO1xuICBhbmltYXRpb24tbmFtZTogYW5pbWF0aW9uLWNoZWNrYm94LTcwO1xuICBvcGFjaXR5OiAwO1xufVxuLmNvbnRhaW4gc3ZnICNjaGVja2JveC03MSB7XG4gIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7XG4gIGFuaW1hdGlvbi1uYW1lOiBhbmltYXRpb24tY2hlY2tib3gtNzE7XG4gIG9wYWNpdHk6IDA7XG59XG4uY29udGFpbiBzdmcgI2NoZWNrYm94LTcyIHtcbiAgYW5pbWF0aW9uLWR1cmF0aW9uOiAzcztcbiAgYW5pbWF0aW9uLW5hbWU6IGFuaW1hdGlvbi1jaGVja2JveC03MjtcbiAgb3BhY2l0eTogMDtcbn1cbi5jb250YWluIHN2ZyAjY2hlY2tib3gtNzMge1xuICBhbmltYXRpb24tZHVyYXRpb246IDNzO1xuICBhbmltYXRpb24tbmFtZTogYW5pbWF0aW9uLWNoZWNrYm94LTczO1xuICBvcGFjaXR5OiAwO1xufVxuLmNvbnRhaW4gc3ZnICNjaGVja2JveC03NCB7XG4gIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7XG4gIGFuaW1hdGlvbi1uYW1lOiBhbmltYXRpb24tY2hlY2tib3gtNzQ7XG4gIG9wYWNpdHk6IDA7XG59XG4uY29udGFpbiBzdmcgLmNoZWNrYm94LTc1IHtcbiAgYW5pbWF0aW9uLWR1cmF0aW9uOiAzcztcbiAgYW5pbWF0aW9uLW5hbWU6IGFuaW1hdGlvbi1jaGVja2JveC03NTtcbiAgb3BhY2l0eTogMDtcbn1cbi5jb250YWluIHN2ZyAuY2hlY2tib3gtYm9yZGVyLWZpbmFsIHtcbiAgYW5pbWF0aW9uLWR1cmF0aW9uOiAzcztcbiAgYW5pbWF0aW9uLW5hbWU6IGFuaW1hdGlvbi1jaGVja2JveC1ib3JkZXItZmluYWw7XG4gIG9wYWNpdHk6IDE7XG59XG4uY29udGFpbiBzdmcgLmNoZWNrYm94LWNoZWNrLWZpbmFsIHtcbiAgYW5pbWF0aW9uLWR1cmF0aW9uOiAzcztcbiAgYW5pbWF0aW9uLW5hbWU6IGFuaW1hdGlvbi1jaGVja2JveC1jaGVjay1maW5hbDtcbiAgb3BhY2l0eTogMTtcbn1cbi5jb250YWluIHN2ZyAuY2hlY2tib3gtY2hlY2sge1xuICBhbmltYXRpb24tZHVyYXRpb246IDNzO1xuICBhbmltYXRpb24tbmFtZTogYW5pbWF0aW9uLWNoZWNrYm94LWNoZWNrO1xuICB0cmFuc2Zvcm06IG1hdHJpeCgxLCAwLCAwLCAxLCAwLCAwKTtcbn1cblxuQGtleWZyYW1lcyBhbmltYXRpb24tYmFkZ2Uge1xuICAwJSB7XG4gICAgdHJhbnNmb3JtOiBzY2FsZSgwLjEsIDAuMSk7XG4gIH1cbiAgNjAlIHtcbiAgICB0cmFuc2Zvcm06IHNjYWxlKDEuMiwgMS4yKTtcbiAgfVxuICA3MCUge1xuICAgIHRyYW5zZm9ybTogc2NhbGUoMC44LCAwLjgpO1xuICB9XG4gIDgwJSB7XG4gICAgdHJhbnNmb3JtOiBzY2FsZSgxLjEsIDEuMSk7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWJsdXItb25seSB7XG4gIDAlIHtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG4gIDUlIHtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG4gIDYlIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG59XG5Aa2V5ZnJhbWVzIGFuaW1hdGlvbi1ibHVyLWZpbHRlciB7XG4gIDAlIHtcbiAgICBmaWx0ZXI6IHVybCgjYmx1ci1maWx0ZXItMSk7XG4gIH1cbiAgMSUge1xuICAgIGZpbHRlcjogdXJsKCNibHVyLWZpbHRlci0yKTtcbiAgfVxuICAyJSB7XG4gICAgZmlsdGVyOiB1cmwoI2JsdXItZmlsdGVyLTMpO1xuICB9XG4gIDMlIHtcbiAgICBmaWx0ZXI6IHVybCgjYmx1ci1maWx0ZXItNCk7XG4gIH1cbiAgNCUge1xuICAgIGZpbHRlcjogdXJsKCNibHVyLWZpbHRlci01KTtcbiAgfVxuICA1JSB7XG4gICAgZmlsdGVyOiB1cmwoI2JsdXItZmlsdGVyLTYpO1xuICB9XG59XG5Aa2V5ZnJhbWVzIGFuaW1hdGlvbi1ibHVyLWxvY2sge1xuICAwJSB7XG4gICAgdHJhbnNmb3JtOiBtYXRyaXgoMC44NDQ4MTgxMTUyLCAwLCAwLCAwLjg0NDU3Mzk3NDYsIDE5OS45NSwgMjUzKTtcbiAgfVxuICAxJSB7XG4gICAgdHJhbnNmb3JtOiBtYXRyaXgoMC44NDQ3ODc1OTc3LCAwLCAwLCAwLjg0NDU0MzQ1NywgMjAwLCAyMzcpO1xuICB9XG4gIDIlIHtcbiAgICB0cmFuc2Zvcm06IG1hdHJpeCgwLjg0NDc4NzU5NzcsIDAsIDAsIDAuODQ0NTQzNDU3LCAyMDAsIDIyMSk7XG4gIH1cbiAgMyUge1xuICAgIHRyYW5zZm9ybTogbWF0cml4KDAuODQ0Nzg3NTk3NywgMCwgMCwgMC44NDQ1NDM0NTcsIDIwMCwgMjA1KTtcbiAgfVxuICA0JSB7XG4gICAgdHJhbnNmb3JtOiBtYXRyaXgoMC44NDQ3ODc1OTc3LCAwLCAwLCAwLjg0NDU0MzQ1NywgMjAwLCAxODkuMDUpO1xuICB9XG4gIDUlIHtcbiAgICB0cmFuc2Zvcm06IG1hdHJpeCgwLjg0NDc4NzU5NzcsIDAsIDAsIDAuODQ0NTQzNDU3LCAyMDAsIDE3Myk7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWxvY2stb25seSB7XG4gIDAlIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIDUlIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIDYlIHtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG59XG5Aa2V5ZnJhbWVzIGFuaW1hdGlvbi1sb2NrLWhlYWQge1xuICA2JSB7XG4gICAgdHJhbnNmb3JtOiBtYXRyaXgoMSwgMCwgMCwgMSwgMC4xLCA4NC43KTtcbiAgfVxuICAzMSUge1xuICAgIHRyYW5zZm9ybTogbWF0cml4KDEsIDAsIDAsIDEsIDAuMSwgMTEuMSk7XG4gIH1cbiAgMzglIHtcbiAgICB0cmFuc2Zvcm06IG1hdHJpeCgxLCAwLCAwLCAxLCAwLjEsIDMwLjMpO1xuICB9XG4gIDQ0JSB7XG4gICAgdHJhbnNmb3JtOiBtYXRyaXgoMSwgMCwgMCwgMSwgMC4xLCAyNi4zKTtcbiAgfVxuICA1MyUge1xuICAgIHRyYW5zZm9ybTogbWF0cml4KDEsIDAsIDAsIDEsIDAuMSwgMzAuMyk7XG4gIH1cbiAgNjQlIHtcbiAgICB0cmFuc2Zvcm06IG1hdHJpeCgxLCAwLCAwLCAxLCAwLjEsIDI2LjMpO1xuICB9XG4gIDY3JSB7XG4gICAgdHJhbnNmb3JtOiBtYXRyaXgoMSwgMCwgMCwgMSwgMC4xLCAyNi4zKTtcbiAgfVxuICA2OCUge1xuICAgIHRyYW5zZm9ybTogbWF0cml4KDAuODU3MTMxOTU4LCAwLCAwLCAxLCAtNS4yLCAyNi4zKTtcbiAgfVxuICA4MSUge1xuICAgIHRyYW5zZm9ybTogbWF0cml4KC0xLCAwLCAwLCAxLCAtNzQuMiwgMjYuMyk7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWxvY2stYm9keSB7XG4gIDE5JSB7XG4gICAgdHJhbnNmb3JtOiBtYXRyaXgoMSwgMCwgMCwgMSwgMCwgMTE3Ljg1KTtcbiAgfVxuICAzMCUge1xuICAgIHRyYW5zZm9ybTogbWF0cml4KDAuOTU1OTc4MzkzNiwgMCwgMCwgMS4wNTM3NzE5NzI3LCAtMC4wNSwgMTE0LjY1KTtcbiAgfVxuICAzNyUge1xuICAgIHRyYW5zZm9ybTogbWF0cml4KDEsIDAsIDAsIDEsIDAsIDExNy44NSk7XG4gIH1cbiAgNDMlIHtcbiAgICB0cmFuc2Zvcm06IG1hdHJpeCgwLjk1NTk3ODM5MzYsIDAsIDAsIDEuMDMzNDE2NzQ4LCAtMC4wNSwgMTE1LjkpO1xuICB9XG4gIDUzJSB7XG4gICAgdHJhbnNmb3JtOiBtYXRyaXgoMSwgMCwgMCwgMSwgMCwgMTE3Ljg1KTtcbiAgfVxufVxuQGtleWZyYW1lcyBhbmltYXRpb24tY2hlY2tib3gtb25seSB7XG4gIDAlIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIDY2JSB7XG4gICAgb3BhY2l0eTogMDtcbiAgfVxuICA2NyUge1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LTY4IHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgNjYlIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIDY3JSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuICA2OCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LTY5IHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgNjclIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIDY4JSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuICA2OSUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LTcwIHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgNjglIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIDY5JSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuICA3MCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LTcxIHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgNjklIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIDcwJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuICA3MSUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LTcyIHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgNzAlIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIDcxJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuICA3MiUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LTczIHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgNzElIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIDcyJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuICA3MyUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LTc0IHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgNzIlIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIDczJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuICA3NCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LTc1IHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgNzMlIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIDc0JSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuICA3NSUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LWJvcmRlci1maW5hbCB7XG4gIDAlIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIDc0JSB7XG4gICAgb3BhY2l0eTogMDtcbiAgfVxuICA3NSUge1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYW5pbWF0aW9uLWNoZWNrYm94LWNoZWNrLWZpbmFsIHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgODUlIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIDg2JSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxufVxuQGtleWZyYW1lcyBhbmltYXRpb24tY2hlY2tib3gtY2hlY2sge1xuICA4NiUge1xuICAgIHRyYW5zZm9ybTogbWF0cml4KDEsIDAsIDAsIDEsIC0zNC45LCAxLjUpO1xuICB9XG4gIDkwJSB7XG4gICAgdHJhbnNmb3JtOiBtYXRyaXgoMSwgMCwgMCwgMSwgMCwgMCk7XG4gIH1cbn0iXX0= */");

/***/ }),

/***/ "./src/app/shared/components/unlocking/unlocking.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/shared/components/unlocking/unlocking.component.ts ***!
  \********************************************************************/
/*! exports provided: UnlockingComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UnlockingComponent", function() { return UnlockingComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

var UnlockingComponent = /** @class */ (function () {
    function UnlockingComponent() {
    }
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], UnlockingComponent.prototype, "badgeUrl", void 0);
    UnlockingComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'unlocking',
            template: __importDefault(__webpack_require__(/*! raw-loader!./unlocking.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/unlocking/unlocking.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./unlocking.component.scss */ "./src/app/shared/components/unlocking/unlocking.component.scss")).default]
        }),
        __metadata("design:paramtypes", [])
    ], UnlockingComponent);
    return UnlockingComponent;
}());



/***/ }),

/***/ "./src/app/shared/directives/drag-and-drop/drag-and-drop.directive.ts":
/*!****************************************************************************!*\
  !*** ./src/app/shared/directives/drag-and-drop/drag-and-drop.directive.ts ***!
  \****************************************************************************/
/*! exports provided: DragAndDropDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DragAndDropDirective", function() { return DragAndDropDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

var DragAndDropDirective = /** @class */ (function () {
    function DragAndDropDirective() {
        this.fileDropped = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    DragAndDropDirective.prototype.ondragover = function (evt) {
        evt.preventDefault();
        evt.stopPropagation();
        if (!this.disabled) {
            this.fileOver = true;
        }
    };
    DragAndDropDirective.prototype.ondragleave = function (evt) {
        evt.preventDefault();
        evt.stopPropagation();
        this.fileOver = false;
    };
    DragAndDropDirective.prototype.ondrop = function (evt) {
        evt.preventDefault();
        evt.stopPropagation();
        if (this.disabled) {
            return;
        }
        this.fileOver = false;
        var files = evt.dataTransfer.files;
        // error - no file droped
        if (files.length < 0) {
            this.fileDropped.emit({
                success: false,
                message: 'No file droped'
            });
            return;
        }
        // error - more than one file droped
        if (files.length > 1) {
            this.fileDropped.emit({
                success: false,
                message: 'More than one file droped'
            });
            return;
        }
        var file = files[0];
        // error - not maching file type
        if (this.acceptFileType && this.acceptFileType !== 'any' && !file.type.includes(this.acceptFileType)) {
            this.fileDropped.emit({
                success: false,
                message: 'Not a maching file type'
            });
            return;
        }
        this.fileDropped.emit({
            success: true,
            file: file
        });
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], DragAndDropDirective.prototype, "fileDropped", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], DragAndDropDirective.prototype, "acceptFileType", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Boolean)
    ], DragAndDropDirective.prototype, "disabled", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"])('class.fileover'),
        __metadata("design:type", Boolean)
    ], DragAndDropDirective.prototype, "fileOver", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"])('dragover', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], DragAndDropDirective.prototype, "ondragover", null);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"])('dragleave', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], DragAndDropDirective.prototype, "ondragleave", null);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"])('drop', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], DragAndDropDirective.prototype, "ondrop", null);
    DragAndDropDirective = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"])({
            selector: '[appDragAndDrop]'
        })
    ], DragAndDropDirective);
    return DragAndDropDirective;
}());



/***/ }),

/***/ "./src/app/shared/directives/float/float.directive.ts":
/*!************************************************************!*\
  !*** ./src/app/shared/directives/float/float.directive.ts ***!
  \************************************************************/
/*! exports provided: FloatDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FloatDirective", function() { return FloatDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


var PRACTERA_CARD_SHADOW = '0 4px 16px rgba(0,0,0,.12)';
var ACTIVITY_CARD_SHADOW = '-3px 3px 4px rgba(0, 0, 0, 0.21)';
var FloatDirective = /** @class */ (function () {
    function FloatDirective(el, utils) {
        this.el = el;
        this.utils = utils;
        this.isActivityCard = false;
    }
    FloatDirective.prototype.onMouseLeave = function () {
        this.float(null);
    };
    FloatDirective.prototype.onScroll = function () {
        this.float(null);
    };
    FloatDirective.prototype.float = function (color) {
        this.el.nativeElement.style.backgroundColor = color;
        this.isDisplaying(this.el.nativeElement);
    };
    /**
     * @description preliminary test to calculate a DOM's appearance in screen
     * @param {HTML DOM} element targeted DOM
     */
    FloatDirective.prototype.isDisplaying = function (element) {
        var _this = this;
        var cards = element.getElementsByTagName('ion-card');
        this.utils.each(cards, function (card) {
            _this.getBoundaryRect(card);
        });
    };
    /**
     * @description get boundary information of an valid HTML DOM, and apply styles based on
     *              the returned boundary information
     * @param {HTML DOM} element targeted HTML DOM
     */
    FloatDirective.prototype.getBoundaryRect = function (element) {
        var child = element.getBoundingClientRect();
        var el = this.el.nativeElement.getBoundingClientRect();
        element.style.transition = 'all 0.1s ease';
        if (el.top > (child.top - 5)) { // top
            this.renderStyle(element, true);
        }
        else {
            this.renderStyle(element, false);
        }
    };
    /**
     * @description to apply boxShadow to targeted element (if isActivityCard == true, apply ACTIVITY_CARD_SHADOW instead of generic shadow)
     * @param {HTML DOM} element  targeted HTML DOM
     * @param {boolean} hideShadow true: hide shadow, false: show shadow
     */
    FloatDirective.prototype.renderStyle = function (element, hideShadow) {
        if (hideShadow && element.style.boxShadow !== 'none') {
            element.style.boxShadow = 'none';
            return;
        }
        if (!hideShadow && element.style.boxShadow === 'none') {
            element.style.boxShadow = this.isActivityCard ? ACTIVITY_CARD_SHADOW : PRACTERA_CARD_SHADOW;
            return;
        }
    };
    FloatDirective.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_1__["UtilsService"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], FloatDirective.prototype, "isActivityCard", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"])('mouseleave'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], FloatDirective.prototype, "onMouseLeave", null);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"])('wheel'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], FloatDirective.prototype, "onScroll", null);
    FloatDirective = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"])({
            selector: '[appFloat]'
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"], _services_utils_service__WEBPACK_IMPORTED_MODULE_1__["UtilsService"]])
    ], FloatDirective);
    return FloatDirective;
}());



/***/ }),

/***/ "./src/app/shared/new-relic/new-relic.module.ts":
/*!******************************************************!*\
  !*** ./src/app/shared/new-relic/new-relic.module.ts ***!
  \******************************************************/
/*! exports provided: NewRelicModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewRelicModule", function() { return NewRelicModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/common.js");
/* harmony import */ var _new_relic_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./new-relic.service */ "./src/app/shared/new-relic/new-relic.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



var NewRelicModule = /** @class */ (function () {
    function NewRelicModule(parentModule) {
        if (parentModule) {
            throw new Error('NewRelicModule is already loaded. Import it in the AppModule only');
        }
    }
    NewRelicModule_1 = NewRelicModule;
    NewRelicModule.forRoot = function () {
        return {
            ngModule: NewRelicModule_1,
        };
    };
    var NewRelicModule_1;
    NewRelicModule.ctorParameters = function () { return [
        { type: NewRelicModule, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["SkipSelf"] }] }
    ]; };
    NewRelicModule = NewRelicModule_1 = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            declarations: [],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]
            ],
            providers: [_new_relic_service__WEBPACK_IMPORTED_MODULE_2__["NewRelicService"]],
            exports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]]
        }),
        __param(0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"])()), __param(0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["SkipSelf"])()),
        __metadata("design:paramtypes", [NewRelicModule])
    ], NewRelicModule);
    return NewRelicModule;
}());



/***/ }),

/***/ "./src/app/shared/new-relic/new-relic.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/shared/new-relic/new-relic.service.ts ***!
  \*******************************************************/
/*! exports provided: NewRelicService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewRelicService", function() { return NewRelicService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


// import * as NewRelic from 'newrelic';
var NewRelicService = /** @class */ (function () {
    function NewRelicService(storage) {
        this.storage = storage;
        if (newrelic) {
            this.newrelic = newrelic.interaction();
            this.newrelic.onEnd(function () {
                console.log('interaction ended');
            });
        }
    }
    NewRelicService.prototype.setPageViewName = function (name) {
        return newrelic.setPageViewName(name);
    };
    NewRelicService.prototype.addPageAction = function (name, customAttr) {
        return newrelic.addPageAction(name, customAttr);
    };
    NewRelicService.prototype.setCustomAttribute = function (name, value) {
        return newrelic.setCustomAttribute(name, value);
    };
    NewRelicService.prototype.noticeError = function (error, customAttr) {
        var _a = this.storage.getUser(), userHash = _a.userHash, enrolment = _a.enrolment;
        if (userHash) {
            this.setAttribute('user hash', userHash);
        }
        if (enrolment && enrolment.id) {
            this.setAttribute('enrolment ID', enrolment.id);
        }
        return newrelic.noticeError(error);
    };
    NewRelicService.prototype.createTracer = function (name, callback) {
        var newInteraction = newrelic.interaction();
        return newInteraction.createTracer(name, callback);
    };
    NewRelicService.prototype.getContext = function () {
        return this.newrelic.getContext().save();
    };
    NewRelicService.prototype.actionText = function (name) {
        return this.newrelic.actionText(name).save();
    };
    NewRelicService.prototype.setAttribute = function (name, value) {
        return this.newrelic.setAttribute(name, value).save();
    };
    NewRelicService.ctorParameters = function () { return [
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_1__["BrowserStorageService"] }
    ]; };
    NewRelicService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root',
        }),
        __metadata("design:paramtypes", [_services_storage_service__WEBPACK_IMPORTED_MODULE_1__["BrowserStorageService"]])
    ], NewRelicService);
    return NewRelicService;
}());



/***/ }),

/***/ "./src/app/shared/notification/achievement-pop-up/achievement-pop-up.component.scss":
/*!******************************************************************************************!*\
  !*** ./src/app/shared/notification/achievement-pop-up/achievement-pop-up.component.scss ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".pop-up-content {\n  background-color: transparent !important;\n  --ion-color-base: transparent !important;\n}\n.pop-up-content .image-content {\n  margin-top: 5px;\n  margin-bottom: -45px;\n}\n.pop-up-content .image-content .image {\n  padding: 12px;\n}\n.pop-up-content .image-content .image img.default {\n  -webkit-filter: invert(0.5);\n          filter: invert(0.5);\n}\n.pop-up-content .details-container {\n  padding: 20px;\n  border-radius: 12px;\n}\n.pop-up-content .div-after-img {\n  margin: 0;\n  margin-bottom: 15px;\n}\n.pop-up-content.desktop-view .details-container .div-after-img .title {\n  margin-top: 30px;\n}\n.pop-up-content.desktop-view .details-container .div-after-img .points {\n  margin: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGF3L1dvcmtzcGFjZXMvd3d3L2ludGVyc2VjdGl2ZS9wcmFjdGVyYS1hcHAtdjIvc3JjL2FwcC9zaGFyZWQvbm90aWZpY2F0aW9uL2FjaGlldmVtZW50LXBvcC11cC9hY2hpZXZlbWVudC1wb3AtdXAuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3NoYXJlZC9ub3RpZmljYXRpb24vYWNoaWV2ZW1lbnQtcG9wLXVwL2FjaGlldmVtZW50LXBvcC11cC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHdDQUFBO0VBQ0Esd0NBQUE7QUNDRjtBRENFO0VBQ0UsZUFBQTtFQUNBLG9CQUFBO0FDQ0o7QURDSTtFQUNFLGFBQUE7QUNDTjtBREVRO0VBQ0UsMkJBQUE7VUFBQSxtQkFBQTtBQ0FWO0FETUU7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7QUNKSjtBRE9FO0VBQ0UsU0FBQTtFQUNBLG1CQUFBO0FDTEo7QURjVTtFQUNFLGdCQUFBO0FDWFo7QURhVTtFQUNFLFlBQUE7QUNYWiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9ub3RpZmljYXRpb24vYWNoaWV2ZW1lbnQtcG9wLXVwL2FjaGlldmVtZW50LXBvcC11cC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5wb3AtdXAtY29udGVudCB7XG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gIC0taW9uLWNvbG9yLWJhc2U6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG5cbiAgLmltYWdlLWNvbnRlbnQge1xuICAgIG1hcmdpbi10b3A6IDVweDtcbiAgICBtYXJnaW4tYm90dG9tOiAtNDVweDtcblxuICAgIC5pbWFnZSB7XG4gICAgICBwYWRkaW5nOiAxMnB4O1xuXG4gICAgICBpbWcge1xuICAgICAgICAmLmRlZmF1bHQge1xuICAgICAgICAgIGZpbHRlcjogaW52ZXJ0KC41KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC5kZXRhaWxzLWNvbnRhaW5lciB7XG4gICAgcGFkZGluZzogMjBweDtcbiAgICBib3JkZXItcmFkaXVzOiAxMnB4O1xuICB9XG5cbiAgLmRpdi1hZnRlci1pbWcge1xuICAgIG1hcmdpbjogMDtcbiAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xuICB9XG5cbn1cblxuICAucG9wLXVwLWNvbnRlbnQge1xuICAgICYuZGVza3RvcC12aWV3IHtcbiAgICAgIC5kZXRhaWxzLWNvbnRhaW5lciB7XG4gICAgICAgIC5kaXYtYWZ0ZXItaW1nIHtcbiAgICAgICAgICAudGl0bGUge1xuICAgICAgICAgICAgbWFyZ2luLXRvcDogMzBweDtcbiAgICAgICAgICB9XG4gICAgICAgICAgLnBvaW50cyB7XG4gICAgICAgICAgICBtYXJnaW46IDEwcHg7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG4iLCIucG9wLXVwLWNvbnRlbnQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICAtLWlvbi1jb2xvci1iYXNlOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xufVxuLnBvcC11cC1jb250ZW50IC5pbWFnZS1jb250ZW50IHtcbiAgbWFyZ2luLXRvcDogNXB4O1xuICBtYXJnaW4tYm90dG9tOiAtNDVweDtcbn1cbi5wb3AtdXAtY29udGVudCAuaW1hZ2UtY29udGVudCAuaW1hZ2Uge1xuICBwYWRkaW5nOiAxMnB4O1xufVxuLnBvcC11cC1jb250ZW50IC5pbWFnZS1jb250ZW50IC5pbWFnZSBpbWcuZGVmYXVsdCB7XG4gIGZpbHRlcjogaW52ZXJ0KDAuNSk7XG59XG4ucG9wLXVwLWNvbnRlbnQgLmRldGFpbHMtY29udGFpbmVyIHtcbiAgcGFkZGluZzogMjBweDtcbiAgYm9yZGVyLXJhZGl1czogMTJweDtcbn1cbi5wb3AtdXAtY29udGVudCAuZGl2LWFmdGVyLWltZyB7XG4gIG1hcmdpbjogMDtcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcbn1cblxuLnBvcC11cC1jb250ZW50LmRlc2t0b3AtdmlldyAuZGV0YWlscy1jb250YWluZXIgLmRpdi1hZnRlci1pbWcgLnRpdGxlIHtcbiAgbWFyZ2luLXRvcDogMzBweDtcbn1cbi5wb3AtdXAtY29udGVudC5kZXNrdG9wLXZpZXcgLmRldGFpbHMtY29udGFpbmVyIC5kaXYtYWZ0ZXItaW1nIC5wb2ludHMge1xuICBtYXJnaW46IDEwcHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/shared/notification/achievement-pop-up/achievement-pop-up.component.ts":
/*!****************************************************************************************!*\
  !*** ./src/app/shared/notification/achievement-pop-up/achievement-pop-up.component.ts ***!
  \****************************************************************************************/
/*! exports provided: AchievementPopUpComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AchievementPopUpComponent", function() { return AchievementPopUpComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm5/ionic-angular.js");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



var AchievementPopUpComponent = /** @class */ (function () {
    function AchievementPopUpComponent(modalController, utils) {
        this.modalController = modalController;
        this.utils = utils;
        this.type = '';
    }
    AchievementPopUpComponent.prototype.confirmed = function () {
        this.modalController.dismiss();
    };
    AchievementPopUpComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilsService"] }
    ]; };
    AchievementPopUpComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-achievement-pop-up',
            template: __importDefault(__webpack_require__(/*! raw-loader!./achievement-pop-up.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/notification/achievement-pop-up/achievement-pop-up.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./achievement-pop-up.component.scss */ "./src/app/shared/notification/achievement-pop-up/achievement-pop-up.component.scss")).default]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilsService"]])
    ], AchievementPopUpComponent);
    return AchievementPopUpComponent;
}());



/***/ }),

/***/ "./src/app/shared/notification/activity-complete-pop-up/activity-complete-pop-up.component.scss":
/*!******************************************************************************************************!*\
  !*** ./src/app/shared/notification/activity-complete-pop-up/activity-complete-pop-up.component.scss ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("p {\n  line-height: 1.5;\n}\n\n.fixed-bottom {\n  position: fixed;\n  width: 100%;\n  bottom: 0;\n}\n\n.fixed-bottom hr {\n  border-top: 3px solid var(--ion-color-light);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGF3L1dvcmtzcGFjZXMvd3d3L2ludGVyc2VjdGl2ZS9wcmFjdGVyYS1hcHAtdjIvc3JjL2FwcC9zaGFyZWQvbm90aWZpY2F0aW9uL2FjdGl2aXR5LWNvbXBsZXRlLXBvcC11cC9hY3Rpdml0eS1jb21wbGV0ZS1wb3AtdXAuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3NoYXJlZC9ub3RpZmljYXRpb24vYWN0aXZpdHktY29tcGxldGUtcG9wLXVwL2FjdGl2aXR5LWNvbXBsZXRlLXBvcC11cC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0FDQ0Y7O0FEQ0E7RUFDRSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7QUNFRjs7QURERTtFQUNFLDRDQUFBO0FDR0oiLCJmaWxlIjoic3JjL2FwcC9zaGFyZWQvbm90aWZpY2F0aW9uL2FjdGl2aXR5LWNvbXBsZXRlLXBvcC11cC9hY3Rpdml0eS1jb21wbGV0ZS1wb3AtdXAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJwIHtcbiAgbGluZS1oZWlnaHQ6IDEuNSxcbn1cbi5maXhlZC1ib3R0b20ge1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHdpZHRoOiAxMDAlO1xuICBib3R0b206IDA7XG4gIGhyIHtcbiAgICBib3JkZXItdG9wOiAzcHggc29saWQgdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbiAgfVxufVxuIiwicCB7XG4gIGxpbmUtaGVpZ2h0OiAxLjU7XG59XG5cbi5maXhlZC1ib3R0b20ge1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHdpZHRoOiAxMDAlO1xuICBib3R0b206IDA7XG59XG4uZml4ZWQtYm90dG9tIGhyIHtcbiAgYm9yZGVyLXRvcDogM3B4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1saWdodCk7XG59Il19 */");

/***/ }),

/***/ "./src/app/shared/notification/activity-complete-pop-up/activity-complete-pop-up.component.ts":
/*!****************************************************************************************************!*\
  !*** ./src/app/shared/notification/activity-complete-pop-up/activity-complete-pop-up.component.ts ***!
  \****************************************************************************************************/
/*! exports provided: ActivityCompletePopUpComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActivityCompletePopUpComponent", function() { return ActivityCompletePopUpComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm5/ionic-angular.js");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};




var ActivityCompletePopUpComponent = /** @class */ (function () {
    function ActivityCompletePopUpComponent(modalController, utils, router) {
        this.modalController = modalController;
        this.utils = utils;
        this.router = router;
    }
    ActivityCompletePopUpComponent.prototype.confirmed = function (continueToActivity) {
        this.modalController.dismiss();
        if (!continueToActivity) {
            this.router.navigate(['app', 'activity', this.activityId]);
        }
        else {
            if (this.activityCompleted) {
                this.router.navigate(['app', 'home'], { queryParams: { activityId: this.activityId, activityCompleted: this.activityCompleted } });
            }
            else {
                this.router.navigate(['app', 'home'], { queryParams: { activityId: this.activityId } });
            }
        }
    };
    ActivityCompletePopUpComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilsService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
    ]; };
    ActivityCompletePopUpComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-activity-complete-pop-up',
            template: __importDefault(__webpack_require__(/*! raw-loader!./activity-complete-pop-up.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/notification/activity-complete-pop-up/activity-complete-pop-up.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./activity-complete-pop-up.component.scss */ "./src/app/shared/notification/activity-complete-pop-up/activity-complete-pop-up.component.scss")).default]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilsService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
    ], ActivityCompletePopUpComponent);
    return ActivityCompletePopUpComponent;
}());



/***/ }),

/***/ "./src/app/shared/notification/lock-team-assessment-pop-up/lock-team-assessment-pop-up.component.scss":
/*!************************************************************************************************************!*\
  !*** ./src/app/shared/notification/lock-team-assessment-pop-up/lock-team-assessment-pop-up.component.scss ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".pop-up-content {\n  background-color: #ffffff !important;\n  --ion-color-base: #ffffff !important;\n  overflow-y: hidden !important;\n}\n.pop-up-content.desktop-view .image-content {\n  margin-top: 35px;\n}\n.pop-up-content.desktop-view .div-after-img {\n  margin-bottom: 35px;\n}\n.pop-up-content .image-content {\n  margin-top: 20px;\n}\n.pop-up-content .image-content .image {\n  padding: 5px;\n}\n.pop-up-content .div-after-img {\n  margin: 0;\n  margin-bottom: 15px;\n}\n.pop-up-content .description {\n  max-height: none !important;\n  -webkit-line-clamp: unset !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGF3L1dvcmtzcGFjZXMvd3d3L2ludGVyc2VjdGl2ZS9wcmFjdGVyYS1hcHAtdjIvc3JjL2FwcC9zaGFyZWQvbm90aWZpY2F0aW9uL2xvY2stdGVhbS1hc3Nlc3NtZW50LXBvcC11cC9sb2NrLXRlYW0tYXNzZXNzbWVudC1wb3AtdXAuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3NoYXJlZC9ub3RpZmljYXRpb24vbG9jay10ZWFtLWFzc2Vzc21lbnQtcG9wLXVwL2xvY2stdGVhbS1hc3Nlc3NtZW50LXBvcC11cC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG9DQUFBO0VBQ0Esb0NBQUE7RUFDQSw2QkFBQTtBQ0NGO0FERUk7RUFDRSxnQkFBQTtBQ0FOO0FERUk7RUFDRSxtQkFBQTtBQ0FOO0FESUU7RUFDRSxnQkFBQTtBQ0ZKO0FESUk7RUFDRSxZQUFBO0FDRk47QURNRTtFQUNFLFNBQUE7RUFDQSxtQkFBQTtBQ0pKO0FET0U7RUFDRSwyQkFBQTtFQUNBLG9DQUFBO0FDTEoiLCJmaWxlIjoic3JjL2FwcC9zaGFyZWQvbm90aWZpY2F0aW9uL2xvY2stdGVhbS1hc3Nlc3NtZW50LXBvcC11cC9sb2NrLXRlYW0tYXNzZXNzbWVudC1wb3AtdXAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucG9wLXVwLWNvbnRlbnQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmICFpbXBvcnRhbnQ7XG4gIC0taW9uLWNvbG9yLWJhc2U6ICNmZmZmZmYgICFpbXBvcnRhbnQ7XG4gIG92ZXJmbG93LXk6IGhpZGRlbiAhaW1wb3J0YW50O1xuXG4gICYuZGVza3RvcC12aWV3IHtcbiAgICAuaW1hZ2UtY29udGVudCB7XG4gICAgICBtYXJnaW4tdG9wOiAzNXB4O1xuICAgIH1cbiAgICAuZGl2LWFmdGVyLWltZyB7XG4gICAgICBtYXJnaW4tYm90dG9tOiAzNXB4O1xuICAgIH1cbiAgfVxuXG4gIC5pbWFnZS1jb250ZW50IHtcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xuXG4gICAgLmltYWdlIHtcbiAgICAgIHBhZGRpbmc6IDVweDtcbiAgICB9XG4gIH1cblxuICAuZGl2LWFmdGVyLWltZyB7XG4gICAgbWFyZ2luOiAwO1xuICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XG4gIH1cblxuICAuZGVzY3JpcHRpb24ge1xuICAgIG1heC1oZWlnaHQ6IG5vbmUgIWltcG9ydGFudDtcbiAgICAtd2Via2l0LWxpbmUtY2xhbXA6IHVuc2V0ICFpbXBvcnRhbnQ7XG4gIH1cblxufVxuIiwiLnBvcC11cC1jb250ZW50IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZiAhaW1wb3J0YW50O1xuICAtLWlvbi1jb2xvci1iYXNlOiAjZmZmZmZmICFpbXBvcnRhbnQ7XG4gIG92ZXJmbG93LXk6IGhpZGRlbiAhaW1wb3J0YW50O1xufVxuLnBvcC11cC1jb250ZW50LmRlc2t0b3AtdmlldyAuaW1hZ2UtY29udGVudCB7XG4gIG1hcmdpbi10b3A6IDM1cHg7XG59XG4ucG9wLXVwLWNvbnRlbnQuZGVza3RvcC12aWV3IC5kaXYtYWZ0ZXItaW1nIHtcbiAgbWFyZ2luLWJvdHRvbTogMzVweDtcbn1cbi5wb3AtdXAtY29udGVudCAuaW1hZ2UtY29udGVudCB7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG59XG4ucG9wLXVwLWNvbnRlbnQgLmltYWdlLWNvbnRlbnQgLmltYWdlIHtcbiAgcGFkZGluZzogNXB4O1xufVxuLnBvcC11cC1jb250ZW50IC5kaXYtYWZ0ZXItaW1nIHtcbiAgbWFyZ2luOiAwO1xuICBtYXJnaW4tYm90dG9tOiAxNXB4O1xufVxuLnBvcC11cC1jb250ZW50IC5kZXNjcmlwdGlvbiB7XG4gIG1heC1oZWlnaHQ6IG5vbmUgIWltcG9ydGFudDtcbiAgLXdlYmtpdC1saW5lLWNsYW1wOiB1bnNldCAhaW1wb3J0YW50O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/shared/notification/lock-team-assessment-pop-up/lock-team-assessment-pop-up.component.ts":
/*!**********************************************************************************************************!*\
  !*** ./src/app/shared/notification/lock-team-assessment-pop-up/lock-team-assessment-pop-up.component.ts ***!
  \**********************************************************************************************************/
/*! exports provided: LockTeamAssessmentPopUpComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LockTeamAssessmentPopUpComponent", function() { return LockTeamAssessmentPopUpComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm5/ionic-angular.js");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



var LockTeamAssessmentPopUpComponent = /** @class */ (function () {
    function LockTeamAssessmentPopUpComponent(modalController, utils) {
        this.modalController = modalController;
        this.utils = utils;
        this.name = '';
        this.image = '';
    }
    LockTeamAssessmentPopUpComponent.prototype.confirmed = function () {
        this.modalController.dismiss(true);
    };
    LockTeamAssessmentPopUpComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilsService"] }
    ]; };
    LockTeamAssessmentPopUpComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-lock-team-assessment-pop-up',
            template: __importDefault(__webpack_require__(/*! raw-loader!./lock-team-assessment-pop-up.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/notification/lock-team-assessment-pop-up/lock-team-assessment-pop-up.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./lock-team-assessment-pop-up.component.scss */ "./src/app/shared/notification/lock-team-assessment-pop-up/lock-team-assessment-pop-up.component.scss")).default]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilsService"]])
    ], LockTeamAssessmentPopUpComponent);
    return LockTeamAssessmentPopUpComponent;
}());



/***/ }),

/***/ "./src/app/shared/notification/notification.module.ts":
/*!************************************************************!*\
  !*** ./src/app/shared/notification/notification.module.ts ***!
  \************************************************************/
/*! exports provided: NotificationModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationModule", function() { return NotificationModule; });
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @shared/shared.module */ "./src/app/shared/shared.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _pop_up_pop_up_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pop-up/pop-up.component */ "./src/app/shared/notification/pop-up/pop-up.component.ts");
/* harmony import */ var _achievement_pop_up_achievement_pop_up_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./achievement-pop-up/achievement-pop-up.component */ "./src/app/shared/notification/achievement-pop-up/achievement-pop-up.component.ts");
/* harmony import */ var _activity_complete_pop_up_activity_complete_pop_up_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./activity-complete-pop-up/activity-complete-pop-up.component */ "./src/app/shared/notification/activity-complete-pop-up/activity-complete-pop-up.component.ts");
/* harmony import */ var _lock_team_assessment_pop_up_lock_team_assessment_pop_up_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./lock-team-assessment-pop-up/lock-team-assessment-pop-up.component */ "./src/app/shared/notification/lock-team-assessment-pop-up/lock-team-assessment-pop-up.component.ts");
/* harmony import */ var _notification_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./notification.service */ "./src/app/shared/notification/notification.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};







var NotificationModule = /** @class */ (function () {
    function NotificationModule() {
    }
    NotificationModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__["SharedModule"]
            ],
            providers: [
                _notification_service__WEBPACK_IMPORTED_MODULE_6__["NotificationService"]
            ],
            declarations: [
                _pop_up_pop_up_component__WEBPACK_IMPORTED_MODULE_2__["PopUpComponent"],
                _achievement_pop_up_achievement_pop_up_component__WEBPACK_IMPORTED_MODULE_3__["AchievementPopUpComponent"],
                _lock_team_assessment_pop_up_lock_team_assessment_pop_up_component__WEBPACK_IMPORTED_MODULE_5__["LockTeamAssessmentPopUpComponent"],
                _activity_complete_pop_up_activity_complete_pop_up_component__WEBPACK_IMPORTED_MODULE_4__["ActivityCompletePopUpComponent"]
            ],
            exports: [
                _pop_up_pop_up_component__WEBPACK_IMPORTED_MODULE_2__["PopUpComponent"],
                _achievement_pop_up_achievement_pop_up_component__WEBPACK_IMPORTED_MODULE_3__["AchievementPopUpComponent"],
                _lock_team_assessment_pop_up_lock_team_assessment_pop_up_component__WEBPACK_IMPORTED_MODULE_5__["LockTeamAssessmentPopUpComponent"],
                _activity_complete_pop_up_activity_complete_pop_up_component__WEBPACK_IMPORTED_MODULE_4__["ActivityCompletePopUpComponent"]
            ],
            entryComponents: [
                _pop_up_pop_up_component__WEBPACK_IMPORTED_MODULE_2__["PopUpComponent"],
                _achievement_pop_up_achievement_pop_up_component__WEBPACK_IMPORTED_MODULE_3__["AchievementPopUpComponent"],
                _lock_team_assessment_pop_up_lock_team_assessment_pop_up_component__WEBPACK_IMPORTED_MODULE_5__["LockTeamAssessmentPopUpComponent"],
                _activity_complete_pop_up_activity_complete_pop_up_component__WEBPACK_IMPORTED_MODULE_4__["ActivityCompletePopUpComponent"]
            ]
        })
    ], NotificationModule);
    return NotificationModule;
}());



/***/ }),

/***/ "./src/app/shared/notification/notification.service.ts":
/*!*************************************************************!*\
  !*** ./src/app/shared/notification/notification.service.ts ***!
  \*************************************************************/
/*! exports provided: NotificationService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationService", function() { return NotificationService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm5/ionic-angular.js");
/* harmony import */ var _pop_up_pop_up_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pop-up/pop-up.component */ "./src/app/shared/notification/pop-up/pop-up.component.ts");
/* harmony import */ var _achievement_pop_up_achievement_pop_up_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./achievement-pop-up/achievement-pop-up.component */ "./src/app/shared/notification/achievement-pop-up/achievement-pop-up.component.ts");
/* harmony import */ var _lock_team_assessment_pop_up_lock_team_assessment_pop_up_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./lock-team-assessment-pop-up/lock-team-assessment-pop-up.component */ "./src/app/shared/notification/lock-team-assessment-pop-up/lock-team-assessment-pop-up.component.ts");
/* harmony import */ var _activity_complete_pop_up_activity_complete_pop_up_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./activity-complete-pop-up/activity-complete-pop-up.component */ "./src/app/shared/notification/activity-complete-pop-up/activity-complete-pop-up.component.ts");
/* harmony import */ var _app_achievements_achievements_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @app/achievements/achievements.service */ "./src/app/achievements/achievements.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};








var NotificationService = /** @class */ (function () {
    function NotificationService(modalController, alertController, toastController, loadingController, achievementService, utils) {
        this.modalController = modalController;
        this.alertController = alertController;
        this.toastController = toastController;
        this.loadingController = loadingController;
        this.achievementService = achievementService;
        this.utils = utils;
    }
    NotificationService.prototype.dismiss = function () {
        return this.modalController.dismiss();
    };
    /**
     * @name modalConfig
     * @description futher customised filter
     */
    NotificationService.prototype.modalConfig = function (_a, options) {
        var component = _a.component, componentProps = _a.componentProps;
        if (options === void 0) { options = {}; }
        var config = Object.assign({
            component: component,
            componentProps: componentProps,
        }, options);
        return config;
    };
    // show pop up message
    // this is using pop-up.component.ts as the view
    // put redirect = false if don't need to redirect
    NotificationService.prototype.popUp = function (type, data, redirect) {
        if (redirect === void 0) { redirect = false; }
        return __awaiter(this, void 0, void 0, function () {
            var component, componentProps, modal;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        component = _pop_up_pop_up_component__WEBPACK_IMPORTED_MODULE_2__["PopUpComponent"];
                        componentProps = {
                            type: type,
                            data: data,
                            redirect: redirect,
                        };
                        return [4 /*yield*/, this.modal(component, componentProps)];
                    case 1:
                        modal = _a.sent();
                        return [2 /*return*/, modal];
                }
            });
        });
    };
    NotificationService.prototype.modal = function (component, componentProps, options, event) {
        return __awaiter(this, void 0, void 0, function () {
            var modal;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalOnly(component, componentProps, options, event)];
                    case 1:
                        modal = _a.sent();
                        return [2 /*return*/, modal.present()];
                }
            });
        });
    };
    NotificationService.prototype.modalOnly = function (component, componentProps, options, event) {
        return __awaiter(this, void 0, void 0, function () {
            var modal;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create(this.modalConfig({ component: component, componentProps: componentProps }, options))];
                    case 1:
                        modal = _a.sent();
                        if (event) {
                            modal.onDidDismiss().then(event);
                        }
                        return [2 /*return*/, modal];
                }
            });
        });
    };
    NotificationService.prototype.alert = function (config) {
        return __awaiter(this, void 0, void 0, function () {
            var alert;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create(config)];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    // toast message pop up, by default, shown success message for 2 seconds.
    NotificationService.prototype.presentToast = function (message, options) {
        return __awaiter(this, void 0, void 0, function () {
            var toastOptions, toast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        toastOptions = {
                            message: message,
                            duration: 2000,
                            position: 'top',
                            color: 'danger'
                        };
                        toastOptions = Object.assign(toastOptions, options);
                        return [4 /*yield*/, this.toastController.create(toastOptions)];
                    case 1:
                        toast = _a.sent();
                        return [2 /*return*/, toast.present()];
                }
            });
        });
    };
    /**
     * pop up achievement notification and detail
     * sample call for notification popup
     * NotificationService.achievementPopUp('notification', {
     *   image: 'url' (optinal - have default one)
     *   name: "Sample Headding"
     * });
     * sample call for info popup
     * NotificationService.achievementPopUp('', {
     *    image: 'url' (optinal - have default one)
     *    name: "Sample Headding",
     *    points: "100",
     *    description: "qwert yuiop asdfg asdff"
     * });
     */
    NotificationService.prototype.achievementPopUp = function (type, achievement) {
        return __awaiter(this, void 0, void 0, function () {
            var component, componentProps, modal;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        component = _achievement_pop_up_achievement_pop_up_component__WEBPACK_IMPORTED_MODULE_3__["AchievementPopUpComponent"];
                        componentProps = {
                            type: type,
                            achievement: achievement
                        };
                        if (type === 'notification') {
                            this.achievementService.markAchievementAsSeen(achievement.id);
                        }
                        return [4 /*yield*/, this.modal(component, componentProps, {
                                cssClass: this.utils.isMobile() ? 'practera-popup' : 'practera-popup desktop-view',
                                keyboardClose: false,
                                backdropDismiss: false
                            })];
                    case 1:
                        modal = _a.sent();
                        return [2 /*return*/, modal];
                }
            });
        });
    };
    /**
     * pop up to show user click on locked team assessment.
     * @param data
     * sample data object
     * NotificationService.lockTeamAssessmentPopUp({
     *    image: 'url' (optinal - have default one),
     *    name: "Alice"
     * });
     */
    NotificationService.prototype.lockTeamAssessmentPopUp = function (data, event) {
        return __awaiter(this, void 0, void 0, function () {
            var componentProps, component, modal;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        componentProps = {
                            name: data.name,
                            image: data.image
                        };
                        component = _lock_team_assessment_pop_up_lock_team_assessment_pop_up_component__WEBPACK_IMPORTED_MODULE_4__["LockTeamAssessmentPopUpComponent"];
                        return [4 /*yield*/, this.modal(component, componentProps, {
                                cssClass: this.utils.isMobile() ? 'practera-popup lock-assessment-popup' : 'practera-popup lock-assessment-popup desktop-view',
                            }, event)];
                    case 1:
                        modal = _a.sent();
                        return [2 /*return*/, modal];
                }
            });
        });
    };
    /**
     * pop up activity complete notification and detail
     *
     * sample call for activity complete popup
     * NotificationService.activityCompletePopUp(3);
     */
    NotificationService.prototype.activityCompletePopUp = function (activityId, activityCompleted) {
        return __awaiter(this, void 0, void 0, function () {
            var cssClass;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        cssClass = 'practera-popup activity-complete-popup';
                        if (this.utils.isMobile()) {
                            cssClass += ' mobile-view';
                        }
                        return [4 /*yield*/, this.modal(_activity_complete_pop_up_activity_complete_pop_up_component__WEBPACK_IMPORTED_MODULE_5__["ActivityCompletePopUpComponent"], { activityId: activityId, activityCompleted: activityCompleted }, {
                                cssClass: cssClass,
                                keyboardClose: false,
                                backdropDismiss: false
                            })];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    NotificationService.prototype.loading = function (opts) {
        return __awaiter(this, void 0, void 0, function () {
            var loading;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingController.create(opts || {
                            spinner: 'dots',
                        })];
                    case 1:
                        loading = _a.sent();
                        return [2 /*return*/, loading.present()];
                }
            });
        });
    };
    NotificationService.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["AlertController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ToastController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["LoadingController"] },
        { type: _app_achievements_achievements_service__WEBPACK_IMPORTED_MODULE_6__["AchievementsService"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_7__["UtilsService"] }
    ]; };
    NotificationService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ToastController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["LoadingController"],
            _app_achievements_achievements_service__WEBPACK_IMPORTED_MODULE_6__["AchievementsService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_7__["UtilsService"]])
    ], NotificationService);
    return NotificationService;
}());



/***/ }),

/***/ "./src/app/shared/notification/pop-up/pop-up.component.css":
/*!*****************************************************************!*\
  !*** ./src/app/shared/notification/pop-up/pop-up.component.css ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9ub3RpZmljYXRpb24vcG9wLXVwL3BvcC11cC5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/shared/notification/pop-up/pop-up.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/shared/notification/pop-up/pop-up.component.ts ***!
  \****************************************************************/
/*! exports provided: PopUpComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PopUpComponent", function() { return PopUpComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm5/ionic-angular.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



var PopUpComponent = /** @class */ (function () {
    function PopUpComponent(router, modalController) {
        this.router = router;
        this.modalController = modalController;
        this.type = '';
        this.redirect = ['/'];
        this.data = {};
    }
    PopUpComponent.prototype.confirmed = function () {
        this.modalController.dismiss();
        // if this.redirect == false, don't redirect to another page
        if (this.redirect) {
            this.router.navigate(this.redirect);
        }
    };
    PopUpComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
    ]; };
    PopUpComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-pop-up',
            template: __importDefault(__webpack_require__(/*! raw-loader!./pop-up.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/notification/pop-up/pop-up.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./pop-up.component.css */ "./src/app/shared/notification/pop-up/pop-up.component.css")).default]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], PopUpComponent);
    return PopUpComponent;
}());



/***/ }),

/***/ "./src/app/shared/pusher/pusher.module.ts":
/*!************************************************!*\
  !*** ./src/app/shared/pusher/pusher.module.ts ***!
  \************************************************/
/*! exports provided: PusherModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PusherModule", function() { return PusherModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/common.js");
/* harmony import */ var _pusher_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pusher.service */ "./src/app/shared/pusher/pusher.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



var PusherModule = /** @class */ (function () {
    function PusherModule(parentModule) {
        if (parentModule) {
            throw new Error('PusherModule is already loaded. Import it in the AppModule only');
        }
    }
    PusherModule_1 = PusherModule;
    PusherModule.forRoot = function (config) {
        return {
            ngModule: PusherModule_1,
            providers: [
                { provide: _pusher_service__WEBPACK_IMPORTED_MODULE_2__["PusherConfig"], useValue: config }
            ]
        };
    };
    var PusherModule_1;
    PusherModule.ctorParameters = function () { return [
        { type: PusherModule, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["SkipSelf"] }] }
    ]; };
    PusherModule = PusherModule_1 = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            declarations: [],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]
            ],
            providers: [_pusher_service__WEBPACK_IMPORTED_MODULE_2__["PusherService"]],
            exports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]]
        }),
        __param(0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"])()), __param(0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["SkipSelf"])()),
        __metadata("design:paramtypes", [PusherModule])
    ], PusherModule);
    return PusherModule;
}());



/***/ }),

/***/ "./src/app/shared/pusher/pusher.service.ts":
/*!*************************************************!*\
  !*** ./src/app/shared/pusher/pusher.service.ts ***!
  \*************************************************/
/*! exports provided: PusherConfig, PusherService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PusherConfig", function() { return PusherConfig; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PusherService", function() { return PusherService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _shared_request_request_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @shared/request/request.service */ "./src/app/shared/request/request.service.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var pusher_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! pusher-js */ "./node_modules/pusher-js/dist/web/pusher.js");
/* harmony import */ var pusher_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(pusher_js__WEBPACK_IMPORTED_MODULE_8__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};









var api = {
    pusherAuth: 'api/v2/message/notify/pusher_auth.json',
    channels: 'api/v2/message/notify/channels.json'
};
var PusherConfig = /** @class */ (function () {
    function PusherConfig() {
        this.pusherKey = '';
        this.apiurl = '';
    }
    return PusherConfig;
}());

var PusherService = /** @class */ (function () {
    function PusherService(http, config, request, utils, storage, ngZone) {
        this.http = http;
        this.request = request;
        this.utils = utils;
        this.storage = storage;
        this.ngZone = ngZone;
        this.channelNames = {
            presence: {
                name: null,
                subscription: null,
            },
            team: {
                name: null,
                subscription: null,
            },
            teamNoMentor: {
                name: null,
                subscription: null,
            },
            notification: {
                name: null,
                subscription: null,
            }
        };
        this.channels = {
            presence: null,
            team: null,
            teamNoMentor: null,
            notification: null
        };
        this.typingAction = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        if (config) {
            this.pusherKey = config.pusherKey;
            this.apiurl = config.apiurl;
        }
    }
    // initialise + subscribe to channels at one go
    PusherService.prototype.initialise = function (options) {
        return __awaiter(this, void 0, void 0, function () {
            var _a, channels;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        if (!!this.pusher) return [3 /*break*/, 2];
                        _a = this;
                        return [4 /*yield*/, this.initialisePusher()];
                    case 1:
                        _a.pusher = _b.sent();
                        _b.label = 2;
                    case 2:
                        if (!this.pusher) {
                            return [2 /*return*/, {}];
                        }
                        if (options && options.unsubscribe) {
                            this.unsubscribeChannels();
                            this.typingAction = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
                        }
                        // handling condition at re-login without rebuilding pusher (where isInstantiated() is false)
                        if (this.pusher.connection.state !== 'connected') {
                            // reconnect pusher
                            this.pusher.connect();
                        }
                        return [4 /*yield*/, this.getChannels().toPromise()];
                    case 3:
                        channels = _b.sent();
                        return [2 /*return*/, {
                                pusher: this.pusher,
                                channels: channels
                            }];
                }
            });
        });
    };
    PusherService.prototype.disconnect = function () {
        if (this.pusher) {
            return this.pusher.disconnect();
        }
        return;
    };
    // check if pusher has been instantiated correctly
    PusherService.prototype.isInstantiated = function () {
        if (this.utils.isEmpty(this.pusher)) {
            return false;
        }
        if (this.pusher.connection.state === 'disconnected') {
            return false;
        }
        return true;
    };
    PusherService.prototype.initialisePusher = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a, apikey, timelineId, config, newPusherInstance, err_1;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        // during the app execution lifecycle
                        if (typeof this.pusher !== 'undefined') {
                            return [2 /*return*/, this.pusher];
                        }
                        _a = this.storage.getUser(), apikey = _a.apikey, timelineId = _a.timelineId;
                        if (!apikey || !timelineId) {
                            return [2 /*return*/, this.pusher];
                        }
                        // never reinstantiate another instance of Pusher
                        if (!this.utils.isEmpty(this.pusher)) {
                            return [2 /*return*/, this.pusher];
                        }
                        _b.label = 1;
                    case 1:
                        _b.trys.push([1, 3, , 4]);
                        config = {
                            cluster: 'mt1',
                            forceTLS: true,
                            authEndpoint: this.apiurl + api.pusherAuth,
                            auth: {
                                headers: {
                                    'Authorization': 'pusherKey=' + this.pusherKey,
                                    'appkey': _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].appkey,
                                    'apikey': this.storage.getUser().apikey,
                                    'timelineid': this.storage.getUser().timelineId
                                },
                            },
                        };
                        return [4 /*yield*/, new pusher_js__WEBPACK_IMPORTED_MODULE_8__(this.pusherKey, config)];
                    case 2:
                        newPusherInstance = _b.sent();
                        return [2 /*return*/, newPusherInstance];
                    case 3:
                        err_1 = _b.sent();
                        throw new Error(err_1);
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * check if every channel has been subscribed properly
     * true: subscribed
     * false: haven't subscribed
     */
    PusherService.prototype.isSubscribed = function (newChannelName) {
        var channels = this.pusher.allChannels();
        var subscribedChannel = false;
        this.utils.each(channels, function (channel) {
            if (channel.name === newChannelName && channel.subscribed) {
                subscribedChannel = true;
            }
        });
        return subscribedChannel;
    };
    /**
     * get a list of channels from API request and subscribe every of them into
     * connected + authorised pusher
     */
    PusherService.prototype.getChannels = function () {
        var _this = this;
        return this.request.get(api.channels, {
            params: { env: _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].env }
        }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (response) {
            if (response.data) {
                return _this._subscribeChannels(response.data);
            }
        }));
    };
    /**
     * unsubscribe all channels
     * (use case: after switching program)
     */
    PusherService.prototype.unsubscribeChannels = function () {
        var _this = this;
        this.utils.each(this.channelNames, function (channel, key) {
            if (channel) {
                _this.channelNames[key] = { name: null, subscription: null };
                if (_this.channels[key]) {
                    // unbind all events from this channel
                    _this.channels[key].unbind_all();
                    _this.channels[key] = null;
                }
                // handle issue logout at first load of program-switching view
                if (_this.pusher) {
                    _this.pusher.unbind_all();
                    _this.pusher.unsubscribe(channel.name);
                }
            }
        });
    };
    PusherService.prototype._subscribeChannels = function (channels) {
        var _this = this;
        // channels format verification
        if (this.utils.isEmpty(channels)) {
            return this.request.apiResponseFormatError('Pusher channels cannot be empty');
        }
        if (!Array.isArray(channels)) {
            return this.request.apiResponseFormatError('Pusher channels must be an array');
        }
        var incorrectChannelName = channels.find(function (channel) { return !_this.utils.has(channel, 'channel'); });
        if (incorrectChannelName) {
            return this.request.apiResponseFormatError('Pusher channel format error');
        }
        channels.forEach(function (channel) {
            // subscribe channels and bind events
            // team
            if (channel.channel.includes('private-' + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].env + '-team-') &&
                !channel.channel.includes('nomentor')) {
                if (_this.isSubscribed(channel.channel)) {
                    return;
                }
                _this.channelNames.team.name = channel.channel;
                _this.channels.team = _this.pusher.subscribe(channel.channel);
                _this.channels.team
                    .bind('send-event', function (data) {
                    _this.utils.broadcastEvent('team-message', data);
                })
                    .bind('typing-event', function (data) {
                    _this.utils.broadcastEvent('team-typing', data);
                })
                    .bind('client-typing-event', function (data) {
                    _this.utils.broadcastEvent('team-typing', data);
                })
                    .bind('pusher:subscription_succeeded', function (data) {
                    _this.channelNames.team.subscription = true;
                })
                    .bind('pusher:subscription_error', function () {
                    _this.channelNames.team.subscription = channel.channel + " channel subscription failed.";
                });
                return;
            }
            // team without mentor
            if (channel.channel.includes('private-' + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].env + '-team-nomentor-')) {
                if (_this.isSubscribed(channel.channel)) {
                    return;
                }
                _this.channelNames.teamNoMentor.name = channel.channel;
                _this.channels.teamNoMentor = _this.pusher.subscribe(channel.channel);
                _this.channels.teamNoMentor
                    .bind('send-event', function (data) {
                    _this.utils.broadcastEvent('team-no-mentor-message', data);
                })
                    .bind('typing-event', function (data) {
                    _this.utils.broadcastEvent('team-no-mentor-typing', data);
                })
                    .bind('client-typing-event', function (data) {
                    _this.utils.broadcastEvent('team-no-mentor-typing', data);
                })
                    .bind('pusher:subscription_succeeded', function (data) {
                    _this.channelNames.teamNoMentor.subscription = true;
                })
                    .bind('pusher:subscription_error', function (data) {
                    _this.channelNames.teamNoMentor.subscription = channel.channel + " channel subscription failed.";
                });
                return;
            }
            // notification
            if (channel.channel.includes('private-' + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].env + '-notification-')) {
                if (_this.isSubscribed(channel.channel)) {
                    return;
                }
                _this.channelNames.notification.name = channel.channel;
                _this.channels.notification = _this.pusher.subscribe(channel.channel);
                _this.channels.notification
                    .bind('notification', function (data) {
                    _this.utils.broadcastEvent('notification', data);
                })
                    .bind('achievement', function (data) {
                    _this.utils.broadcastEvent('achievement', data);
                })
                    .bind('event-reminder', function (data) {
                    _this.utils.broadcastEvent('event-reminder', data);
                })
                    .bind('pusher:subscription_succeeded', function (data) {
                    _this.channelNames.notification.subscription = true;
                })
                    .bind('pusher:subscription_error', function (data) {
                    _this.channelNames.notification.subscription = channel.channel + " channel subscription failed.";
                });
                return;
            }
            // team member presence
            if (channel.channel.includes('presence-' + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].env + '-team-')) {
                if (_this.isSubscribed(channel.channel)) {
                    return;
                }
                _this.channelNames.presence.name = channel.channel;
                _this.channels.presence = _this.pusher.subscribe(channel.channel);
                _this.channels.presence
                    .bind('pusher:subscription_succeeded', function (data) {
                    _this.channelNames.presence.subscription = true;
                })
                    .bind('pusher:subscription_error', function (data) {
                    _this.channelNames.presence.subscription = channel.channel + " channel subscription failed.";
                });
                return;
            }
        });
        // subscribe to typing event
        return this.initiateTypingEvent().subscribe(function (data) {
            return _this.pusher.channels;
        });
    };
    PusherService.prototype.getMyPresenceChannelId = function () {
        if (!this.utils.isEmpty(this.channels.presence) && this.utils.has(this.channels.presence, 'members')) {
            return this.channels.presence.members.me.id;
        }
        return;
    };
    /**
     * prepare subsequent "next" trigger for hot observable,
     * let rxjs handle the repeated trigger before API
     */
    PusherService.prototype.triggerTyping = function (data, participantsOnly) {
        if (participantsOnly) {
            return this.typingAction.next({
                data: data,
                channel: this.channels.teamNoMentor,
            });
        }
        return this.typingAction.next({
            data: data,
            channel: this.channels.team
        });
    };
    PusherService.prototype.initiateTypingEvent = function () {
        return this.typingAction.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["debounceTime"])(300), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["switchMap"])(function (event) {
            if (event.channel) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(event.channel.trigger('client-typing-event', event.data));
            }
            // error handling for unsubscribed pusher channel
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(true);
        }));
    };
    PusherService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
        { type: PusherConfig, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"] }] },
        { type: _shared_request_request_service__WEBPACK_IMPORTED_MODULE_4__["RequestService"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_6__["UtilsService"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_7__["BrowserStorageService"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"] }
    ]; };
    PusherService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root',
        }),
        __param(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"])()),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            PusherConfig,
            _shared_request_request_service__WEBPACK_IMPORTED_MODULE_4__["RequestService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_6__["UtilsService"],
            _services_storage_service__WEBPACK_IMPORTED_MODULE_7__["BrowserStorageService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]])
    ], PusherService);
    return PusherService;
}());



/***/ }),

/***/ "./src/app/shared/request/request.interceptor.ts":
/*!*******************************************************!*\
  !*** ./src/app/shared/request/request.interceptor.ts ***!
  \*******************************************************/
/*! exports provided: RequestInterceptor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequestInterceptor", function() { return RequestInterceptor; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _request_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./request.service */ "./src/app/shared/request/request.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



var RequestInterceptor = /** @class */ (function () {
    function RequestInterceptor(storage, config) {
        this.storage = storage;
        this.currenConfig = config;
    }
    RequestInterceptor.prototype.intercept = function (req, next) {
        if (req.url.includes('ipapi.co')) {
            return next.handle(req);
        }
        var apikey = this.storage.getUser().apikey;
        var timelineId = this.storage.getUser().timelineId;
        var teamId = this.storage.getUser().teamId;
        var headerClone = req.headers;
        var paramsInject = req.params;
        // inject appkey
        if (this.currenConfig.appkey) {
            var appkey = this.currenConfig.appkey;
            headerClone = headerClone.set('appkey', appkey);
        }
        if (apikey) {
            headerClone = headerClone.set('apikey', apikey);
        }
        if (timelineId) {
            headerClone = headerClone.set('timelineId', timelineId);
        }
        // do not need to pass team id for teams.json
        // do not need to pass team id for chat api calls
        if (teamId && !req.url.includes('/teams.json') &&
            !req.url.includes('/message/chat/list.json') && !req.url.includes('/message/chat/create_message') &&
            !req.url.includes('/message/chat/edit_message') && !req.url.includes('/message/chat/list_messages.json')) {
            headerClone = headerClone.set('teamId', teamId);
        }
        return next.handle(req.clone({
            headers: headerClone,
            params: paramsInject,
        }));
    };
    RequestInterceptor.ctorParameters = function () { return [
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__["BrowserStorageService"] },
        { type: _request_service__WEBPACK_IMPORTED_MODULE_1__["RequestConfig"], decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"] }] }
    ]; };
    RequestInterceptor = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __param(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"])()),
        __metadata("design:paramtypes", [_services_storage_service__WEBPACK_IMPORTED_MODULE_2__["BrowserStorageService"],
            _request_service__WEBPACK_IMPORTED_MODULE_1__["RequestConfig"]])
    ], RequestInterceptor);
    return RequestInterceptor;
}());



/***/ }),

/***/ "./src/app/shared/request/request.module.ts":
/*!**************************************************!*\
  !*** ./src/app/shared/request/request.module.ts ***!
  \**************************************************/
/*! exports provided: RequestModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequestModule", function() { return RequestModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _request_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./request.service */ "./src/app/shared/request/request.service.ts");
/* harmony import */ var _request_interceptor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./request.interceptor */ "./src/app/shared/request/request.interceptor.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};





var RequestModule = /** @class */ (function () {
    function RequestModule(parentModule) {
        if (parentModule) {
            throw new Error('RequestModule is already loaded. Import it in the AppModule only');
        }
    }
    RequestModule_1 = RequestModule;
    RequestModule.forRoot = function (config) {
        return {
            ngModule: RequestModule_1,
            providers: [
                { provide: _request_service__WEBPACK_IMPORTED_MODULE_1__["RequestConfig"], useValue: config }
            ]
        };
    };
    var RequestModule_1;
    RequestModule.ctorParameters = function () { return [
        { type: RequestModule, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["SkipSelf"] }] }
    ]; };
    RequestModule = RequestModule_1 = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClientModule"],
            ],
            providers: [
                _request_service__WEBPACK_IMPORTED_MODULE_1__["RequestService"],
                {
                    provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HTTP_INTERCEPTORS"],
                    useClass: _request_interceptor__WEBPACK_IMPORTED_MODULE_2__["RequestInterceptor"],
                    multi: true,
                },
            ],
            exports: [
                _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClientModule"],
            ],
        }),
        __param(0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"])()), __param(0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["SkipSelf"])()),
        __metadata("design:paramtypes", [RequestModule])
    ], RequestModule);
    return RequestModule;
}());



/***/ }),

/***/ "./src/app/shared/request/request.service.ts":
/*!***************************************************!*\
  !*** ./src/app/shared/request/request.service.ts ***!
  \***************************************************/
/*! exports provided: DevModeService, RequestConfig, QueryEncoder, RequestService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DevModeService", function() { return DevModeService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequestConfig", function() { return RequestConfig; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QueryEncoder", function() { return QueryEncoder; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequestService", function() { return RequestService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @shared/new-relic/new-relic.service */ "./src/app/shared/new-relic/new-relic.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};









var DevModeService = /** @class */ (function () {
    function DevModeService() {
    }
    DevModeService.prototype.isDevMode = function () {
        return Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["isDevMode"])();
    };
    DevModeService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({ providedIn: 'root' })
    ], DevModeService);
    return DevModeService;
}());

var RequestConfig = /** @class */ (function () {
    function RequestConfig() {
        this.appkey = '';
        this.prefixUrl = '';
    }
    return RequestConfig;
}());

var QueryEncoder = /** @class */ (function () {
    function QueryEncoder() {
    }
    QueryEncoder.prototype.encodeKey = function (k) {
        return encodeURIComponent(k);
    };
    QueryEncoder.prototype.encodeValue = function (v) {
        return encodeURIComponent(v);
    };
    QueryEncoder.prototype.decodeKey = function (k) {
        return decodeURIComponent(k);
    };
    QueryEncoder.prototype.decodeValue = function (v) {
        return decodeURIComponent(v);
    };
    return QueryEncoder;
}());

var RequestService = /** @class */ (function () {
    function RequestService(http, utils, storage, router, config, newrelic, devMode) {
        this.http = http;
        this.utils = utils;
        this.storage = storage;
        this.router = router;
        this.newrelic = newrelic;
        this.devMode = devMode;
        if (config) {
            this.appkey = config.appkey;
            this.prefixUrl = config.prefixUrl;
        }
    }
    /**
     *
     * @param {'Content-Type': string } header
     * @returns {HttpHeaders}
     */
    RequestService.prototype.appendHeaders = function (header) {
        if (header === void 0) { header = {}; }
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"](Object.assign({ 'Content-Type': 'application/json' }, header));
        return headers;
    };
    /**
     *
     * @param options
     * @returns {any}
     */
    RequestService.prototype.setParams = function (options) {
        var params;
        if (!this.utils.isEmpty(options)) {
            params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]();
            this.utils.each(options, function (value, key) {
                params = params.append(key, value);
            });
        }
        return params;
    };
    RequestService.prototype.getEndpointUrl = function (endpoint) {
        var endpointUrl = this.prefixUrl + endpoint;
        if (endpoint.includes('https://') || endpoint.includes('http://')) {
            endpointUrl = endpoint;
        }
        return endpointUrl;
    };
    /**
     *
     * @param {string} endPoint
     * @param options
     * @param headers
     * @returns {Observable<any>}
     */
    RequestService.prototype.get = function (endPoint, httpOptions) {
        var _this = this;
        if (endPoint === void 0) { endPoint = ''; }
        if (!httpOptions) {
            httpOptions = {};
        }
        if (!this.utils.has(httpOptions, 'headers')) {
            httpOptions.headers = '';
        }
        if (!this.utils.has(httpOptions, 'params')) {
            httpOptions.params = '';
        }
        return this.http.get(this.getEndpointUrl(endPoint), {
            headers: this.appendHeaders(httpOptions.headers),
            params: this.setParams(httpOptions.params)
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["concatMap"])(function (response) {
            _this._refreshApikey(response);
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(response);
        }))
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) { return _this.handleError(error); }));
    };
    RequestService.prototype.post = function (endPoint, data, httpOptions) {
        var _this = this;
        if (endPoint === void 0) { endPoint = ''; }
        if (!httpOptions) {
            httpOptions = {};
        }
        if (!this.utils.has(httpOptions, 'headers')) {
            httpOptions.headers = '';
        }
        if (!this.utils.has(httpOptions, 'params')) {
            httpOptions.params = '';
        }
        return this.http.post(this.getEndpointUrl(endPoint), data, {
            headers: this.appendHeaders(httpOptions.headers),
            params: this.setParams(httpOptions.params)
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["concatMap"])(function (response) {
            _this._refreshApikey(response);
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(response);
        }))
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) { return _this.handleError(error); }));
    };
    RequestService.prototype.postGraphQL = function (data) {
        var _this = this;
        return this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].graphQL, data, {
            headers: this.appendHeaders()
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["concatMap"])(function (response) {
            _this._refreshApikey(response);
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(response);
        }))
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) { return _this.handleError(error); }));
    };
    RequestService.prototype.delete = function (endPoint, httpOptions) {
        var _this = this;
        if (endPoint === void 0) { endPoint = ''; }
        if (!httpOptions) {
            httpOptions = {};
        }
        if (!this.utils.has(httpOptions, 'headers')) {
            httpOptions.headers = '';
        }
        if (!this.utils.has(httpOptions, 'params')) {
            httpOptions.params = '';
        }
        return this.http.delete(this.getEndpointUrl(endPoint), {
            headers: this.appendHeaders(httpOptions.headers),
            params: this.setParams(httpOptions.params)
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["concatMap"])(function (response) {
            _this._refreshApikey(response);
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(response);
        }))
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) { return _this.handleError(error); }));
    };
    /**
     *
     * @returns {string}
     */
    RequestService.prototype.getPrefixUrl = function () {
        return this.prefixUrl;
    };
    /**
     *
     * @returns {string}
     */
    RequestService.prototype.getAppkey = function () {
        return this.appkey;
    };
    RequestService.prototype.apiResponseFormatError = function (msg) {
        if (msg === void 0) { msg = ''; }
        console.error('API response format error.\n' + msg);
        return;
    };
    RequestService.prototype.handleError = function (error) {
        var _this = this;
        if (this.devMode.isDevMode()) {
            console.error(error); // log to console instead
        }
        // log the user out if jwt expired
        if (this.utils.has(error, 'error.message') && [
            'Request must contain an apikey',
            'Expired apikey',
            'Invalid apikey'
        ].includes(error.error.message) && !this.loggedOut) {
            // in case lots of api returns the same apikey invalid at the same time
            this.loggedOut = true;
            setTimeout(function () {
                _this.loggedOut = false;
            }, 2000);
            this.router.navigate(['logout']);
        }
        this.newrelic.noticeError(error);
        // if error.error is a html template error (when try to read remote version.txt)
        if (typeof error.error === 'string' && error.error.indexOf('<!DOCTYPE html>') !== -1) {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(error.message);
        }
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(error.error);
    };
    /**
     * Refresh the apikey (JWT token) if API returns it
     *
     */
    RequestService.prototype._refreshApikey = function (response) {
        if (this.utils.has(response, 'apikey')) {
            this.storage.setUser({ apikey: response.apikey });
        }
    };
    RequestService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_5__["UtilsService"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_6__["BrowserStorageService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: RequestConfig, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"] }] },
        { type: _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_8__["NewRelicService"] },
        { type: DevModeService }
    ]; };
    RequestService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root',
        }),
        __param(4, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"])()),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_5__["UtilsService"],
            _services_storage_service__WEBPACK_IMPORTED_MODULE_6__["BrowserStorageService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            RequestConfig,
            _shared_new_relic_new_relic_service__WEBPACK_IMPORTED_MODULE_8__["NewRelicService"],
            DevModeService])
    ], RequestService);
    return RequestService;
}());



/***/ }),

/***/ "./src/app/shared/shared.module.ts":
/*!*****************************************!*\
  !*** ./src/app/shared/shared.module.ts ***!
  \*****************************************/
/*! exports provided: SharedModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedModule", function() { return SharedModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm5/ionic-angular.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var _shared_components_activity_card_activity_card_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @shared/components/activity-card/activity-card.component */ "./src/app/shared/components/activity-card/activity-card.component.ts");
/* harmony import */ var _shared_components_achievement_badge_achievement_badge_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @shared/components/achievement-badge/achievement-badge.component */ "./src/app/shared/components/achievement-badge/achievement-badge.component.ts");
/* harmony import */ var _shared_components_description_description_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @shared/components/description/description.component */ "./src/app/shared/components/description/description.component.ts");
/* harmony import */ var _shared_components_clickable_item_clickable_item_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @shared/components/clickable-item/clickable-item.component */ "./src/app/shared/components/clickable-item/clickable-item.component.ts");
/* harmony import */ var _shared_components_circle_progress_circle_progress_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @shared/components/circle-progress/circle-progress.component */ "./src/app/shared/components/circle-progress/circle-progress.component.ts");
/* harmony import */ var ng_circle_progress__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ng-circle-progress */ "./node_modules/ng-circle-progress/__ivy_ngcc__/fesm5/ng-circle-progress.js");
/* harmony import */ var _shared_components_branding_logo_branding_logo_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @shared/components/branding-logo/branding-logo.component */ "./src/app/shared/components/branding-logo/branding-logo.component.ts");
/* harmony import */ var _shared_components_contact_number_form_contact_number_form_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @shared/components/contact-number-form/contact-number-form.component */ "./src/app/shared/components/contact-number-form/contact-number-form.component.ts");
/* harmony import */ var _shared_components_list_item_list_item_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @shared/components/list-item/list-item.component */ "./src/app/shared/components/list-item/list-item.component.ts");
/* harmony import */ var _directives_float_float_directive__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./directives/float/float.directive */ "./src/app/shared/directives/float/float.directive.ts");
/* harmony import */ var _shared_components_img_img_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @shared/components/img/img.component */ "./src/app/shared/components/img/img.component.ts");
/* harmony import */ var _directives_drag_and_drop_drag_and_drop_directive__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./directives/drag-and-drop/drag-and-drop.directive */ "./src/app/shared/directives/drag-and-drop/drag-and-drop.directive.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};
















var largeCircleDefaultConfig = {
    backgroundColor: 'var(--ion-color-light)',
    subtitleColor: 'var(--ion-color-dark-tint)',
    showInnerStroke: false,
    startFromZero: false,
    outerStrokeColor: 'var(--ion-color-primary)',
    innerStrokeColor: 'var(--ion-color-primary)',
    subtitle: [
        'COMPLETE'
    ],
    animation: true,
    animationDuration: 1000,
    titleFontSize: '32',
    subtitleFontSize: '18',
};
var SharedModule = /** @class */ (function () {
    function SharedModule() {
    }
    SharedModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                ng_circle_progress__WEBPACK_IMPORTED_MODULE_9__["NgCircleProgressModule"].forRoot(largeCircleDefaultConfig),
            ],
            declarations: [
                _shared_components_activity_card_activity_card_component__WEBPACK_IMPORTED_MODULE_4__["ActivityCardComponent"],
                _shared_components_achievement_badge_achievement_badge_component__WEBPACK_IMPORTED_MODULE_5__["AchievementBadgeComponent"],
                _shared_components_description_description_component__WEBPACK_IMPORTED_MODULE_6__["DescriptionComponent"],
                _shared_components_clickable_item_clickable_item_component__WEBPACK_IMPORTED_MODULE_7__["ClickableItemComponent"],
                _shared_components_circle_progress_circle_progress_component__WEBPACK_IMPORTED_MODULE_8__["CircleProgressComponent"],
                _shared_components_branding_logo_branding_logo_component__WEBPACK_IMPORTED_MODULE_10__["BrandingLogoComponent"],
                _shared_components_contact_number_form_contact_number_form_component__WEBPACK_IMPORTED_MODULE_11__["ContactNumberFormComponent"],
                _shared_components_list_item_list_item_component__WEBPACK_IMPORTED_MODULE_12__["ListItemComponent"],
                _directives_float_float_directive__WEBPACK_IMPORTED_MODULE_13__["FloatDirective"],
                _directives_drag_and_drop_drag_and_drop_directive__WEBPACK_IMPORTED_MODULE_15__["DragAndDropDirective"],
                _shared_components_img_img_component__WEBPACK_IMPORTED_MODULE_14__["ImgComponent"],
            ],
            exports: [
                _shared_components_activity_card_activity_card_component__WEBPACK_IMPORTED_MODULE_4__["ActivityCardComponent"],
                _shared_components_achievement_badge_achievement_badge_component__WEBPACK_IMPORTED_MODULE_5__["AchievementBadgeComponent"],
                _shared_components_description_description_component__WEBPACK_IMPORTED_MODULE_6__["DescriptionComponent"],
                _shared_components_clickable_item_clickable_item_component__WEBPACK_IMPORTED_MODULE_7__["ClickableItemComponent"],
                _shared_components_circle_progress_circle_progress_component__WEBPACK_IMPORTED_MODULE_8__["CircleProgressComponent"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _shared_components_branding_logo_branding_logo_component__WEBPACK_IMPORTED_MODULE_10__["BrandingLogoComponent"],
                _shared_components_contact_number_form_contact_number_form_component__WEBPACK_IMPORTED_MODULE_11__["ContactNumberFormComponent"],
                _shared_components_list_item_list_item_component__WEBPACK_IMPORTED_MODULE_12__["ListItemComponent"],
                _directives_float_float_directive__WEBPACK_IMPORTED_MODULE_13__["FloatDirective"],
                _shared_components_img_img_component__WEBPACK_IMPORTED_MODULE_14__["ImgComponent"],
                _directives_drag_and_drop_drag_and_drop_directive__WEBPACK_IMPORTED_MODULE_15__["DragAndDropDirective"]
            ],
        })
    ], SharedModule);
    return SharedModule;
}());



/***/ }),

/***/ "./src/app/switcher/switcher.service.ts":
/*!**********************************************!*\
  !*** ./src/app/switcher/switcher.service.ts ***!
  \**********************************************/
/*! exports provided: SwitcherService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SwitcherService", function() { return SwitcherService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _shared_request_request_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @shared/request/request.service */ "./src/app/shared/request/request.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _shared_pusher_pusher_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @shared/pusher/pusher.service */ "./src/app/shared/pusher/pusher.service.ts");
/* harmony import */ var _services_shared_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @services/shared.service */ "./src/app/services/shared.service.ts");
/* harmony import */ var _app_review_list_review_list_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @app/review-list/review-list.service */ "./src/app/review-list/review-list.service.ts");
/* harmony import */ var _app_event_list_event_list_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @app/event-list/event-list.service */ "./src/app/event-list/event-list.service.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};











/**
 * @name api
 * @description list of api endpoint involved in this service
 * @type {Object}
 */
var api = {
    me: 'api/users.json',
    teams: 'api/teams.json',
    jwt: 'api/v2/users/jwt/refresh.json'
};
var SwitcherService = /** @class */ (function () {
    function SwitcherService(request, utils, storage, sharedService, pusherService, reviewsService, eventsService) {
        this.request = request;
        this.utils = utils;
        this.storage = storage;
        this.sharedService = sharedService;
        this.pusherService = pusherService;
        this.reviewsService = reviewsService;
        this.eventsService = eventsService;
    }
    SwitcherService.prototype.getPrograms = function () {
        var _this = this;
        var programs = this.storage.get('programs');
        var cdn = 'https://cdn.filestackcontent.com/resize=fit:crop,width:';
        var imagewidth = 600;
        programs.forEach(function (program) {
            if (program.project.lead_image) {
                var imageId = program.project.lead_image.split('/').pop();
                if (!_this.utils.isMobile()) {
                    imagewidth = 1024;
                }
                program.project.lead_image = "" + cdn + imagewidth + "/" + imageId;
            }
        });
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])(programs);
    };
    /**
     * Get the progress and number of notifications for each project
     * @param projectIds Project ids
     */
    SwitcherService.prototype.getProgresses = function (projectIds) {
        return this.request.postGraphQL('"{projects(ids: ' + JSON.stringify(projectIds) + ') {id progress todoItems{isDone}}}"')
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) {
            return res.data.projects.map(function (v) {
                return {
                    id: +v.id,
                    progress: v.progress,
                    todoItems: v.todoItems.filter(function (ti) { return !ti.isDone; }).length
                };
            });
        }));
    };
    SwitcherService.prototype.switchProgram = function (programObj) {
        var themeColor = this.utils.has(programObj, 'program.config.theme_color') ? programObj.program.config.theme_color : '#2bbfd4';
        var cardBackgroundImage = '';
        if (this.utils.has(programObj, 'program.config.card_style')) {
            cardBackgroundImage = '/assets/' + programObj.program.config.card_style;
        }
        this.storage.setUser({
            programId: programObj.program.id,
            programName: programObj.program.name,
            programImage: programObj.project.lead_image,
            hasReviewRating: this.utils.has(programObj, 'program.config.review_rating') ? programObj.program.config.review_rating : false,
            truncateDescription: this.utils.has(programObj, 'program.config.truncate_description') ? programObj.program.config.truncate_description : true,
            experienceId: programObj.program.experience_id,
            projectId: programObj.project.id,
            timelineId: programObj.timeline.id,
            contactNumber: programObj.enrolment.contact_number,
            themeColor: themeColor,
            activityCardImage: cardBackgroundImage,
            enrolment: programObj.enrolment,
            teamId: null,
            hasEvents: false,
            hasReviews: false
        });
        this.sharedService.onPageLoad();
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["forkJoin"])([
            this.getNewJwt(),
            this.getTeamInfo(),
            this.getMyInfo(),
            this.getReviews(),
            this.getEvents()
        ]);
    };
    SwitcherService.prototype.getTeamInfo = function () {
        var _this = this;
        return this.request.get(api.teams)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (response) {
            if (response.success && response.data) {
                if (!_this.utils.has(response.data, 'Teams') ||
                    !Array.isArray(response.data.Teams) ||
                    !_this.utils.has(response.data.Teams[0], 'id')) {
                    return _this.storage.setUser({
                        teamId: null
                    });
                }
                return _this.storage.setUser({
                    teamId: response.data.Teams[0].id
                });
            }
        }));
    };
    /**
     * @name getMyInfo
     * @description get user info
     */
    SwitcherService.prototype.getMyInfo = function () {
        var _this = this;
        return this.request.get(api.me).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (response) {
            if (response.data) {
                if (!_this.utils.has(response, 'data.User')) {
                    return _this.request.apiResponseFormatError('User format error');
                }
                var apiData = response.data.User;
                _this.storage.setUser({
                    name: apiData.name,
                    contactNumber: apiData.contact_number,
                    email: apiData.email,
                    role: apiData.role,
                    image: apiData.image,
                    linkedinConnected: apiData.linkedinConnected,
                    linkedinUrl: apiData.linkedin_url,
                    userHash: apiData.userhash,
                    maxAchievablePoints: _this.utils.has(apiData, 'max_achievable_points') ? apiData.max_achievable_points : null
                });
            }
            return response;
        }));
    };
    SwitcherService.prototype.getReviews = function () {
        var _this = this;
        return this.reviewsService.getReviews().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (data) {
            _this.storage.setUser({
                hasReviews: (data && data.length > 0)
            });
            return data;
        }));
    };
    SwitcherService.prototype.getEvents = function () {
        var _this = this;
        return this.eventsService.getEvents().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (events) {
            _this.storage.setUser({
                hasEvents: !_this.utils.isEmpty(events)
            });
            return events;
        }));
    };
    SwitcherService.prototype.checkIsOneProgram = function (programs) {
        var programList = programs;
        if (this.utils.isEmpty(programs)) {
            programList = this.storage.get('programs');
        }
        if (programList.length === 1) {
            return true;
        }
        return false;
    };
    /**
     * this method will check program data and navigate to switcher or dashboard/go-mobile
     * @param programs
     * there are 4 types of values can come to programs variable.
     * - Array with multiple program objects -> [{},{},{},{}]
     * - Array with one program object -> [{}]
     * - one program object -> {}
     * - empty value
     * if method got 'Array with multiple program objects', redirect to switcher page.
     * if method got 'Array with one program object', switch to that program object and navigate to dashboard.
     * if method got 'one program object', switch to that program object and navigate to dashboard.
     * if method got 'empty value', do nothing.
     */
    SwitcherService.prototype.switchProgramAndNavigate = function (programs) {
        return __awaiter(this, void 0, void 0, function () {
            var route;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!!this.utils.isEmpty(programs)) return [3 /*break*/, 7];
                        if (!(Array.isArray(programs) && !this.checkIsOneProgram(programs))) return [3 /*break*/, 1];
                        return [2 /*return*/, ['switcher', 'switcher-program']];
                    case 1:
                        if (!(Array.isArray(programs) && this.checkIsOneProgram(programs))) return [3 /*break*/, 3];
                        return [4 /*yield*/, this.switchProgram(programs[0]).toPromise()];
                    case 2:
                        _a.sent();
                        return [3 /*break*/, 5];
                    case 3: 
                    // one program object -> {}
                    return [4 /*yield*/, this.switchProgram(programs).toPromise()];
                    case 4:
                        // one program object -> {}
                        _a.sent();
                        _a.label = 5;
                    case 5: return [4 /*yield*/, this.pusherService.initialise({ unsubscribe: true })];
                    case 6:
                        _a.sent();
                        // clear the cached data
                        this.utils.clearCache();
                        if ((typeof _environments_environment__WEBPACK_IMPORTED_MODULE_10__["environment"].goMobile !== 'undefined' && _environments_environment__WEBPACK_IMPORTED_MODULE_10__["environment"].goMobile === false)
                            || /iPhone|iPad|iPod|Android/i.test(navigator.userAgent)) {
                            if (this.storage.get('directLinkRoute')) {
                                route = this.storage.get('directLinkRoute');
                                this.storage.remove('directLinkRoute');
                                return [2 /*return*/, route];
                            }
                            return [2 /*return*/, ['app', 'home']];
                        }
                        else {
                            return [2 /*return*/, ['go-mobile']];
                        }
                        _a.label = 7;
                    case 7: return [2 /*return*/];
                }
            });
        });
    };
    SwitcherService.prototype.getNewJwt = function () {
        return this.request.get(api.jwt);
    };
    SwitcherService.ctorParameters = function () { return [
        { type: _shared_request_request_service__WEBPACK_IMPORTED_MODULE_3__["RequestService"] },
        { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilsService"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_5__["BrowserStorageService"] },
        { type: _services_shared_service__WEBPACK_IMPORTED_MODULE_7__["SharedService"] },
        { type: _shared_pusher_pusher_service__WEBPACK_IMPORTED_MODULE_6__["PusherService"] },
        { type: _app_review_list_review_list_service__WEBPACK_IMPORTED_MODULE_8__["ReviewListService"] },
        { type: _app_event_list_event_list_service__WEBPACK_IMPORTED_MODULE_9__["EventListService"] }
    ]; };
    SwitcherService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_shared_request_request_service__WEBPACK_IMPORTED_MODULE_3__["RequestService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilsService"],
            _services_storage_service__WEBPACK_IMPORTED_MODULE_5__["BrowserStorageService"],
            _services_shared_service__WEBPACK_IMPORTED_MODULE_7__["SharedService"],
            _shared_pusher_pusher_service__WEBPACK_IMPORTED_MODULE_6__["PusherService"],
            _app_review_list_review_list_service__WEBPACK_IMPORTED_MODULE_8__["ReviewListService"],
            _app_event_list_event_list_service__WEBPACK_IMPORTED_MODULE_9__["EventListService"]])
    ], SwitcherService);
    return SwitcherService;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};
// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --configuration=production` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in configurations section of `angular.json`.
var environment = {
    production: false,
    appkey: 'b11e7c189b',
    pusherKey: '255f010d210933ca7675',
    env: 'sandbox',
    APIEndpoint: 'https://sandbox.practera.com/',
    graphQL: 'https://kixs5acl6j.execute-api.ap-southeast-2.amazonaws.com/sandbox/',
    // APIEndpoint: 'http://127.0.0.1:8080/',
    // graphQL: 'http://127.0.0.1:8000/',
    intercomAppId: '',
    filestack: {
        key: 'AO6F4C72uTPGRywaEijdLz',
        s3Config: {
            location: 's3',
            container: 'practera-aus',
            containerChina: 'practera-kr',
            region: 'ap-southeast-2',
            regionChina: 'ap-northeast-2',
            paths: {
                any: '/appv2/stage/uploads/',
                image: '/appv2/stage/uploads/',
                video: '/appv2/stage/video/upload/'
            },
            workflows: [
                '3c38ef53-a9d0-4aa4-9234-617d9f03c0de',
            ],
        },
        policy: '<CUSTOM_FILESTACK_POLICY>',
        signature: '<CUSTOM_FILESTACK_SIGNATURE>',
        workflows: {
            virusDetection: '3c38ef53-a9d0-4aa4-9234-617d9f03c0de',
        },
    },
    defaultCountryModel: 'AUS',
    intercom: false,
    goMobile: false,
};
/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/__ivy_ngcc__/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/chaw/Workspaces/www/intersective/practera-app-v2/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map